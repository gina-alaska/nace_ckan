<?php

/*

CometChat
Copyright (c) 2016 Inscripts
License: https://www.cometchat.com/legal/license

*/
	$_GET['process']=1;
	include_once(dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR."cometchat_login.php");
	exit;
?>