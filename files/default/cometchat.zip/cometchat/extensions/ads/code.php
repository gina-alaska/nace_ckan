<?php
$extensioninfo = array('ads','Advertisements');