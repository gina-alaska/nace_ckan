<?php
$extensioninfo = array('jabber','Gtalk Chat');