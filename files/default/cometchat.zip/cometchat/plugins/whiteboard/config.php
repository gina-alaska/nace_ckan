<?php

include_once(dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'config.php');

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* SETTINGS START */

$whitebWidth = setConfigValue('whitebWidth','752');
$whitebHeight = setConfigValue('whitebHeight','628');

/* SETTINGS END */

$drawPluginType = '0';
$drawURL = 'https://b.chatforyoursite.com';
$hostAddress = '';
$port = '1935';
$application = 'whiteboard';
$token = '643d5323225058c99e7622d887c6d10c8681b0fd';

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////