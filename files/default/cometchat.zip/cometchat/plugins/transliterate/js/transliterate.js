

/**************************************** jsapi ****************************************************/
if(!window['googleLT_']){window['googleLT_']=(new Date()).getTime();}if (!window['google']) {
window['google'] = {};
}
if (!window['google']['loader']) {
window['google']['loader'] = {};
google.loader.ServiceBase = 'https://www.google.com/uds';
google.loader.GoogleApisBase = 'https://ajax.googleapis.com/ajax';
google.loader.ApiKey = 'notsupplied';
google.loader.KeyVerified = true;
google.loader.LoadFailure = false;
google.loader.Secure = false;
google.loader.GoogleLocale = 'https://www.google.com';
google.loader.ClientLocation = null;
google.loader.AdditionalParams = '';
(function() {var d=encodeURIComponent,g=window,h=document;function l(a,b){return a.load=b}var m="push",n="replace",q="charAt",r="indexOf",t="ServiceBase",u="name",v="getTime",w="length",x="prototype",y="setTimeout",z="loader",A="substring",B="join",C="toLowerCase";function D(a){return a in E?E[a]:E[a]=-1!=navigator.userAgent[C]()[r](a)}var E={};function F(a,b){var c=function(){};c.prototype=b[x];a.U=b[x];a.prototype=new c}
function G(a,b,c){var e=Array[x].slice.call(arguments,2)||[];return function(){return a.apply(b,e.concat(Array[x].slice.call(arguments)))}}function H(a){a=Error(a);a.toString=function(){return this.message};return a}function I(a,b){for(var c=a.split(/\./),e=g,f=0;f<c[w]-1;f++)e[c[f]]||(e[c[f]]={}),e=e[c[f]];e[c[c[w]-1]]=b}function J(a,b,c){a[b]=c}if(!K)var K=I;if(!L)var L=J;google[z].v={};K("google.loader.callbacks",google[z].v);var M={},N={};google[z].eval={};K("google.loader.eval",google[z].eval);
l(google,function(a,b,c){function e(a){var b=a.split(".");if(2<b[w])throw H("Module: '"+a+"' not found!");"undefined"!=typeof b[1]&&(f=b[0],c.packages=c.packages||[],c.packages[m](b[1]))}var f=a;c=c||{};if(a instanceof Array||a&&"object"==typeof a&&"function"==typeof a[B]&&"function"==typeof a.reverse)for(var k=0;k<a[w];k++)e(a[k]);else e(a);if(a=M[":"+f]){c&&!c.language&&c.locale&&(c.language=c.locale);c&&"string"==typeof c.callback&&(k=c.callback,k.match(/^[[\]A-Za-z0-9._]+$/)&&(k=g.eval(k),c.callback=
k));if((k=c&&null!=c.callback)&&!a.s(b))throw H("Module: '"+f+"' must be loaded before DOM onLoad!");k?a.m(b,c)?g[y](c.callback,0):a.load(b,c):a.m(b,c)||a.load(b,c)}else throw H("Module: '"+f+"' not found!");});K("google.load",google.load);
google.T=function(a,b){b?(0==O[w]&&(P(g,"load",Q),!D("msie")&&!D("safari")&&!D("konqueror")&&D("mozilla")||g.opera?g.addEventListener("DOMContentLoaded",Q,!1):D("msie")?h.write("<script defer onreadystatechange='google.loader.domReady()' src=//:>\x3c/script>"):(D("safari")||D("konqueror"))&&g[y](S,10)),O[m](a)):P(g,"load",a)};K("google.setOnLoadCallback",google.T);
function P(a,b,c){if(a.addEventListener)a.addEventListener(b,c,!1);else if(a.attachEvent)a.attachEvent("on"+b,c);else{var e=a["on"+b];a["on"+b]=null!=e?aa([c,e]):c}}function aa(a){return function(){for(var b=0;b<a[w];b++)a[b]()}}var O=[];google[z].P=function(){var a=g.event.srcElement;"complete"==a.readyState&&(a.onreadystatechange=null,a.parentNode.removeChild(a),Q())};K("google.loader.domReady",google[z].P);var ba={loaded:!0,complete:!0};function S(){ba[h.readyState]?Q():0<O[w]&&g[y](S,10)}
function Q(){for(var a=0;a<O[w];a++)O[a]();O.length=0}google[z].d=function(a,b,c){if(c){var e;"script"==a?(e=h.createElement("script"),e.type="text/javascript",e.src=b):"css"==a&&(e=h.createElement("link"),e.type="text/css",e.href=b,e.rel="stylesheet");(a=h.getElementsByTagName("head")[0])||(a=h.body.parentNode.appendChild(h.createElement("head")));a.appendChild(e)}else"script"==a?h.write('<script src="'+b+'" type="text/javascript">\x3c/script>'):"css"==a&&h.write('<link href="'+b+'" type="text/css" rel="stylesheet"></link>')};
K("google.loader.writeLoadTag",google[z].d);google[z].Q=function(a){N=a};K("google.loader.rfm",google[z].Q);google[z].S=function(a){for(var b in a)"string"==typeof b&&b&&":"==b[q](0)&&!M[b]&&(M[b]=new T(b[A](1),a[b]))};K("google.loader.rpl",google[z].S);google[z].R=function(a){if((a=a.specs)&&a[w])for(var b=0;b<a[w];++b){var c=a[b];"string"==typeof c?M[":"+c]=new U(c):(c=new V(c[u],c.baseSpec,c.customSpecs),M[":"+c[u]]=c)}};K("google.loader.rm",google[z].R);google[z].loaded=function(a){M[":"+a.module].l(a)};
K("google.loader.loaded",google[z].loaded);google[z].O=function(){return"qid="+((new Date)[v]().toString(16)+Math.floor(1E7*Math.random()).toString(16))};K("google.loader.createGuidArg_",google[z].O);I("google_exportSymbol",I);I("google_exportProperty",J);google[z].a={};K("google.loader.themes",google[z].a);google[z].a.I="//www.google.com/cse/style/look/bubblegum.css";L(google[z].a,"BUBBLEGUM",google[z].a.I);google[z].a.K="//www.google.com/cse/style/look/greensky.css";L(google[z].a,"GREENSKY",google[z].a.K);
google[z].a.J="//www.google.com/cse/style/look/espresso.css";L(google[z].a,"ESPRESSO",google[z].a.J);google[z].a.M="//www.google.com/cse/style/look/shiny.css";L(google[z].a,"SHINY",google[z].a.M);google[z].a.L="//www.google.com/cse/style/look/minimalist.css";L(google[z].a,"MINIMALIST",google[z].a.L);google[z].a.N="//www.google.com/cse/style/look/v2/default.css";L(google[z].a,"V2_DEFAULT",google[z].a.N);function U(a){this.b=a;this.o=[];this.n={};this.e={};this.f={};this.j=!0;this.c=-1}
U[x].g=function(a,b){var c="";void 0!=b&&(void 0!=b.language&&(c+="&hl="+d(b.language)),void 0!=b.nocss&&(c+="&output="+d("nocss="+b.nocss)),void 0!=b.nooldnames&&(c+="&nooldnames="+d(b.nooldnames)),void 0!=b.packages&&(c+="&packages="+d(b.packages)),null!=b.callback&&(c+="&async=2"),void 0!=b.style&&(c+="&style="+d(b.style)),void 0!=b.noexp&&(c+="&noexp=true"),void 0!=b.other_params&&(c+="&"+b.other_params));if(!this.j){google[this.b]&&google[this.b].JSHash&&(c+="&sig="+d(google[this.b].JSHash));
var e=[],f;for(f in this.n)":"==f[q](0)&&e[m](f[A](1));for(f in this.e)":"==f[q](0)&&this.e[f]&&e[m](f[A](1));c+="&have="+d(e[B](","))}return google[z][t]+"/?file="+this.b+"&v="+a+google[z].AdditionalParams+c};U[x].t=function(a){var b=null;a&&(b=a.packages);var c=null;if(b)if("string"==typeof b)c=[a.packages];else if(b[w])for(c=[],a=0;a<b[w];a++)"string"==typeof b[a]&&c[m](b[a][n](/^\s*|\s*$/,"")[C]());c||(c=["default"]);b=[];for(a=0;a<c[w];a++)this.n[":"+c[a]]||b[m](c[a]);return b};
l(U[x],function(a,b){var c=this.t(b),e=b&&null!=b.callback;if(e)var f=new W(b.callback);for(var k=[],p=c[w]-1;0<=p;p--){var s=c[p];e&&f.B(s);if(this.e[":"+s])c.splice(p,1),e&&this.f[":"+s][m](f);else k[m](s)}if(c[w]){b&&b.packages&&(b.packages=c.sort()[B](","));for(p=0;p<k[w];p++)s=k[p],this.f[":"+s]=[],e&&this.f[":"+s][m](f);if(b||null==N[":"+this.b]||null==N[":"+this.b].versions[":"+a]||google[z].AdditionalParams||!this.j)b&&b.autoloaded||google[z].d("script",this.g(a,b),e);else{c=N[":"+this.b];
google[this.b]=google[this.b]||{};for(var R in c.properties)R&&":"==R[q](0)&&(google[this.b][R[A](1)]=c.properties[R]);google[z].d("script",google[z][t]+c.path+c.js,e);c.css&&google[z].d("css",google[z][t]+c.path+c.css,e)}this.j&&(this.j=!1,this.c=(new Date)[v](),1!=this.c%100&&(this.c=-1));for(p=0;p<k[w];p++)s=k[p],this.e[":"+s]=!0}});
U[x].l=function(a){-1!=this.c&&(X("al_"+this.b,"jl."+((new Date)[v]()-this.c),!0),this.c=-1);this.o=this.o.concat(a.components);google[z][this.b]||(google[z][this.b]={});google[z][this.b].packages=this.o.slice(0);for(var b=0;b<a.components[w];b++){this.n[":"+a.components[b]]=!0;this.e[":"+a.components[b]]=!1;var c=this.f[":"+a.components[b]];if(c){for(var e=0;e<c[w];e++)c[e].C(a.components[b]);delete this.f[":"+a.components[b]]}}};U[x].m=function(a,b){return 0==this.t(b)[w]};U[x].s=function(){return!0};
function W(a){this.F=a;this.q={};this.r=0}W[x].B=function(a){this.r++;this.q[":"+a]=!0};W[x].C=function(a){this.q[":"+a]&&(this.q[":"+a]=!1,this.r--,0==this.r&&g[y](this.F,0))};function V(a,b,c){this.name=a;this.D=b;this.p=c;this.u=this.h=!1;this.k=[];google[z].v[this[u]]=G(this.l,this)}F(V,U);l(V[x],function(a,b){var c=b&&null!=b.callback;c?(this.k[m](b.callback),b.callback="google.loader.callbacks."+this[u]):this.h=!0;b&&b.autoloaded||google[z].d("script",this.g(a,b),c)});V[x].m=function(a,b){return b&&null!=b.callback?this.u:this.h};V[x].l=function(){this.u=!0;for(var a=0;a<this.k[w];a++)g[y](this.k[a],0);this.k=[]};
var Y=function(a,b){return a.string?d(a.string)+"="+d(b):a.regex?b[n](/(^.*$)/,a.regex):""};V[x].g=function(a,b){return this.G(this.w(a),a,b)};
V[x].G=function(a,b,c){var e="";a.key&&(e+="&"+Y(a.key,google[z].ApiKey));a.version&&(e+="&"+Y(a.version,b));b=google[z].Secure&&a.ssl?a.ssl:a.uri;if(null!=c)for(var f in c)a.params[f]?e+="&"+Y(a.params[f],c[f]):"other_params"==f?e+="&"+c[f]:"base_domain"==f&&(b="https://"+c[f]+a.uri[A](a.uri[r]("/",7)));google[this[u]]={};-1==b[r]("?")&&e&&(e="?"+e[A](1));return b+e};V[x].s=function(a){return this.w(a).deferred};V[x].w=function(a){if(this.p)for(var b=0;b<this.p[w];++b){var c=this.p[b];if(RegExp(c.pattern).test(a))return c}return this.D};function T(a,b){this.b=a;this.i=b;this.h=!1}F(T,U);l(T[x],function(a,b){this.h=!0;google[z].d("script",this.g(a,b),!1)});T[x].m=function(){return this.h};T[x].l=function(){};T[x].g=function(a,b){if(!this.i.versions[":"+a]){if(this.i.aliases){var c=this.i.aliases[":"+a];c&&(a=c)}if(!this.i.versions[":"+a])throw H("Module: '"+this.b+"' with version '"+a+"' not found!");}return google[z].GoogleApisBase+"/libs/"+this.b+"/"+a+"/"+this.i.versions[":"+a][b&&b.uncompressed?"uncompressed":"compressed"]};
T[x].s=function(){return!1};var ca=!1,Z=[],da=(new Date)[v](),fa=function(){ca||(P(g,"unload",ea),ca=!0)},ga=function(a,b){fa();if(!(google[z].Secure||google[z].Options&&!1!==google[z].Options.csi)){for(var c=0;c<a[w];c++)a[c]=d(a[c][C]()[n](/[^a-z0-9_.]+/g,"_"));for(c=0;c<b[w];c++)b[c]=d(b[c][C]()[n](/[^a-z0-9_.]+/g,"_"));g[y](G($,null,"//gg.google.com/csi?s=uds&v=2&action="+a[B](",")+"&it="+b[B](",")),1E4)}},X=function(a,b,c){c?ga([a],[b]):(fa(),Z[m]("r"+Z[w]+"="+d(a+(b?"|"+b:""))),g[y](ea,5<Z[w]?0:15E3))},ea=function(){if(Z[w]){var a=
google[z][t];0==a[r]("https:")&&(a=a[n](/^http:/,"https:"));$(a+"/stats?"+Z[B]("&")+"&nc="+(new Date)[v]()+"_"+((new Date)[v]()-da));Z.length=0}},$=function(a){var b=new Image,c=$.H++;$.A[c]=b;b.onload=b.onerror=function(){delete $.A[c]};b.src=a;b=null};$.A={};$.H=0;I("google.loader.recordCsiStat",ga);I("google.loader.recordStat",X);I("google.loader.createImageForLogging",$);

}) ();google.loader.rm({"specs":["feeds","spreadsheets","gdata","visualization",{"name":"sharing","baseSpec":{"uri":"https://www.google.com/s2/sharing/js","ssl":null,"key":{"string":"key"},"version":{"string":"v"},"deferred":false,"params":{"language":{"string":"hl"}}}},"search","orkut","ads","elements",{"name":"books","baseSpec":{"uri":"https://books.google.com/books/api.js","ssl":"https://encrypted.google.com/books/api.js","key":{"string":"key"},"version":{"string":"v"},"deferred":true,"params":{"callback":{"string":"callback"},"language":{"string":"hl"}}}},{"name":"friendconnect","baseSpec":{"uri":"https://www.google.com/friendconnect/script/friendconnect.js","ssl":"https://www.google.com/friendconnect/script/friendconnect.js","key":{"string":"key"},"version":{"string":"v"},"deferred":false,"params":{}}},"identitytoolkit","ima",{"name":"maps","baseSpec":{"uri":"https://maps.google.com/maps?file\u003dgoogleapi","ssl":"https://maps-api-ssl.google.com/maps?file\u003dgoogleapi","key":{"string":"key"},"version":{"string":"v"},"deferred":true,"params":{"callback":{"regex":"callback\u003d$1\u0026async\u003d2"},"language":{"string":"hl"}}},"customSpecs":[{"uri":"https://maps.googleapis.com/maps/api/js","ssl":"https://maps.googleapis.com/maps/api/js","version":{"string":"v"},"deferred":true,"params":{"callback":{"string":"callback"},"language":{"string":"hl"}},"pattern":"^(3|3..*)$"}]},"payments","wave","annotations_v2","earth","language",{"name":"annotations","baseSpec":{"uri":"https://www.google.com/reviews/scripts/annotations_bootstrap.js","ssl":null,"key":{"string":"key"},"version":{"string":"v"},"deferred":true,"params":{"callback":{"string":"callback"},"language":{"string":"hl"},"country":{"string":"gl"}}}},"picker"]});
google.loader.rfm({":search":{"versions":{":1":"1",":1.0":"1"},"path":"/api/search/1.0/ee93f9aae9c9e9dba5eea831d506e69a/","js":"default+en.I.js","css":"default+en.css","properties":{":JSHash":"ee93f9aae9c9e9dba5eea831d506e69a",":NoOldNames":false,":Version":"1.0"}},":language":{"versions":{":1":"1",":1.0":"1"},"path":"/api/language/1.0/aa67524fe978e85d12a837b6f572142f/","js":"default+en.I.js","properties":{":JSHash":"aa67524fe978e85d12a837b6f572142f",":Version":"1.0"}},":feeds":{"versions":{":1":"1",":1.0":"1"},"path":"/api/feeds/1.0/482f2817cdf8982edf2e5669f9e3a627/","js":"default+en.I.js","css":"default+en.css","properties":{":JSHash":"482f2817cdf8982edf2e5669f9e3a627",":Version":"1.0"}},":spreadsheets":{"versions":{":0":"1",":0.4":"1"},"path":"/api/spreadsheets/0.4/87ff7219e9f8a8164006cbf28d5e911a/","js":"default.I.js","properties":{":JSHash":"87ff7219e9f8a8164006cbf28d5e911a",":Version":"0.4"}},":ima":{"versions":{":3":"1",":3.0":"1"},"path":"/api/ima/3.0/28a914332232c9a8ac0ae8da68b1006e/","js":"default.I.js","properties":{":JSHash":"28a914332232c9a8ac0ae8da68b1006e",":Version":"3.0"}},":wave":{"versions":{":1":"1",":1.0":"1"},"path":"/api/wave/1.0/3b6f7573ff78da6602dda5e09c9025bf/","js":"default.I.js","properties":{":JSHash":"3b6f7573ff78da6602dda5e09c9025bf",":Version":"1.0"}},":earth":{"versions":{":1":"1",":1.0":"1"},"path":"/api/earth/1.0/db22e5693e0a8de1f62f3536f5a8d7d3/","js":"default.I.js","properties":{":JSHash":"db22e5693e0a8de1f62f3536f5a8d7d3",":Version":"1.0"}},":annotations":{"versions":{":1":"1",":1.0":"1"},"path":"/api/annotations/1.0/bacce7b6155a1bbadda3c05d65391b22/","js":"default+en.I.js","properties":{":JSHash":"bacce7b6155a1bbadda3c05d65391b22",":Version":"1.0"}},":picker":{"versions":{":1":"1",":1.0":"1"},"path":"/api/picker/1.0/1c635e91b9d0c082c660a42091913907/","js":"default.I.js","css":"default.css","properties":{":JSHash":"1c635e91b9d0c082c660a42091913907",":Version":"1.0"}}});
google.loader.rpl({":scriptaculous":{"versions":{":1.8.3":{"uncompressed":"scriptaculous.js","compressed":"scriptaculous.js"},":1.9.0":{"uncompressed":"scriptaculous.js","compressed":"scriptaculous.js"},":1.8.2":{"uncompressed":"scriptaculous.js","compressed":"scriptaculous.js"},":1.8.1":{"uncompressed":"scriptaculous.js","compressed":"scriptaculous.js"}},"aliases":{":1.8":"1.8.3",":1":"1.9.0",":1.9":"1.9.0"}},":yui":{"versions":{":2.6.0":{"uncompressed":"build/yuiloader/yuiloader.js","compressed":"build/yuiloader/yuiloader-min.js"},":2.9.0":{"uncompressed":"build/yuiloader/yuiloader.js","compressed":"build/yuiloader/yuiloader-min.js"},":2.7.0":{"uncompressed":"build/yuiloader/yuiloader.js","compressed":"build/yuiloader/yuiloader-min.js"},":2.8.0r4":{"uncompressed":"build/yuiloader/yuiloader.js","compressed":"build/yuiloader/yuiloader-min.js"},":2.8.2r1":{"uncompressed":"build/yuiloader/yuiloader.js","compressed":"build/yuiloader/yuiloader-min.js"},":2.8.1":{"uncompressed":"build/yuiloader/yuiloader.js","compressed":"build/yuiloader/yuiloader-min.js"},":3.3.0":{"uncompressed":"build/yui/yui.js","compressed":"build/yui/yui-min.js"}},"aliases":{":3":"3.3.0",":2":"2.9.0",":2.7":"2.7.0",":2.8.2":"2.8.2r1",":2.6":"2.6.0",":2.9":"2.9.0",":2.8":"2.8.2r1",":2.8.0":"2.8.0r4",":3.3":"3.3.0"}},":swfobject":{"versions":{":2.1":{"uncompressed":"swfobject_src.js","compressed":"swfobject.js"},":2.2":{"uncompressed":"swfobject_src.js","compressed":"swfobject.js"}},"aliases":{":2":"2.2"}},":webfont":{"versions":{":1.0.28":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.27":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.29":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.12":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.13":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.14":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.15":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.10":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.11":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.2":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.1":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.0":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.6":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.19":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.5":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.18":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.4":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.17":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.3":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.16":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.9":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.21":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.22":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.25":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.26":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.23":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"},":1.0.24":{"uncompressed":"webfont_debug.js","compressed":"webfont.js"}},"aliases":{":1":"1.0.29",":1.0":"1.0.29"}},":ext-core":{"versions":{":3.1.0":{"uncompressed":"ext-core-debug.js","compressed":"ext-core.js"},":3.0.0":{"uncompressed":"ext-core-debug.js","compressed":"ext-core.js"}},"aliases":{":3":"3.1.0",":3.0":"3.0.0",":3.1":"3.1.0"}},":mootools":{"versions":{":1.3.1":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.1.1":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.3.0":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.3.2":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.1.2":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.2.3":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.2.4":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.2.1":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.2.2":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.2.5":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.4.0":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.4.1":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"},":1.4.2":{"uncompressed":"mootools.js","compressed":"mootools-yui-compressed.js"}},"aliases":{":1":"1.1.2",":1.11":"1.1.1",":1.4":"1.4.2",":1.3":"1.3.2",":1.2":"1.2.5",":1.1":"1.1.2"}},":jqueryui":{"versions":{":1.8.0":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.2":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.1":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.15":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.14":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.13":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.12":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.11":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.10":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.17":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.16":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.6.0":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.9":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.7":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.8":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.7.2":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.5":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.7.3":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.6":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.7.0":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.7.1":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.8.4":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.5.3":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"},":1.5.2":{"uncompressed":"jquery-ui.js","compressed":"jquery-ui.min.js"}},"aliases":{":1.8":"1.8.17",":1.7":"1.7.3",":1.6":"1.6.0",":1":"1.8.17",":1.5":"1.5.3",":1.8.3":"1.8.4"}},":chrome-frame":{"versions":{":1.0.2":{"uncompressed":"CFInstall.js","compressed":"CFInstall.min.js"},":1.0.1":{"uncompressed":"CFInstall.js","compressed":"CFInstall.min.js"},":1.0.0":{"uncompressed":"CFInstall.js","compressed":"CFInstall.min.js"}},"aliases":{":1":"1.0.2",":1.0":"1.0.2"}},":jquery":{"versions":{":1.6.2":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.3.1":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.6.1":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.3.0":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.6.4":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.6.3":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.3.2":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.6.0":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.2.3":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.7.0":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.7.1":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.2.6":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.4.3":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.4.4":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.5.1":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.5.0":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.4.0":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.5.2":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.4.1":{"uncompressed":"jquery.js","compressed":"jquery.min.js"},":1.4.2":{"uncompressed":"jquery.js","compressed":"jquery.min.js"}},"aliases":{":1.7":"1.7.1",":1.6":"1.6.4",":1":"1.7.1",":1.5":"1.5.2",":1.4":"1.4.4",":1.3":"1.3.2",":1.2":"1.2.6"}},":dojo":{"versions":{":1.3.1":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.3.0":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.6.1":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.1.1":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.3.2":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.6.0":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.2.3":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.7.2":{"uncompressed":"dojo/dojo.js.uncompressed.js","compressed":"dojo/dojo.js"},":1.7.0":{"uncompressed":"dojo/dojo.js.uncompressed.js","compressed":"dojo/dojo.js"},":1.7.1":{"uncompressed":"dojo/dojo.js.uncompressed.js","compressed":"dojo/dojo.js"},":1.4.3":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.5.1":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.5.0":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.2.0":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.4.0":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"},":1.4.1":{"uncompressed":"dojo/dojo.xd.js.uncompressed.js","compressed":"dojo/dojo.xd.js"}},"aliases":{":1.7":"1.7.2",":1":"1.6.1",":1.6":"1.6.1",":1.5":"1.5.1",":1.4":"1.4.3",":1.3":"1.3.2",":1.2":"1.2.3",":1.1":"1.1.1"}},":prototype":{"versions":{":1.7.0.0":{"uncompressed":"prototype.js","compressed":"prototype.js"},":1.6.0.2":{"uncompressed":"prototype.js","compressed":"prototype.js"},":1.6.1.0":{"uncompressed":"prototype.js","compressed":"prototype.js"},":1.6.0.3":{"uncompressed":"prototype.js","compressed":"prototype.js"}},"aliases":{":1.7":"1.7.0.0",":1.6.1":"1.6.1.0",":1":"1.7.0.0",":1.6":"1.6.1.0",":1.7.0":"1.7.0.0",":1.6.0":"1.6.0.3"}}});
}
/**************************************https://www.google.com/uds/?file=elements&v=1&packages=transliteration****************************************/
if (window['google'] != undefined && window['google']['loader'] != undefined) {
if (!window['google']['elements']) {
window['google']['elements'] = {};
google.elements.Version = '1.0';
google.elements.JSHash = '53cb38ca35d63cf81c13fdb4e1addec2';
google.elements.LoadArgs = 'file\75elements\46v\0751\46packages\75transliteration';
}
google.loader.writeLoadTag("css", google.loader.ServiceBase + "/api/elements/1.0/53cb38ca35d63cf81c13fdb4e1addec2/transliteration.css", false);
//google.loader.writeLoadTag("script", google.loader.ServiceBase + "/api/elements/1.0/53cb38ca35d63cf81c13fdb4e1addec2/transliteration.I.js", false);
}

/****************************** transliterate.I.js ****************************/


(function () {
    (function () {
        function e(a) {
            throw a;
        }
        var i = void 0,
            j = null,
            aa = encodeURIComponent,
            l = window,
            ba = Object,
            ca = Infinity,
            m = Error,
            da = parseInt,
            ea = parseFloat,
            n = String,
            fa = Function,
            p = document,
            ga = decodeURIComponent,
            ha = isNaN,
            ia = Array,
            r = Math;

        function ja(a, b) {
            return a.width = b
        }

        function ka(a, b) {
            return a.innerHTML = b
        }

        function la(a, b) {
            return a.selected = b
        }

        function ma(a, b) {
            return a.currentTarget = b
        }

        function na(a, b) {
            return a.left = b
        }

        function oa(a, b) {
            return a.screenX = b
        }

        function pa(a, b) {
            return a.screenY = b
        }

        function qa(a, b) {
            return a.status = b
        }

        function ra(a, b) {
            return a.remove = b
        }

        function sa(a, b) {
            return a.keyCode = b
        }

        function ta(a, b) {
            return a.select = b
        }

        function va(a, b) {
            return a.handleEvent = b
        }

        function wa(a, b) {
            return a.type = b
        }

        function xa(a, b) {
            return a.clear = b
        }

        function ya(a, b) {
            return a.clientX = b
        }

        function za(a, b) {
            return a.clientY = b
        }

        function Aa(a, b) {
            return a.visibility = b
        }

        function Ba(a, b) {
            return a.length = b
        }

        function Ca(a, b) {
            return a.className = b
        }

        function Da(a, b) {
            return a.next = b
        }

        function Ea(a, b) {
            return a.target = b
        }

        function Fa(a, b) {
            return a.contains = b
        }

        function Ga(a, b) {
            return a.reset = b
        }

        function Ha(a, b) {
            return a.height = b
        }

        function Ia(a, b) {
            return a.nodeValue = b
        }
        var Ja = "appendChild",
            s = "push",
            Ka = "getBoundingClientRect",
            Ma = "test",
            Na = "shift",
            Oa = "relatedTarget",
            Pa = "exec",
            t = "width",
            Qa = "text",
            Ra = "collapse",
            Sa = "slice",
            u = "replace",
            Ta = "inRange",
            v = "nodeType",
            Ua = "ceil",
            Va = "floor",
            Wa = "getElementById",
            Xa = "concat",
            Ya = "charAt",
            Za = "selected",
            $a = "createTextNode",
            ab = "value",
            bb = "preventDefault",
            cb = "item",
            db = "insertBefore",
            eb = "targetTouches",
            fb = "move",
            x = "indexOf",
            gb = "metaKey",
            hb = "compareDocumentPosition",
            ib = "setEnd",
            jb = "jstiming",
            kb = "capture",
            lb = "nodeName",
            mb = "currentTarget",
            nb = "createRange",
            y = "left",
            ob = "screenX",
            pb = "screenY",
            qb = "match",
            rb = "createTextRange",
            sb = "status",
            tb = "getBoxObjectFor",
            ub = "fromCharCode",
            vb = "charCode",
            wb = "focus",
            xb = "createElement",
            A = "keyCode",
            B = "firstChild",
            yb = "select",
            zb = "forEach",
            Ab = "clientLeft",
            Bb = "addEventListener",
            Cb = "setAttribute",
            Db = "clientTop",
            Eb = "handleEvent",
            Fb = "parentElement",
            Gb = "execCommand",
            C = "type",
            Hb = "clear",
            D = "childNodes",
            Ib = "defaultView",
            Jb = "bind",
            Kb = "rangeCount",
            Lb = "name",
            Mb = "nextSibling",
            Nb = "duplicate",
            Ob = "clientX",
            Pb = "clientY",
            Qb = "documentElement",
            Rb = "substr",
            Sb = "external",
            Tb = "scrollTop",
            Ub = "previousSibling",
            Vb = "stop",
            Wb = "toString",
            Xb = "altKey",
            Yb = "setStart",
            E = "length",
            Zb = "propertyIsEnumerable",
            $b = "htmlText",
            F = "prototype",
            ac = "sourceIndex",
            bc = "className",
            cc = "clientWidth",
            dc = "setTimeout",
            ec = "document",
            fc = "removeEventListener",
            gc = "next",
            hc = "ctrlKey",
            ic = "split",
            jc = "stopPropagation",
            kc = "moveToElementText",
            lc = "hasOwnProperty",
            G = "style",
            mc = "body",
            nc = "ownerDocument",
            oc = "removeChild",
            H = "target",
            pc = "lastChild",
            I = "call",
            qc = "isEnabled",
            rc = "moveEnd",
            sc = "start",
            tc = "cloneRange",
            uc = "clientHeight",
            vc = "scrollLeft",
            wc = "charCodeAt",
            xc = "bottom",
            yc = "compareEndPoints",
            J = "substring",
            zc = "contains",
            Ac = "apply",
            Bc = "shiftKey",
            Cc = "tagName",
            Dc = "reset",
            Ec = "removeAttribute",
            K = "parentNode",
            Fc = "offsetTop",
            Gc = "height",
            Hc = "toUpperCase",
            Ic = "splice",
            L = "join",
            Jc = "unshift",
            Kc = "nodeValue",
            Lc = "toLowerCase",
            Mc = "right",
            M = "",
            Nc = "\n",
            Oc = "\r\n",
            N = " ",
            Pc = " in targetLangCode array",
            Qc = ' name="',
            Rc = " targetLangCode: ",
            Sc = " targetLanguage: ",
            Tc = ' type="',
            Uc = '"',
            Vc = "#",
            Wc = "#$1$1$2$2$3$3",
            Xc = "#FFFFAA",
            Yc = "#ffa",
            Zc = "$1-",
            $c = "%",
            ad = "&",
            bd = "&action=",
            cd = "&amp;",
            dd = "&apa=1",
            ed = "&gt;",
            fd = "&it=",
            gd = "&lt;",
            hd = "&nbsp;",
            id = "&npn=1",
            jd = "&p=s",
            kd = "&quot;",
            ld = "&rt=",
            md = "&s=",
            nd = "&srt=",
            od = "&tran=",
            pd = "'",
            qd = "(\\d*)(\\D*)",
            sd = ")",
            td = "*",
            ud = "+",
            vd = ",",
            wd = ", ",
            xd = "-",
            yd = "-9",
            zd = "-active",
            Ad = "-body",
            Bd = "-caption",
            Cd = "-cell",
            Dd = "-cell-hover",
            Ed = "-cell-selected",
            Fd = "-checkbox",
            Gd = "-checked",
            Hd = "-colorswatch",
            Id = "-content",
            Jd = "-disabled",
            Kd = "-dropdown",
            Ld = "-focused",
            Md = "-footer",
            Nd =
                "-footer-end",
            Od = "-highlight",
            Pd = "-horizontal",
            Qd = "-hover",
            Rd = "-indicator",
            Sd = "-inner-box",
            Td = "-input",
            Ud = "-logo",
            Vd = "-nav",
            Wd = "-navbutton",
            Xd = "-open",
            Yd = "-outer-box",
            Zd = "-pagedown ",
            $d = "-pageup ",
            ae = "-row",
            be = "-rtl",
            ce = "-segment",
            de = "-segment-highlighted",
            ee = "-selected",
            fe = "-table",
            ge = "-vertical",
            he = ".",
            ie = "/",
            je = "//",
            ke = "/inputtools/request",
            le = "0",
            me = "1",
            ne = "1.5",
            oe = "1.5em",
            pe = "1.8",
            qe = "1.9",
            re = "14px",
            se = "1em",
            te = "5.7",
            ue = "500",
            ve = "525",
            we = "525.0",
            xe = "528",
            ye = "533.17.9",
            ze = "6",
            Ae = "7",
            Be = "8",
            Ce =
                ":",
            De = ": should be an array or a string",
            Ee = ";0;0",
            Fe = "<",
            Ge = '<TABLE style="width:100%;"><TBODY><TR><TD style="width:100%;"></TD><TD width="54px"></TD></TR></TBODY></TABLE>',
            He = '<TABLE style="width:100%;"><TBODY><TR><TD style="width:100%;"></TD><TD width="63px"></TD></TR></TBODY></TABLE>',
            Ie = "<TABLE><TBODY><TR><TD></TD></TR></TBODY></TABLE>",
            Je = "<br>",
            Ke = "=",
            Le = ">",
            Me = "?",
            Ne = "?v=3",
            Oe = "@",
            Pe = "APPLET",
            Qe = "AREA",
            Re = "Arial,Helvetica,sans-serif",
            Se = "BASE",
            Te = "BODY",
            Ue = "BR",
            Ve = "BUTTON",
            We = "Bottom",
            Xe =
                "COL",
            Ye = "CSS1Compat",
            Ze = "Component already rendered",
            $e = "ControlType",
            af = "Controller",
            bf = "DIV",
            cf = "End",
            df = "EndToEnd",
            ef = "EndToStart",
            ff = "EventType",
            gf = "FRAME",
            hf = "FontName",
            jf = "Google ta3reeb",
            kf = "HR",
            lf = "HTML",
            mf = "IFRAME",
            nf = "IMG",
            of = "INPUT",
            pf = "ISINDEX",
            qf = "Incorrect targetLangCode parameter ",
            rf = "Input is not an array of ids or element references",
            sf = "Input text too long.",
            tf = "Invalid element id ",
            uf = "Invalid event type",
            vf = "Invalid event type:",
            xf = "Invalid listener argument",
            yf = "Invalid shortcut key",
            zf = "KeyEvents",
            Af = "LINK",
            Bf = "Left",
            Cf = "META",
            Df = "NOFRAMES",
            Ef = "NOSCRIPT",
            Ff = "No div exists with id ",
            Gf = "OBJECT",
            Hf = "PARAM",
            If = "PRE",
            Jf = "RGB (",
            Kf = "Right",
            Lf = "SCRIPT",
            Mf = "SELECT",
            Nf = "SPAN",
            Of = "STYLE",
            Pf = "SUCCESS",
            Qf = "Start",
            Rf = "StartToEnd",
            Sf = "StartToStart",
            Tf = "Style",
            Uf = "TD",
            Vf = "TEXTAREA",
            Wf = "TR",
            Xf = "To",
            Yf = "Top",
            Zf = "UTF-8",
            $f = "Unable to set parent component",
            ag = "Unsupported language ",
            bg = "Unsupported sourceLangCode & targetLangCode pair: sourceLangCode: ",
            cg = "Unsupported sourceLanguage & targetLanguage pair: sourceLanguage: ",
            dg = "Width",
            eg = "[object Array]",
            fg = "[object Function]",
            gg = "[object Window]",
            hg = "_",
            ig = "_TRN_",
            jg = "_callbacks_.",
            kg = "_h#",
            lg = "_rs",
            mg = "`",
            ng = "`'",
            og = "`_-'",
            pg = "a",
            qg = "absolute",
            rg = "action",
            sg = "activate",
            tg = "activedescendant",
            ug = "activedescendent",
            vg = "addEventListener",
            wg = "afterhide",
            xg = "aftershow",
            yg = "alt",
            zg = "altKey",
            Ag = "am",
            Bg = "amp",
            Cg = "ar",
            Dg = "arc",
            Eg = "aria-",
            Fg = "array",
            Gg = "auto",
            Hg = "background-color",
            Ig = "background-color:",
            Jg = "beforedrag",
            Kg = "beforeshow",
            Lg = "block",
            Mg = "blur",
            Ng = "boolean",
            Og = "borderBottom",
            Pg = "borderBottomWidth",
            Qg = "borderLeft",
            Rg = "borderLeftWidth",
            Sg = "borderRight",
            Tg = "borderRightWidth",
            Ug = "borderTop",
            Vg = "borderTopWidth",
            Wg = "break-word",
            Xg = "button",
            Yg = "call",
            Zg = "callback",
            $g = "callee",
            ah = "cb",
            bh = "changeState",
            ch = "character",
            dh = "check",
            eh = "checked",
            fh = "class",
            gh = "click",
            hh = "close",
            ih = "composition",
            jh = "contextmenu",
            kh = "control",
            lh = "conversion",
            mh = "copy",
            nh = "css:",
            oh = "ctrl",
            ph = "ctrl+g",
            qh = "ctrlKey",
            rh = "cut",
            sh = "cvc",
            th = "dblclick",
            uh = "deactivate",
            vh = "dir",
            wh = "direction",
            xh = "disable",
            yh =
                "disabled",
            zh = "discard",
            Ah = "display",
            O = "div",
            Bh = "document",
            Ch = "drag",
            Dh = "dragstart",
            Eh = "earlycancel",
            Fh = "en",
            Gh = "enable",
            Hh = "end",
            Ih = "enter",
            Jh = "expanded",
            Kh = "f",
            Lh = "fa",
            Mh = "fetch",
            Nh = "fixed",
            Oh = "focus",
            Ph = "font-size",
            Qh = "fontFamily",
            Rh = "fontSize",
            Sh = "fontStyle",
            Th = "fontWeight",
            Uh = "for",
            Vh = "function",
            Wh = "g",
            Xh = "ge",
            Yh = "goog_",
            Zh = "goog_input_bookmarklet",
            $h = "google.elements.transliteration",
            ai = "google.elements.transliteration.SupportedDestinationLanguages",
            bi = "google.elements.transliteration.getDestinationLanguages",
            ci = "google.elements.transliteration.isBrowserCompatible",
            di = "grid",
            ei = "gridcell",
            fi = "gt",
            gi = "haspopup",
            hi = "head",
            ii = "height:18px;width:7px;",
            ji = "hex",
            ki = "hi",
            li = "hidden",
            mi = "hide",
            ni = "highlight",
            oi = "horizontal",
            pi = "http://csi.gstatic.com/csi",
            qi = "https://www.google.com",
            ri = "https:",
            si = "https://csi.gstatic.com/csi",
            ti = "i",
            ui = "i18n_input",
            vi = "id",
            wi = "iframe",
            xi = "inline",
            yi = "innerText",
            zi = "inputapi-button",
            Ai = "inputapi-color-menu-button",
            Bi = "inputapi-color-menu-button-indicator",
            Ci = "inputapi-control",
            Di = "inputapi-custom-button",
            Ei = "inputapi-custom-button-collapse-right",
            Fi = "inputapi-inline-block",
            Gi = "inputapi-inline-block ",
            Hi = "inputapi-menu-button",
            Ii = "inputapi-menuheader",
            Ji = "inputapi-menuitem",
            Ki = "inputapi-menuitem-accel",
            Li = "inputapi-menuseparator",
            Mi = "inputapi-multisegmentpopupeditor",
            Ni = "inputapi-multisegmentpopupeditor-menuitem",
            Oi = "inputapi-option",
            Pi = "inputapi-option-selected",
            Qi = "inputapi-popupeditor",
            Ri = "inputapi-popupeditor-cursor",
            Si = "inputapi-popupeditor-menuitem",
            Ti = "inputapi-toolbar-button",
            Ui = "inputapi-toolbar-color-menu-button",
            Vi = "inputapi-toolbar-menu-button",
            Wi = "inputapi-transliterate-button",
            Xi = "inputapi-transliterate-ie6-",
            Yi = "inputapi-transliterate-img inputapi-transliterate-img-button-",
            Zi = "inputapi-transliterate-img inputapi-transliterate-img-langmenu-",
            $i = "inputapi-transliterate-img-button-",
            aj = "inputapi-transliterate-img-dropdown",
            bj = "inputapi-transliterate-img-ie6 inputapi-transliterate-img-ie6-button inputapi-transliterate-ie6-",
            cj = "inputapi-transliterate-img-ie6 inputapi-transliterate-img-ie6-dropdown",
            dj = "inputapi-transliterate-img-ie6 inputapi-transliterate-img-ie6-langmenu inputapi-transliterate-ie6-",
            ej = "inputapi-transliterate-img-ie6-button-parent",
            fj = "inputapi-transliterate-img-ie6-dropdown-parent",
            gj = "inputapi-transliterate-img-ie6-langmenu-parent",
            hj = "inputapi-transliterate-indic-button",
            ij = "inputapi-transliterate-indic-suggestion-menu",
            jj = "inputapi-transliterate-indic-suggestion-menuitem",
            kj = "iw",
            lj = "ja",
            mj = "ja-Hira",
            nj = "key",
            oj = "keydown",
            pj = "keypress",
            qj = "keyup",
            rj = "lc",
            sj = "leave",
            tj =
                "letterSpacing",
            uj = "li",
            vj = "line-height",
            wj = "lineHeight",
            xj = "losecapture",
            yj = "lt",
            zj = "ltr",
            Aj = "makeTransliteratable",
            Bj = "margin",
            Cj = "menuitemcheckbox",
            Dj = "menuitemradio",
            Ej = "meta",
            Fj = "metaKey",
            Gj = "mousedown",
            Hj = "mousemove",
            Ij = "mouseout",
            Jj = "mouseover",
            Kj = "mouseup",
            Lj = "multi",
            Mj = "n",
            Nj = "named",
            Oj = "native code",
            Pj = "nextSibling",
            Qj = "nodeType",
            Rj = "none",
            Sj = "null",
            Tj = "number",
            Uj = "o",
            Vj = "object",
            Wj = "on",
            Xj = "open",
            Yj = "options not specified",
            Zj = "overflow",
            $j = "overflowX",
            ak = "overflowY",
            bk = "p",
            ck = "padding",
            dk = "password",
            ek = "paste",
            fk = "pgDn",
            gk = "pgUp",
            hk = "pinyin",
            ik = "platformModifierKey",
            jk = "position",
            kk = "pre",
            lk = "pre-wrap",
            mk = "prerender",
            nk = "pressed",
            ok = "previousSibling",
            pk = "px",
            qk = "px solid red",
            rk = "quot",
            sk = "r#",
            tk = "re",
            uk = "relative",
            vk = "removeEventListener",
            wk = "rgb",
            xk = "role",
            yk = "rtl",
            zk = "rtt",
            Ak = "ru",
            Bk = "s",
            Ck = "sc",
            Dk = "script",
            Ek = "scroll",
            Fk = "select",
            Gk = "selected",
            Hk = "separator",
            Ik = "setLanguagePair",
            Jk = "shift",
            Kk = "shiftKey",
            Lk = "shortcut",
            Mk = "shortcutKey",
            Nk = "shortcut_",
            Ok = "show",
            Pk = "showControl",
            Qk = "single",
            Rk = "source",
            Sk = "sourceIndex",
            Tk = "span",
            Uk = "splice",
            Vk = "sr",
            Wk = "start",
            Xk = "state",
            Yk = "static",
            Zk = "string",
            $k = "style",
            al = "su",
            bl = "success",
            cl = "t13n.changeState",
            dl = "tabIndex",
            el = "tabindex",
            fl = "table",
            gl = "tbody",
            hl = "td",
            il = "te",
            jl = "text",
            kl = "text/javascript",
            ll = "textAlign",
            ml = "textContent",
            nl = "textDecoration",
            ol = "textTransform",
            pl = "textarea",
            ql = "ti",
            rl = "ti_all,ti_",
            sl = "tick",
            tl = "touchcancel",
            ul = "touchend",
            vl = "touchmove",
            wl = "touchstart",
            xl = "tr",
            yl = "transliteration_en_",
            zl = "transliteration_ja-Hira_ja",
            Al = "transparent",
            Bl = "true",
            Cl = "uncheck",
            Dl = "unhighlight",
            El = "unselect",
            Fl = "unselectable",
            Gl = "ur",
            Hl = "utf-8",
            Il = "var ",
            Jl = "vertical",
            Kl = "verticalAlign",
            Ll = "visibility:hidden;position:absolute;line-height:0;padding:0;margin:0;border:0;height:1em;",
            Ml = "visible",
            Nl = "webkitvisibilitychange",
            Ol = "width:18px;height:18px;",
            Ql = "width:60px;height:20px",
            Rl = "wordSpacing",
            Sl = "wordWrap",
            Tl = "y",
            Ul = "zh",
            Vl = "|",
            Wl = "||t:1",
            Xl = "\u00a0",
            Yl = "\u00a5",
            Zl = "\u0106\u0107\u010c\u010d\u0110\u0111\u0160\u0161\u017d\u017e",
            $l =
                "\u200b",
            am = "\u3000";

        function bm() {
            return function () {}
        }

        function cm(a) {
            return function (b) {
                this[a] = b
            }
        }

        function dm(a) {
            return function () {
                return this[a]
            }
        }

        function P(a) {
            return function () {
                return a
            }
        }
        var Q;

        function em(a) {
            this.t = {};
            this.tick = function (a, c, d) {
                this.t[a] = [d != i ? d : (new Date).getTime(), c]
            };
            this.tick(Wk, j, a)
        }

        function fm(a, b) {
            var c = a[ic](he),
                d = R;
            !(c[0] in d) && d.execScript && d.execScript(Il + c[0]);
            for (var f; c[E] && (f = c[Na]());)!c[E] && gm(b) ? d[f] = b : d = d[f] ? d[f] : d[f] = {}
        }

        function hm() {}

        function im(a) {
            a.Q = function () {
                return a.Mj || (a.Mj = new a)
            }
        }

        function jm(a) {
            var b = typeof a;
            if (b == Vj)
                if (a) {
                    if (a instanceof ia) return Fg;
                    else if (a instanceof ba) return b;
                    var c = ba[F][Wb][I](a);
                    if (c == gg) return Vj;
                    if (c == eg || typeof a[E] == Tj && typeof a[Ic] != "undefined" && typeof a[Zb] != "undefined" && !a[Zb](Uk)) return Fg;
                    if (c == fg || typeof a[I] != "undefined" && typeof a[Zb] != "undefined" && !a[Zb](Yg)) return Vh
                } else return Sj;
                else if (b == Vh && typeof a[I] == "undefined") return Vj;
            return b
        }

        function gm(a) {
            return a !== i
        }

        function km(a) {
            return jm(a) == Fg
        }

        function lm(a) {
            var b = jm(a);
            return b == Fg || b == Vj && typeof a[E] == Tj
        }

        function S(a) {
            return typeof a == Zk
        }

        function mm(a) {
            return typeof a == Ng
        }

        function nm(a) {
            return typeof a == Tj
        }

        function om(a) {
            return jm(a) == Vh
        }

        function pm(a) {
            a = jm(a);
            return a == Vj || a == Fg || a == Vh
        }

        function qm(a) {
            return a[rm] || (a[rm] = ++sm)
        }

        function tm(a, b, c) {
            return a[I][Ac](a[Jb], arguments)
        }

        function um(a, b, c) {
            a || e(m());
            if (arguments[E] > 2) {
                var d = ia[F][Sa][I](arguments, 2);
                return function () {
                    var c = ia[F][Sa][I](arguments);
                    ia[F][Jc][Ac](c, d);
                    return a[Ac](b, c)
                }
            } else return function () {
                return a[Ac](b, arguments)
            }
        }

        function T(a, b, c) {
            T = fa[F][Jb] && fa[F][Jb][Wb]()[x](Oj) != -1 ? tm : um;
            return T[Ac](j, arguments)
        }

        function vm(a, b) {
            var c = ia[F][Sa][I](arguments, 1);
            return function () {
                var b = ia[F][Sa][I](arguments);
                b[Jc][Ac](b, c);
                return a[Ac](this, b)
            }
        }

        function wm(a, b, c) {
            a[b] = c
        }

        function U(a, b) {
            function c() {}
            c.prototype = b[F];
            a.g = b[F];
            a.prototype = new c;
            a[F].constructor = a
        }

        function xm(a) {
            return /^[\s\xa0]*$/ [Ma](a)
        }

        function ym(a) {
            return a[u](/[\t\r\n ]+/g, N)[u](/^[\t\r\n ]+|[\t\r\n ]+$/g, M)
        }

        function zm(a) {
            return a[u](/^[\s\xa0]+|[\s\xa0]+$/g, M)
        }

        function Am(a) {
            a = n(a);
            return !Bm[Ma](a) ? aa(a) : a
        }

        function Cm(a) {
            if (!Dm[Ma](a)) return a;
            a[x](ad) != -1 && (a = a[u](Em, cd));
            a[x](Fe) != -1 && (a = a[u](Fm, gd));
            a[x](Le) != -1 && (a = a[u](Gm, ed));
            a[x](Uc) != -1 && (a = a[u](Hm, kd));
            return a
        }

        function Im(a) {
            return a[x](ad) != -1 ? Bh in R ? Jm(a) : Km(a) : a
        }

        function Jm(a) {
            var b = {
                "&amp;": ad,
                "&lt;": Fe,
                "&gt;": Le,
                "&quot;": Uc
            }, c = p[xb](O);
            return a[u](Lm, function (a, f) {
                var g = b[a];
                if (g) return g;
                if (f[Ya](0) == Vc) {
                    var h = Number(le + f[Rb](1));
                    ha(h) || (g = n[ub](h))
                }
                g || (ka(c, a + N), g = c[B][Kc][Sa](0, -1));
                return b[a] = g
            })
        }

        function Km(a) {
            return a[u](/&([^;]+);/g, function (a, c) {
                switch (c) {
                case Bg:
                    return ad;
                case yj:
                    return Fe;
                case fi:
                    return Le;
                case rk:
                    return Uc;
                default:
                    if (c[Ya](0) == Vc) {
                        var d = Number(le + c[Rb](1));
                        if (!ha(d)) return n[ub](d)
                    }
                    return a
                }
            })
        }

        function Mm(a, b) {
            for (var c = 0, d = zm(n(a))[ic](he), f = zm(n(b))[ic](he), g = r.max(d[E], f[E]), h = 0; c == 0 && h < g; h++) {
                var k = d[h] || M,
                    o = f[h] || M,
                    q = RegExp(qd, Wh),
                    w = RegExp(qd, Wh);
                do {
                    var z = q[Pa](k) || [M, M, M],
                        ua = w[Pa](o) || [M, M, M];
                    if (z[0][E] == 0 && ua[0][E] == 0) break;
                    c = Nm(z[1][E] == 0 ? 0 : da(z[1], 10), ua[1][E] == 0 ? 0 : da(ua[1], 10)) || Nm(z[2][E] == 0, ua[2][E] == 0) || Nm(z[2], ua[2])
                } while (c == 0)
            }
            return c
        }

        function Nm(a, b) {
            if (a < b) return -1;
            else if (a > b) return 1;
            return 0
        }

        function Om(a) {
            var b = Number(a);
            return b == 0 && xm(a) ? NaN : b
        }

        function Pm(a) {
            return Qm[a] || (Qm[a] = n(a)[u](/\-([a-z])/g, function (a, c) {
                return c[Hc]()
            }))
        }

        function Rm(a) {
            return a[a[E] - 1]
        }

        function Sm(a, b, c, d) {
            if (a.reduce) return d ? a.reduce(T(b, d), c) : a.reduce(b, c);
            var f = c;
            V(a, function (c, h) {
                f = b[I](d, f, c, h, a)
            });
            return f
        }

        function Tm(a, b, c) {
            b = Um(a, b, c);
            return b < 0 ? j : S(a) ? a[Ya](b) : a[b]
        }

        function Um(a, b, c) {
            for (var d = a[E], f = S(a) ? a[ic](M) : a, g = 0; g < d; g++)
                if (g in f && b[I](c, f[g], g, a)) return g;
            return -1
        }

        function Vm(a, b) {
            return Wm(a, b) >= 0
        }

        function Xm(a, b) {
            var c = Wm(a, b);
            c >= 0 && Ym[Ic][I](a, c, 1)
        }

        function Zm(a) {
            return Ym[Xa][Ac](Ym, arguments)
        }

        function $m(a) {
            if (km(a)) return Zm(a);
            else {
                for (var b = [], c = 0, d = a[E]; c < d; c++) b[c] = a[c];
                return b
            }
        }

        function an(a, b) {
            for (var c = 1; c < arguments[E]; c++) {
                var d = arguments[c],
                    f;
                if (km(d) || (f = lm(d)) && d[lc]($g)) a[s][Ac](a, d);
                else if (f)
                    for (var g = a[E], h = d[E], k = 0; k < h; k++) a[g + k] = d[k];
                else a[s](d)
            }
        }

        function bn(a, b, c, d) {
            Ym[Ic][Ac](a, cn(arguments, 1))
        }

        function cn(a, b, c) {
            return arguments[E] <= 2 ? Ym[Sa][I](a, b) : Ym[Sa][I](a, b, c)
        }

        function dn(a) {
            for (var b = {}, c = 0, d = 0; d < a[E];) {
                var f = a[d++],
                    g = pm(f) ? Uj + qm(f) : (typeof f)[Ya](0) + f;
                ba[F][lc][I](b, g) || (b[g] = !0, a[c++] = f)
            }
            Ba(a, c)
        }

        function en(a, b) {
            if (!lm(a) || !lm(b) || a[E] != b[E]) return !1;
            for (var c = a[E], d = fn, f = 0; f < c; f++)
                if (!d(a[f], b[f])) return !1;
            return !0
        }

        function fn(a, b) {
            return a === b
        }

        function gn() {}

        function hn(a) {
            if (a instanceof gn) return a;
            if (typeof a.wc == Vh) return a.wc(!1);
            if (lm(a)) {
                var b = 0,
                    c = new gn;
                Da(c, function () {
                    for (;;)
                        if (b >= a[E] && e(jn), b in a) return a[b++];
                        else b++
                });
                return c
            }
            e(m("Not implemented"))
        }

        function kn(a, b, c) {
            for (var d in a) b[I](c, a[d], d, a)
        }

        function ln(a) {
            var b = [],
                c = 0,
                d;
            for (d in a) b[c++] = a[d];
            return b
        }

        function mn(a) {
            var b = [],
                c = 0,
                d;
            for (d in a) b[c++] = d;
            return b
        }

        function nn(a, b) {
            for (var c in a)
                if (a[c] == b) return !0;
            return !1
        }

        function on(a, b) {
            b in a && delete a[b]
        }

        function pn(a) {
            var b = {}, c;
            for (c in a) b[a[c]] = c;
            return b
        }

        function qn(a, b) {
            for (var c, d, f = 1; f < arguments[E]; f++) {
                d = arguments[f];
                for (c in d) a[c] = d[c];
                for (var g = 0; g < rn[E]; g++) c = rn[g], ba[F][lc][I](d, c) && (a[c] = d[c])
            }
        }

        function sn(a) {
            var b = arguments[E];
            if (b == 1 && km(arguments[0])) return sn[Ac](j, arguments[0]);
            for (var c = {}, d = 0; d < b; d++) c[arguments[d]] = !0;
            return c
        }

        function tn(a) {
            if (typeof a.yb == Vh) return a.yb();
            if (S(a)) return a[ic](M);
            if (lm(a)) {
                for (var b = [], c = a[E], d = 0; d < c; d++) b[s](a[d]);
                return b
            }
            return ln(a)
        }

        function un(a) {
            if (typeof a.Pb == Vh) return a.Pb();
            if (typeof a.yb != Vh) {
                if (lm(a) || S(a)) {
                    for (var b = [], a = a[E], c = 0; c < a; c++) b[s](c);
                    return b
                }
                return mn(a)
            }
        }

        function vn(a, b, c) {
            if (typeof a[zb] == Vh) a[zb](b, c);
            else if (lm(a) || S(a)) V(a, b, c);
            else
                for (var d = un(a), f = tn(a), g = f[E], h = 0; h < g; h++) b[I](c, f[h], d && d[h], a)
        }

        function wn(a, b) {
            this.c = {};
            this.b = [];
            var c = arguments[E];
            if (c > 1) {
                c % 2 && e(m("Uneven number of arguments"));
                for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
            } else if (a) {
                a instanceof wn ? (c = a.Pb(), d = a.yb()) : (c = mn(a), d = ln(a));
                for (var f = 0; f < c[E]; f++) this.set(c[f], d[f])
            }
        }

        function xn(a) {
            if (a.G != a.b[E]) {
                for (var b = 0, c = 0; b < a.b[E];) {
                    var d = a.b[b];
                    yn(a.c, d) && (a.b[c++] = d);
                    b++
                }
                Ba(a.b, c)
            }
            if (a.G != a.b[E]) {
                for (var f = {}, c = b = 0; b < a.b[E];) d = a.b[b], yn(f, d) || (a.b[c++] = d, f[d] = 1), b++;
                Ba(a.b, c)
            }
        }

        function yn(a, b) {
            return ba[F][lc][I](a, b)
        }

        function zn() {
            return R.navigator ? R.navigator.userAgent : j
        }

        function An() {
            return R.navigator
        }

        function W(a) {
            return Bn[a] || (Bn[a] = Mm(Cn, a) >= 0)
        }

        function Dn() {
            return En[9] || (En[9] = X && p.documentMode && p.documentMode >= 9)
        }

        function Fn(a, b) {
            var c = 0,
                d = 0;
            if (Gn(a)) c = a.selectionStart, d = b ? -1 : a.selectionEnd;
            else if (X) {
                var f = Hn(a),
                    g = f[0],
                    f = f[1];
                if (g[Ta](f)) {
                    g.setEndPoint(ef, f);
                    if (a[C] == pl) {
                        for (var c = f[Nb](), h = g[Qa], d = h, k = f = c[Qa], o = !1; !o;) g[yc](Rf, g) == 0 ? o = !0 : (g[rc](ch, -1), g[Qa] == h ? d += Oc : o = !0);
                        if (b) g = [d[E], -1];
                        else {
                            for (g = !1; !g;) c[yc](Rf, c) == 0 ? g = !0 : (c[rc](ch, -1), c[Qa] == f ? k += Oc : g = !0);
                            g = [d[E], d[E] + k[E]]
                        }
                        return g
                    }
                    c = g[Qa][E];
                    d = b ? -1 : g[Qa][E] + f[Qa][E]
                }
            }
            return [c, d]
        }

        function Hn(a) {
            var b = a[nc] || a[ec],
                c = b.selection[nb]();
            a[C] == pl ? (b = b[mc][rb](), b[kc](a)) : b = a[rb]();
            return [b, c]
        }

        function In(a, b) {
            a[C] == pl && (b = a[ab][J](0, b)[u](/(\r\n|\r|\n)/g, Nc)[E]);
            return b
        }

        function Gn(a) {
            try {
                return typeof a.selectionStart == Tj
            } catch (b) {
                return !1
            }
        }

        function Jn(a, b) {
            this.x = gm(a) ? a : 0;
            this.y = gm(b) ? b : 0
        }

        function Kn(a, b) {
            return new Jn(a.x - b.x, a.y - b.y)
        }

        function Ln(a, b) {
            ja(this, a);
            Ha(this, b)
        }

        function Mn(a) {
            return (a = a[bc]) && typeof a[ic] == Vh ? a[ic](/\s+/) : []
        }

        function Nn(a, b) {
            var c = Mn(a),
                d = cn(arguments, 1),
                f;
            f = c;
            for (var g = 0, h = 0; h < d[E]; h++) Vm(f, d[h]) || (f[s](d[h]), g++);
            f = g == d[E];
            Ca(a, c[L](N));
            return f
        }

        function On(a, b) {
            var c = Mn(a),
                d = cn(arguments, 1),
                f;
            f = c;
            for (var g = 0, h = 0; h < f[E]; h++) Vm(d, f[h]) && (bn(f, h--, 1), g++);
            f = g == d[E];
            Ca(a, c[L](N));
            return f
        }

        function Pn(a) {
            return a ? new Qn(Rn(a)) : Sn || (Sn = new Qn)
        }

        function Tn(a, b, c, d) {
            a = d || a;
            b = b && b != td ? b[Hc]() : M;
            if (a.querySelectorAll && a.querySelector && (!Y || Un(p) || W(xe)) && (b || c)) return a.querySelectorAll(b + (c ? he + c : M));
            if (c && a.getElementsByClassName)
                if (a = a.getElementsByClassName(c), b) {
                    for (var d = {}, f = 0, g = 0, h; h = a[g]; g++) b == h[lb] && (d[f++] = h);
                    Ba(d, f);
                    return d
                } else return a;
            a = a.getElementsByTagName(b || td);
            if (c) {
                d = {};
                for (g = f = 0; h = a[g]; g++) b = h[bc], typeof b[ic] == Vh && Vm(b[ic](/\s+/), c) && (d[f++] = h);
                Ba(d, f);
                return d
            } else return a
        }

        function Vn(a, b) {
            kn(b, function (b, d) {
                d == $k ? a[G].cssText = b : d == fh ? Ca(a, b) : d == Uh ? a.htmlFor = b : d in Wn ? a[Cb](Wn[d], b) : d.lastIndexOf(Eg, 0) == 0 ? a[Cb](d, b) : a[d] = b
            })
        }

        function Xn(a) {
            var b = a[ec];
            if (Y && !W(ue) && !Yn) {
                typeof a.innerHeight == "undefined" && (a = l);
                var b = a.innerHeight,
                    c = a[ec][Qb].scrollHeight;
                a == a.top && c < b && (b -= 15);
                return new Ln(a.innerWidth, b)
            }
            a = Un(b) ? b[Qb] : b[mc];
            return new Ln(a[cc], a[uc])
        }

        function Zn(a) {
            return !Y && Un(a) ? a[Qb] : a[mc]
        }

        function $n(a) {
            return a ? a.parentWindow || a[Ib] : l
        }

        function ao(a, b, c) {
            return bo(p, arguments)
        }

        function bo(a, b) {
            var c = b[0],
                d = b[1];
            if (!co && d && (d[Lb] || d[C])) {
                c = [Fe, c];
                d[Lb] && c[s](Qc, Cm(d[Lb]), Uc);
                if (d[C]) {
                    c[s](Tc, Cm(d[C]), Uc);
                    var f = {};
                    qn(f, d);
                    d = f;
                    delete d[C]
                }
                c[s](Le);
                c = c[L](M)
            }
            c = a[xb](c);
            d && (S(d) ? Ca(c, d) : km(d) ? Nn[Ac](j, [c][Xa](d)) : Vn(c, d));
            b[E] > 2 && eo(a, c, b, 2);
            return c
        }

        function eo(a, b, c, d) {
            function f(c) {
                c && b[Ja](S(c) ? a[$a](c) : c)
            }
            for (; d < c[E]; d++) {
                var g = c[d];
                lm(g) && !(pm(g) && g[v] > 0) ? V(fo(g) ? $m(g) : g, f) : f(g)
            }
        }

        function go(a, b) {
            var c = a[xb](O);
            X ? (ka(c, Je + b), c[oc](c[B])) : ka(c, b);
            if (c[D][E] == 1) return c[oc](c[B]);
            else {
                for (var d = a.createDocumentFragment(); c[B];) d[Ja](c[B]);
                return d
            }
        }

        function Un(a) {
            return a.compatMode == Ye
        }

        function ho(a) {
            for (var b; b = a[B];) a[oc](b)
        }

        function io(a, b) {
            b[K] && b[K][db](a, b[Mb])
        }

        function jo(a) {
            return a && a[K] ? a[K][oc](a) : j
        }

        function ko(a, b) {
            if (a[zc] && b[v] == 1) return a == b || a[zc](b);
            if (typeof a[hb] != "undefined") return a == b || Boolean(a[hb](b) & 16);
            for (; b && a != b;) b = b[K];
            return b == a
        }

        function lo(a, b) {
            if (a == b) return 0;
            if (a[hb]) return a[hb](b) & 2 ? 1 : -1;
            if (Sk in a || a[K] && Sk in a[K]) {
                var c = a[v] == 1,
                    d = b[v] == 1;
                if (c && d) return a[ac] - b[ac];
                else {
                    var f = a[K],
                        g = b[K];
                    return f == g ? mo(a, b) : !c && ko(f, b) ? -1 * no(a, b) : !d && ko(g, a) ? no(b, a) : (c ? a[ac] : f[ac]) - (d ? b[ac] : g[ac])
                }
            }
            d = Rn(a);
            c = d[nb]();
            c.selectNode(a);
            c[Ra](!0);
            d = d[nb]();
            d.selectNode(b);
            d[Ra](!0);
            return c.compareBoundaryPoints(R.Range.START_TO_END, d)
        }

        function no(a, b) {
            var c = a[K];
            if (c == b) return -1;
            for (var d = b; d[K] != c;) d = d[K];
            return mo(d, a)
        }

        function mo(a, b) {
            for (var c = b; c = c[Ub];)
                if (c == a) return -1;
            return 1
        }

        function oo(a) {
            var b, c = arguments[E];
            if (c) {
                if (c == 1) return arguments[0]
            } else return j;
            var d = [],
                f = ca;
            for (b = 0; b < c; b++) {
                for (var g = [], h = arguments[b]; h;) g[Jc](h), h = h[K];
                d[s](g);
                f = r.min(f, g[E])
            }
            g = j;
            for (b = 0; b < f; b++) {
                for (var h = d[0][b], k = 1; k < c; k++)
                    if (h != d[k][b]) return g;
                g = h
            }
            return g
        }

        function Rn(a) {
            return a[v] == 9 ? a : a[nc] || a[ec]
        }

        function po(a) {
            return Y ? a[ec] || a.contentWindow[ec] : a.contentDocument || a.contentWindow[ec]
        }

        function qo(a, b) {
            if (ml in a) a.textContent = b;
            else if (a[B] && a[B][v] == 3) {
                for (; a[pc] != a[B];) a[oc](a[pc]);
                a[B].data = b
            } else ho(a), a[Ja](Rn(a)[$a](b))
        }

        function ro(a) {
            var b = a.getAttributeNode(el);
            return b && b.specified ? (a = a.tabIndex, nm(a) && a >= 0 && a < 32768) : !1
        }

        function so(a) {
            if (to && yi in a) a = a.innerText[u](/(\r\n|\r|\n)/g, Nc);
            else {
                var b = [];
                uo(a, b, !0);
                a = b[L](M)
            }
            a = a[u](/ \xAD /g, N)[u](/\xAD/g, M);
            a = a[u](/\u200B/g, M);
            to || (a = a[u](/ +/g, N));
            a != N && (a = a[u](/^\s*/, M));
            return a
        }

        function vo(a) {
            var b = [];
            uo(a, b, !1);
            return b[L](M)
        }

        function uo(a, b, c) {
            if (!(a[lb] in wo))
                if (a[v] == 3) c ? b[s](n(a[Kc])[u](/(\r\n|\r|\n)/g, M)) : b[s](a[Kc]);
                else if (a[lb] in xo) b[s](xo[a[lb]]);
            else
                for (a = a[B]; a;) uo(a, b, c), a = a[Mb]
        }

        function fo(a) {
            if (a && typeof a[E] == Tj)
                if (pm(a)) return typeof a[cb] == Vh || typeof a[cb] == Zk;
                else if (om(a)) return typeof a[cb] == Vh;
            return !1
        }

        function Qn(a) {
            this.b = a || R[ec] || p
        }

        function yo(a) {
            return a.b
        }

        function zo(a) {
            return a.b.parentWindow || a.b[Ib]
        }

        function Ao(a) {
            var b = a.b,
                a = Zn(b),
                b = b.parentWindow || b[Ib];
            return new Jn(b.pageXOffset || a[vc], b.pageYOffset || a[Tb])
        }

        function Bo(a) {
            var b, c = a[K];
            if (c && c[v] != 11)
                if (a.removeNode) a.removeNode(!1);
                else {
                    for (; b = a[B];) c[db](b, a);
                    jo(a)
                }
        }

        function Co(a, b, c, d) {
            this.top = a;
            this.right = b;
            this.bottom = c;
            na(this, d)
        }

        function Do(a, b, c, d) {
            na(this, a);
            this.top = b;
            ja(this, c);
            Ha(this, d)
        }

        function Eo(a, b) {
            S(b) ? Fo(a, i, b) : kn(b, vm(Fo, a))
        }

        function Fo(a, b, c) {
            a[G][Pm(c)] = b
        }

        function Go(a, b) {
            var c = Rn(a);
            return c[Ib] && c[Ib].getComputedStyle && (c = c[Ib].getComputedStyle(a, j)) ? c[b] || c.getPropertyValue(b) : M
        }

        function Ho(a, b) {
            return a.currentStyle ? a.currentStyle[b] : j
        }

        function Io(a, b) {
            return Go(a, b) || Ho(a, b) || a[G][b]
        }

        function Jo(a, b) {
            var c, d, f = Z && (Ko || Lo) && W(qe);
            b instanceof Jn ? (c = b.x, d = b.y) : (c = b, d = i);
            na(a[G], Mo(c, f));
            a[G].top = Mo(d, f)
        }

        function No(a) {
            var a = a ? a[v] == 9 ? a : Rn(a) : p,
                b;
            if (b = X)
                if (b = !Dn()) b = Pn(a), b = !Un(b.b);
            return b ? a[mc] : a[Qb]
        }

        function Oo(a) {
            var b = a[Ka]();
            X && (a = a[nc], b.left -= a[Qb][Ab] + a[mc][Ab], b.top -= a[Qb][Db] + a[mc][Db]);
            return b
        }

        function Po(a) {
            if (X) return a.offsetParent;
            for (var b = Rn(a), c = Io(a, jk), d = c == Nh || c == qg, a = a[K]; a && a != b; a = a[K])
                if (c = Io(a, jk), d = d && c == Yk && a != b[Qb] && a != b[mc], !d && (a.scrollWidth > a[cc] || a.scrollHeight > a[uc] || c == Nh || c == qg || c == uk)) return a;
            return j
        }

        function Qo(a) {
            for (var b = new Co(0, ca, ca, 0), c = Pn(a), d = c.b[mc], f = Zn(c.b), g; a = Po(a);)
                if ((!X || a[cc] != 0) && (!Y || a[uc] != 0 || a != d) && (a.scrollWidth != a[cc] || a.scrollHeight != a[uc]) && Io(a, Zj) != Ml) {
                    var h = Ro(a),
                        k;
                    k = a;
                    if (Z && !W(qe)) {
                        var o = ea(Go(k, Rg));
                        if (So(k)) {
                            var q = k.offsetWidth - k[cc] - o - ea(Go(k, Tg));
                            o += q
                        }
                        k = new Jn(o, ea(Go(k, Vg)))
                    } else k = new Jn(k[Ab], k[Db]);
                    h.x += k.x;
                    h.y += k.y;
                    b.top = r.max(b.top, h.y);
                    b.right = r.min(b[Mc], h.x + a[cc]);
                    b.bottom = r.min(b[xc], h.y + a[uc]);
                    na(b, r.max(b[y], h.x));
                    g = g || a != f
                }
            d = f[vc];
            f = f[Tb];
            Y ? (b.left +=
                d, b.top += f) : (na(b, r.max(b[y], d)), b.top = r.max(b.top, f));
            if (!g || Y) b.right += d, b.bottom += f;
            c = Xn(zo(c) || l);
            b.right = r.min(b[Mc], d + c[t]);
            b.bottom = r.min(b[xc], f + c[Gc]);
            return b.top >= 0 && b[y] >= 0 && b[xc] > b.top && b[Mc] > b[y] ? b : j
        }

        function Ro(a) {
            var b, c = Rn(a),
                d = Io(a, jk),
                f = Z && c[tb] && !a[Ka] && d == qg && (b = c[tb](a)) && (b[ob] < 0 || b[pb] < 0),
                g = new Jn(0, 0),
                h = No(c);
            if (a == h) return g;
            if (a[Ka]) b = Oo(a), a = Ao(Pn(c)), g.x = b[y] + a.x, g.y = b.top + a.y;
            else if (c[tb] && !f) b = c[tb](a), a = c[tb](h), g.x = b[ob] - a[ob], g.y = b[pb] - a[pb];
            else {
                b = a;
                do {
                    g.x += b.offsetLeft;
                    g.y += b[Fc];
                    b != a && (g.x += b[Ab] || 0, g.y += b[Db] || 0);
                    if (Y && Io(b, jk) == Nh) {
                        g.x += c[mc][vc];
                        g.y += c[mc][Tb];
                        break
                    }
                    b = b.offsetParent
                } while (b && b != a);
                if (To || Y && d == qg) g.y -= c[mc][Fc];
                for (b = a;
                    (b = Po(b)) && b != c[mc] && b != h;)
                    if (g.x -=
                        b[vc], !To || b[Cc] != Wf) g.y -= b[Tb]
            }
            return g
        }

        function Uo(a) {
            var b = new Jn;
            if (a[v] == 1)
                if (a[Ka]) a = Oo(a), b.x = a[y], b.y = a.top;
                else {
                    var c = Ao(Pn(a)),
                        a = Ro(a);
                    b.x = a.x - c.x;
                    b.y = a.y - c.y
                } else {
                    var c = om(a.Nj),
                        d = a;
                    a[eb] ? d = a[eb][0] : c && a.Ha[eb] && (d = a.Ha[eb][0]);
                    b.x = d[Ob];
                    b.y = d[Pb]
                }
            return b
        }

        function Vo(a, b, c) {
            b instanceof Ln ? (c = b[Gc], b = b[t]) : c == i && e(m("missing height argument"));
            ja(a[G], Mo(b, !0));
            Ha(a[G], Mo(c, !0))
        }

        function Mo(a, b) {
            typeof a == Tj && (a = (b ? r.round(a) : a) + pk);
            return a
        }

        function Wo(a) {
            if (Io(a, Ah) != Rj) return Xo(a);
            var b = a[G],
                c = b.display,
                d = b.visibility,
                f = b.position;
            Aa(b, li);
            b.position = qg;
            b.display = xi;
            a = Xo(a);
            b.display = c;
            b.position = f;
            Aa(b, d);
            return a
        }

        function Xo(a) {
            var b = a.offsetWidth,
                c = a.offsetHeight,
                d = Y && !b && !c;
            return (!gm(b) || d) && a[Ka] ? (a = Oo(a), new Ln(a[Mc] - a[y], a[xc] - a.top)) : new Ln(b, c)
        }

        function Yo(a) {
            var b = Ro(a),
                a = Wo(a);
            return new Do(b.x, b.y, a[t], a[Gc])
        }

        function Zo(a, b) {
            a[G].display = b ? M : Rj
        }

        function So(a) {
            return yk == Io(a, wh)
        }

        function $o(a, b, c) {
            c = !c ? a.getElementsByTagName(td) : j;
            if (ap) {
                if (b = b ? Rj : M, a[G][ap] = b, c)
                    for (var a = 0, d; d = c[a]; a++) d[G][ap] = b
            } else if (X || To)
                if (b = b ? Wj : M, a[Cb](Fl, b), c)
                    for (a = 0; d = c[a]; a++) d[Cb](Fl, b)
        }

        function bp(a, b) {
            if (/^\d+px?$/ [Ma](b)) return da(b, 10);
            else {
                var c = a[G][y],
                    d = a.runtimeStyle[y];
                na(a.runtimeStyle, a.currentStyle[y]);
                na(a[G], b);
                var f = a[G].pixelLeft;
                na(a[G], c);
                na(a.runtimeStyle, d);
                return f
            }
        }

        function cp(a, b) {
            if (X) {
                var c = bp(a, Ho(a, b + Bf)),
                    d = bp(a, Ho(a, b + Kf)),
                    f = bp(a, Ho(a, b + Yf)),
                    g = bp(a, Ho(a, b + We));
                return new Co(f, d, g, c)
            } else return c = Go(a, b + Bf), d = Go(a, b + Kf), f = Go(a, b + Yf), g = Go(a, b + We), new Co(ea(f), ea(d), ea(g), ea(c))
        }

        function dp(a, b) {
            if (Ho(a, b + Tf) == Rj) return 0;
            var c = Ho(a, b + dg);
            return c in ep ? ep[c] : bp(a, c)
        }

        function fp(a) {
            if (X) {
                var b = dp(a, Qg),
                    c = dp(a, Sg),
                    d = dp(a, Ug),
                    a = dp(a, Og);
                return new Co(d, c, a, b)
            } else return b = Go(a, Rg), c = Go(a, Tg), d = Go(a, Vg), a = Go(a, Pg), new Co(ea(d), ea(c), ea(a), ea(b))
        }

        function gp(a) {
            var b = Rn(a),
                c = M;
            if (b[mc][rb]) {
                b = b[mc][rb]();
                b[kc](a);
                try {
                    c = b.queryCommandValue(hf)
                } catch (d) {
                    c = M
                }
            }
            c || (c = Io(a, Qh));
            a = c[ic](vd);
            a[E] > 1 && (c = a[0]);
            a: for (a = 0; a < 2; a++)
                if (b = "\"'" [Ya](a), c[Ya](0) == b && c[Ya](c[E] - 1) == b) {
                    c = c[J](1, c[E] - 1);
                    break a
                }
            return c
        }

        function hp(a) {
            var b = Io(a, Rh),
                c;
            c = (c = b[qb](ip)) && c[0] || j;
            if (b && pk == c) return da(b, 10);
            if (X)
                if (c in jp) return bp(a, b);
                else if (a[K] && a[K][v] == 1 && c in kp) return a = a[K], c = Io(a, Rh), bp(a, b == c ? se : b);
            c = ao(Tk, {
                style: Ll
            });
            a[Ja](c);
            b = c.offsetHeight;
            jo(c);
            return b
        }

        function lp(a) {
            return function () {
                return a
            }
        }

        function mp(a) {
            return a
        }

        function np() {}

        function op(a) {
            for (var b = 0, c = arguments[E]; b < c; ++b) {
                var d = arguments[b];
                lm(d) ? op[Ac](j, d) : d && typeof d.s == Vh && d.s()
            }
        }

        function pp(a, b) {
            this.b = a;
            this.m = b
        }

        function qp(a, b, c) {
            a = a.mc();
            return c != j ? a[J](b, c) : a[J](b)
        }

        function rp(a, b) {
            var c = a.mc();
            return b <= c[E] && b >= 0 ? c[Ya](b) : M
        }

        function sp(a, b) {
            pp[I](this, a, b)
        }

        function tp(a, b) {
            return Go(a, b) || Ho(a, b) || a[G][b]
        }

        function up(a, b, c, d, f, g, h, k) {
            var o, q = c.offsetParent;
            if (q) {
                var w = q[Cc] == lf || q[Cc] == Te;
                if (!w || Io(q, jk) != Yk) o = Ro(q), w || (o = Kn(o, new Jn(q[vc], q[Tb])))
            }
            q = Yo(a);
            if (w = Qo(a)) {
                var z = new Do(w[y], w.top, w[Mc] - w[y], w[xc] - w.top),
                    w = r.max(q[y], z[y]),
                    ua = r.min(q[y] + q[t], z[y] + z[t]);
                if (w <= ua) {
                    var La = r.max(q.top, z.top),
                        z = r.min(q.top + q[Gc], z.top + z[Gc]);
                    if (La <= z) na(q, w), q.top = La, ja(q, ua - w), Ha(q, z - La)
                }
            }
            w = Pn(a);
            La = Pn(c);
            if (w.b != La.b) {
                var ua = w.b[mc],
                    La = zo(La),
                    z = new Jn(0, 0),
                    wf = $n(Rn(ua)),
                    Pl = ua;
                do {
                    var Eq = wf == La ? Ro(Pl) : Uo(Pl);
                    z.x += Eq.x;
                    z.y += Eq.y
                } while (wf && wf != La && (Pl = wf.frameElement) && (wf = wf.parent));
                ua = Kn(z, Ro(ua));
                X && !Un(w.b) && (ua = Kn(ua, Ao(w)));
                q.left += ua.x;
                q.top += ua.y
            }
            a = (b & 4 && So(a) ? b ^ 2 : b) & -5;
            b = new Jn(a & 2 ? q[y] + q[t] : q[y], a & 1 ? q.top + q[Gc] : q.top);
            o && (b = Kn(b, o));
            f && (b.x += (a & 2 ? -1 : 1) * f.x, b.y += (a & 1 ? -1 : 1) * f.y);
            var rd;
            if (h && (rd = Qo(c)) && o) rd.top = r.max(0, rd.top - o.y), rd.right -= o.x, rd.bottom -= o.y, na(rd, r.max(0, rd[y] - o.x));
            return vp(b, c, d, g, rd, h, k)
        }

        function vp(a, b, c, d, f, g, h) {
            var a = a.W(),
                k = 0,
                o = (c & 4 && So(b) ? c ^ 2 : c) & -5,
                c = Wo(b),
                h = h ? h.W() : c.W();
            if (d || o != 0) o & 2 ? a.x -= h[t] + (d ? d[Mc] : 0) : d && (a.x += d[y]), o & 1 ? a.y -= h[Gc] + (d ? d[xc] : 0) : d && (a.y += d.top);
            if (g) {
                if (f) {
                    d = a;
                    k = 0;
                    if ((g & 65) == 65 && (d.x < f[y] || d.x >= f[Mc])) g &= -2;
                    if ((g & 132) == 132 && (d.y < f.top || d.y >= f[xc])) g &= -5;
                    if (d.x < f[y] && g & 1) d.x = f[y], k |= 1;
                    d.x < f[y] && d.x + h[t] > f[Mc] && g & 16 && (h.width -= d.x + h[t] - f[Mc], k |= 4);
                    if (d.x + h[t] > f[Mc] && g & 1) d.x = r.max(f[Mc] - h[t], f[y]), k |= 1;
                    g & 2 && (k |= (d.x < f[y] ? 16 : 0) | (d.x + h[t] > f[Mc] ? 32 : 0));
                    if (d.y <
                        f.top && g & 4) d.y = f.top, k |= 2;
                    d.y >= f.top && d.y + h[Gc] > f[xc] && g & 32 && (h.height -= d.y + h[Gc] - f[xc], k |= 8);
                    if (d.y + h[Gc] > f[xc] && g & 4) d.y = r.max(f[xc] - h[Gc], f.top), k |= 2;
                    g & 8 && (k |= (d.y < f.top ? 64 : 0) | (d.y + h[Gc] > f[xc] ? 128 : 0));
                    f = k
                } else f = 256;
                k = f;
                if (k & 496) return k
            }
            Jo(b, a);
            c == h || (!c || !h ? 0 : c[t] == h[t] && c[Gc] == h[Gc]) || Vo(b, h);
            return k
        }

        function wp() {}

        function xp(a, b) {
            this.c = a;
            this.d = b
        }

        function yp(a, b, c) {
            xp[I](this, a, b);
            this.j = c
        }

        function zp(a, b) {
            a & 48 && (b ^= 2);
            a & 192 && (b ^= 1);
            return b
        }

        function Ap(a, b, c, d) {
            yp[I](this, a, b, c || d);
            this.p = d
        }

        function Bp(a, b) {
            this.c = a instanceof Jn ? a : new Jn(a, b)
        }

        function Cp(a, b) {
            Bp[I](this, a, b)
        }

        function Dp(a, b, c) {
            var d = a.b,
                f = Pn(d),
                b = b || a.qb()[fb](1),
                g = kg + qm(d),
                h = f.h(g);
            h ? f.Kg(h) : h = f.l(If, {
                id: g
            });
            h[K] || Rn(d)[mc][Ja](h);
            g = a.m;
            b = b.m;
            f.Aa(h, f.b[$a](d[ab][J](0, g)));
            a = f.b[xb](Nf);
            ka(a, d[ab][J](g, b) || n[ub](160));
            f.Aa(h, a);
            f.Aa(h, f.b[$a](d[ab][J](b)));
            h[G].cssText = d[G].cssText;
            V(Mn(d), function (a) {
                Nn(h, a)
            });
            X && !W(Be) ? (h[G].whiteSpace = kk, h[G].wordWrap = Wg) : (h[G].whiteSpace = lk, h[G].wordWrap = tp(d, Sl) || M);
            h[G].fontFamily = gp(d);
            try {
                h[G].fontSize = hp(d) + pk
            } catch (k) {}
            h[G].fontWeight = tp(d, Th);
            h[G].fontStyle =
                tp(d, Sh);
            h[G].textTransform = tp(d, ol);
            h[G].textDecoration = tp(d, nl);
            h[G].lineHeight = tp(d, wj);
            h[G].letterSpacing = tp(d, tj);
            h[G].wordSpacing = tp(d, Rl);
            h[G].direction = So(d) ? yk : zj;
            h[G].textAlign = Io(d, ll) || Wk;
            h[G].verticalAlign = tp(d, Kl);
            f = cp(d, Bj);
            h[G].marginTop = f.top + pk;
            h[G].marginRight = f[Mc] + pk;
            h[G].marginBottom = f[xc] + pk;
            h[G].marginLeft = f[y] + pk;
            f = fp(d);
            h[G].borderTop = f.top + qk;
            h[G].borderRight = f[Mc] + qk;
            h[G].borderBottom = f[xc] + qk;
            h[G].borderLeft = f[y] + qk;
            f = cp(d, ck);
            h[G].paddingTop = f.top + pk;
            h[G].paddingRight =
                f[Mc] + pk;
            h[G].paddingBottom = f[xc] + pk;
            h[G].paddingLeft = f[y] + pk;
            Aa(h[G], li);
            f = Io(d, $j);
            h[G].overflowX = !f || f == Ml ? Gg : f;
            f = Io(d, ak);
            h[G].overflowY = !f || f == Ml ? Gg : f;
            Vo(h, Wo(d));
            f = h[G][t];
            f = f[J](0, f[E] - 2);
            f = new Number(f) - 4;
            ja(h[G], (f < 4 ? 4 : f) + pk);
            h.scrollTop = d[Tb];
            h.scrollLeft = d[vc];
            Jo(h, Ro(d));
            h[G].position = qg;
            h[G].zIndex = yd;
            return d[Cc][Hc]() == of && (a[Fc] >= d.offsetHeight || a.offsetLeft >= d.offsetWidth) ? Ep(d, 7) : Ep(a, c)
        }

        function Ep(a, b) {
            return new Ap(a, b || 5, !0, !1)
        }

        function Fp(a, b, c) {
            this.b = a;
            this[Dc](b, c || b.qb())
        }

        function Gp(a) {
            a.c = a.q()
        }

        function Hp(a) {
            try {
                a.b.Nd(a.f)
            } catch (b) {}
        }

        function Ip(a, b) {
            wa(this, a);
            Ea(this, b);
            ma(this, this[H])
        }

        function Jp(a) {
            a[bb]()
        }

        function Kp(a, b, c) {
            Fp[I](this, a, b, c)
        }

        function Lp(a) {
            Lp[N](a);
            return a
        }

        function Mp(a, b) {
            a && this.Xc(a, b)
        }

        function Np(a) {
            return (Op ? a.Ha.button == 0 : a[C] == gh ? !0 : !! (a.Ha.button & Pp[0])) && !(Y && Ko && a[hc])
        }

        function Qp(a, b) {
            this.f = b;
            this.c = [];
            a > this.f && e(m("[goog.structs.SimplePool] Initial cannot be greater than max"));
            for (var c = 0; c < a; c++) this.c[s](this.b ? this.b() : {})
        }

        function Rp(a) {
            return a.c[E] ? a.c.pop() : a.b ? a.b() : {}
        }

        function Sp(a, b) {
            a.c[E] < a.f ? a.c[s](b) : Tp(a, b)
        }

        function Tp(a, b) {
            if (a.d) a.d(b);
            else if (pm(b))
                if (om(b.s)) b.s();
                else
                    for (var c in b) delete b[c]
        }

        function Up() {}

        function Vp(a, b, c, d, f) {
            if (b)
                if (km(b)) {
                    for (var g = 0; g < b[E]; g++) Vp(a, b[g], c, d, f);
                    return j
                } else {
                    var d = !! d,
                        h = Wp;
                    b in h || (h[b] = Xp());
                    h = h[b];
                    d in h || (h[d] = Xp(), h.G++);
                    var h = h[d],
                        k = qm(a),
                        o;
                    h.mb++;
                    if (h[k]) {
                        o = h[k];
                        for (g = 0; g < o[E]; g++)
                            if (h = o[g], h.nd == c && h.Xe == f) {
                                if (h.Gc) break;
                                return o[g].key
                            }
                    } else o = h[k] = Yp(), h.G++;
                    g = Zp();
                    g.src = a;
                    h = $p();
                    h.Xc(c, g, a, b, d, f);
                    c = h.key;
                    g.key = c;
                    o[s](h);
                    aq[c] = h;
                    bq[k] || (bq[k] = Yp());
                    bq[k][s](h);
                    a[Bb] ? (a == R || !a.xh) && a[Bb](b, g, d) : a.attachEvent(b in cq ? cq[b] : cq[b] = Wj + b, g);
                    return c
                } else e(m(uf))
        }

        function dq(a, b, c, d, f) {
            if (km(b))
                for (var g = 0; g < b[E]; g++) dq(a, b[g], c, d, f);
            else if (d = !! d, a = eq(a, b, d))
                for (g = 0; g < a[E]; g++)
                    if (a[g].nd == c && a[g][kb] == d && a[g].Xe == f) {
                        fq(a[g].key);
                        break
                    }
        }

        function fq(a) {
            if (!aq[a]) return !1;
            var b = aq[a];
            if (b.Gc) return !1;
            var c = b.src,
                d = b[C],
                f = b.c,
                g = b[kb];
            c[fc] ? (c == R || !c.xh) && c[fc](d, f, g) : c.detachEvent && c.detachEvent(d in cq ? cq[d] : cq[d] = Wj + d, f);
            c = qm(c);
            f = Wp[d][g][c];
            if (bq[c]) {
                var h = bq[c];
                Xm(h, b);
                h[E] == 0 && delete bq[c]
            }
            b.Gc = !0;
            f.yh = !0;
            gq(d, g, c, f);
            delete aq[a];
            return !0
        }

        function gq(a, b, c, d) {
            if (!d.jf && d.yh) {
                for (var f = 0, g = 0; f < d[E]; f++)
                    if (d[f].Gc) {
                        var h = d[f].c;
                        h.src = j;
                        hq(h);
                        iq(d[f])
                    } else f != g && (d[g] = d[f]), g++;
                Ba(d, g);
                d.yh = !1;
                g == 0 && (jq(d), delete Wp[a][b][c], Wp[a][b].G--, Wp[a][b].G == 0 && (kq(Wp[a][b]), delete Wp[a][b], Wp[a].G--), Wp[a].G == 0 && (kq(Wp[a]), delete Wp[a]))
            }
        }

        function lq(a) {
            var b, c = 0,
                d = b == j;
            b = !! b;
            if (a == j) kn(bq, function (a) {
                for (var f = a[E] - 1; f >= 0; f--) {
                    var g = a[f];
                    if (d || b == g[kb]) fq(g.key), c++
                }
            });
            else if (a = qm(a), bq[a])
                for (var a = bq[a], f = a[E] - 1; f >= 0; f--) {
                    var g = a[f];
                    if (d || b == g[kb]) fq(g.key), c++
                }
        }

        function eq(a, b, c) {
            var d = Wp;
            return b in d && (d = d[b], c in d && (d = d[c], a = qm(a), d[a])) ? d[a] : j
        }

        function mq(a, b, c, d, f) {
            var g = 1,
                b = qm(b);
            if (a[b]) {
                a.mb--;
                a = a[b];
                a.jf ? a.jf++ : a.jf = 1;
                try {
                    for (var h = a[E], k = 0; k < h; k++) {
                        var o = a[k];
                        o && !o.Gc && (g &= nq(o, f) !== !1)
                    }
                } finally {
                    a.jf--, gq(c, d, b, a)
                }
            }
            return Boolean(g)
        }

        function nq(a, b) {
            var c = a[Eb](b);
            a.gh && fq(a.key);
            return c
        }

        function oq(a, b) {
            var c = b[C] || b,
                d = Wp;
            if (!(c in d)) return !0;
            if (S(b)) b = new Ip(b, a);
            else if (b instanceof Ip) Ea(b, b[H] || a);
            else {
                var f = b,
                    b = new Ip(c, a);
                qn(b, f)
            }
            var f = 1,
                g, d = d[c],
                c = !0 in d,
                h;
            if (c) {
                g = [];
                for (h = a; h; h = h.kf) g[s](h);
                h = d[!0];
                h.mb = h.G;
                for (var k = g[E] - 1; !b.Yc && k >= 0 && h.mb; k--) ma(b, g[k]), f &= mq(h, g[k], b[C], !0, b) && b.Ee != !1
            }
            if (!1 in d)
                if (h = d[!1], h.mb = h.G, c)
                    for (k = 0; !b.Yc && k < g[E] && h.mb; k++) ma(b, g[k]), f &= mq(h, g[k], b[C], !1, b) && b.Ee != !1;
                else
                    for (d = a; !b.Yc && d && h.mb; d = d.kf) ma(b, d), f &= mq(h, d, b[C], !1, b) && b.Ee != !1;
            return Boolean(f)
        }

        function pq() {
            qq || (qq = [], V(Tn(p, wi, i, i), function (a) {
                var b;
                try {
                    b = po(a)
                } catch (c) {}
                b && qq[s](b)
            }))
        }

        function rq(a, b) {
            var c = sq;
            Vp(p, a, c, !0, b);
            pq();
            V(qq, function (d) {
                try {
                    Vp(d, a, c, !0, b)
                } catch (f) {}
            })
        }

        function tq(a, b, c, d) {
            if (b)
                if (km(b))
                    for (var f = 0; f < b[E]; f++) tq(a, b[f], c, d);
                else f = uq[b], f || (f = {}, uq[b] = f, rq(b, d)), b = f[qm(a)], b || (b = [], f[qm(a)] = b), Vm(b, c) || b[s](c);
                else e(m(uf))
        }

        function sq(a) {
            var b = uq[a[C]];
            return b && a[H] && (b = b[qm(a[H])]) ? vq(b, function (b) {
                if (om(b)) return b[I](i, a);
                else if (b && b[Eb] && om(b[Eb])) return b[Eb][I](b, a)
            }) : !1
        }

        function wq() {}

        function xq(a, b) {
            return oq(a, b)
        }

        function yq(a, b) {
            this.c = !! a;
            this.d = !! b;
            this.b = {}
        }

        function zq(a) {
            this.qc = {};
            this.ia = a || Aq;
            this.c = {}
        }

        function Bq(a, b) {
            return a.ia.get(a, b)
        }

        function Cq(a, b) {
            var c = b.Ob();
            a.qc[c] && e(m("Plugin already registered with the id:" + c));
            a.qc[c] = b;
            b.Za(a);
            b.gf(a)
        }

        function Dq(a) {
            this.c = a;
            this.b = []
        }

        function Fq(a) {
            V(a.b, fq);
            Ba(a.b, 0)
        }

        function Gq(a) {
            if (a[Xb] && !a[hc] || a[gb] || a[A] >= 112 && a[A] <= 123) return !1;
            switch (a[A]) {
            case 18:
            case 20:
            case 93:
            case 17:
            case 40:
            case 35:
            case 27:
            case 36:
            case 45:
            case 37:
            case 224:
            case 91:
            case 144:
            case 12:
            case 34:
            case 33:
            case 19:
            case 255:
            case 44:
            case 39:
            case 16:
            case 38:
            case 224:
            case 92:
                return !1;
            default:
                return !0
            }
        }

        function Hq(a, b, c, d, f) {
            if (!X && (!Y || !W(ve))) return !0;
            if (Ko && f) return Iq(a);
            if (f && !d) return !1;
            if (!c && (b == 17 || b == 18)) return !1;
            if (X && d && b == a) return !1;
            switch (a) {
            case 13:
                return !(X && Dn());
            case 27:
                return !Y
            }
            return Iq(a)
        }

        function Iq(a) {
            if (a >= 48 && a <= 57) return !0;
            if (a >= 96 && a <= 106) return !0;
            if (a >= 65 && a <= 90) return !0;
            if (Y && a == 0) return !0;
            switch (a) {
            case 32:
            case 63:
            case 107:
            case 109:
            case 110:
            case 111:
            case 186:
            case 189:
            case 187:
            case 188:
            case 190:
            case 191:
            case 192:
            case 222:
            case 219:
            case 220:
            case 221:
                return !0;
            default:
                return !1
            }
        }

        function Jq(a, b) {
            this.c = a || 1;
            this.b = b || Kq;
            this.f = T(this.Li, this);
            this.j = Lq()
        }

        function Mq(a, b, c) {
            om(a) ? c && (a = T(a, c)) : a && typeof a[Eb] == Vh ? a = T(a[Eb], a) : e(m(xf));
            b > 2147483647 || Kq[dc](a, b || 0)
        }

        function Nq(a) {
            this.d = {};
            this.c = {
                Bc: [],
                Gg: 0
            };
            this.M = sn(Oq);
            this.p = !0;
            this.f = this.z = !1;
            this.F = !0;
            this.b = a;
            Vp(this.b, oj, this.Ke, !1, this);
            Ko && Z && W(pe) && Vp(this.b, qj, this.Ag, !1, this);
            Pq && !Z && (Vp(this.b, pj, this.Bg, !1, this), Vp(this.b, qj, this.Cg, !1, this))
        }

        function Qq(a, b) {
            var c;
            if (S(b[a])) c = Rq(b[a]);
            else {
                var d = b,
                    f = a;
                km(b[a]) && (d = b[a], f = 0);
                for (c = []; f < d[E]; f += 2) c[s]({
                    keyCode: d[f],
                    Wc: d[f + 1]
                })
            }
            return c
        }

        function Rq(a) {
            for (var a = a[u](/[ +]*\+[ +]*/g, ud)[u](/[ ]+/g, N)[Lc](), a = a[ic](N), b = [], c, d = 0; c = a[d]; d++) {
                var f = c[ic](ud),
                    g;
                c = 0;
                for (var h, k = 0; h = f[k]; k++) {
                    switch (h) {
                    case Jk:
                        c |= 1;
                        continue;
                    case oh:
                        c |= 2;
                        continue;
                    case yg:
                        c |= 4;
                        continue;
                    case Ej:
                        c |= 8;
                        continue
                    }
                    g = h;
                    if (!Sq) {
                        f = {};
                        h = i;
                        for (h in Tq) f[Tq[h]] = h;
                        Sq = f
                    }
                    g = Sq[g];
                    break
                }
                b[s]({
                    keyCode: g,
                    Wc: c
                })
            }
            return b
        }

        function Uq(a) {
            return Pq && !Z && a[hc] && a[Xb] && !a[Bc]
        }

        function Vq(a, b, c) {
            var d = b[Na](),
                d = d[A] & 255 | d.Wc << 8,
                f = a[d];
            f && c && (b[E] == 0 || S(f)) && e(m("Keyboard shortcut conflicts with existing shortcut"));
            b[E] ? (f || (f = a[d] = {}), Vq(f, b, c)) : a[d] = c
        }

        function Wq(a, b, c, d) {
            c = c || 0;
            return (d = (d || a.d)[b[c]]) && !S(d) && b[E] - c > 1 ? Wq(a, b, c + 1, d) : d
        }

        function Xq(a, b, c) {
            Ip[I](this, a, c);
            this.ih = b
        }

        function Yq(a, b) {
            zq[I](this);
            this.M = a;
            this.b = this.Z();
            this.T = b;
            this.j = new Dq(this);
            this.F = this.b && this.b.getAttribute && !! this.b.getAttribute(Zh);
            this.d = {};
            this.p = {};
            this.rb = 0
        }

        function Zq() {
            return sk + ($q++)[Wb](36)
        }

        function ar(a, b) {
            for (var c in a.p) b(a.p[c])
        }

        function br(a) {
            var b = a.Z();
            b[Cc][Hc]() != bf && (Z && ea(Cn) < 4 ? (a = p.createEvent(zf), a.initKeyEvent(pj, !0, !0, l, !1, !1, !1, !1, 0, 32), b.dispatchEvent(a), a = p.createEvent(zf), a.initKeyEvent(pj, !0, !0, l, !1, !1, !1, !1, 8, 0), b.dispatchEvent(a)) : Y && !a.z && !a.F && (b.blur(), a.sb()))
        }

        function cr(a) {
            Yq[I](this, a, il)
        }

        function dr() {}

        function er(a) {
            this.j = Yh + fr++;
            this.f = Yh + fr++;
            this.c = Pn(Rn(X ? a.Nc() : a.A()));
            a.ph(this.c.l(Nf, {
                id: this.j
            }), this.c.l(Nf, {
                id: this.f
            }))
        }

        function gr(a, b) {
            return a.c.h(b ? a.j : a.f)
        }

        function hr(a, b, c, d, f) {
            this.b = !! b;
            a && ir(this, a, d);
            this.c = f != i ? f : this.cb || 0;
            this.b && (this.c *= -1);
            this.d = !c
        }

        function ir(a, b, c, d) {
            if (a.k = b) a.cb = nm(c) ? c : a.k[v] != 1 ? 0 : a.b ? -1 : 1;
            if (nm(d)) a.c = d
        }

        function jr() {}

        function kr(a) {
            if (a.getSelection) return a.getSelection();
            else {
                var a = a[ec],
                    b = a.selection;
                if (b) {
                    try {
                        var c = b[nb]();
                        if (c[Fb]) {
                            if (c[Fb]()[ec] != a) return j
                        } else if (!c[E] || c[cb](0)[ec] != a) return j
                    } catch (d) {
                        return j
                    }
                    return b
                }
                return j
            }
        }

        function lr(a) {
            for (var b = [], c = 0, d = a.kd(); c < d; c++) b[s](a.bc(c));
            return b
        }

        function mr(a, b) {
            hr[I](this, a, b, !0)
        }

        function nr(a, b, c, d, f) {
            var g;
            if (a) {
                this.tc = a;
                this.De = b;
                this.Db = c;
                this.ud = d;
                if (a[v] == 1 && a[Cc] != Ue)
                    if (a = a[D], b = a[b]) this.tc = b, this.De = 0;
                    else {
                        if (a[E]) this.tc = Rm(a);
                        g = !0
                    }
                if (c[v] == 1)(this.Db = c[D][d]) ? this.ud = 0 : this.Db = c
            }
            mr[I](this, f ? this.Db : this.tc, f);
            if (g) try {
                this[gc]()
            } catch (h) {
                h != jn && e(h)
            }
        }

        function or() {}

        function pr(a) {
            this.b = a
        }

        function qr(a) {
            var b = Rn(a)[nb]();
            if (a[v] == 3) b[Yb](a, 0), b[ib](a, a[E]);
            else if (rr(a)) {
                for (var c, d = a;
                    (c = d[B]) && rr(c);) d = c;
                b[Yb](d, 0);
                for (d = a;
                    (c = d[pc]) && rr(c);) d = c;
                b[ib](d, d[v] == 1 ? d[D][E] : d[E])
            } else c = a[K], a = Wm(c[D], a), b[Yb](c, a), b[ib](c, a + 1);
            return b
        }

        function sr(a, b, c, d) {
            var f = Rn(a)[nb]();
            f[Yb](a, b);
            f[ib](c, d);
            return f
        }

        function tr(a) {
            this.b = a
        }

        function ur(a, b) {
            this.b = a;
            this.c = b
        }

        function vr(a) {
            var b = Rn(a)[mc][rb]();
            if (a[v] == 1) b[kc](a), rr(a) && !a[D][E] && b[Ra](!1);
            else {
                for (var c = 0, d = a; d = d[Ub];) {
                    var f = d[v];
                    if (f == 3) c += d[E];
                    else if (f == 1) {
                        b[kc](d);
                        break
                    }
                }
                d || b[kc](a[K]);
                b[Ra](!d);
                c && b[fb](ch, c);
                b[rc](ch, a[E])
            }
            return b
        }

        function wr(a) {
            a.xb = a.gb = a.fb = j;
            a.Qa = a.Ua = -1
        }

        function xr(a, b) {
            for (var c = b[D], d = 0, f = c[E]; d < f; d++) {
                var g = c[d];
                if (rr(g)) {
                    var h = vr(g),
                        k = h[$b] != g.outerHTML;
                    if (a.hb() && k ? a.ib(h, 1, 1) >= 0 && a.ib(h, 1, 0) <= 0 : a.b[Ta](h)) return xr(a, g)
                }
            }
            return b
        }

        function yr(a, b, c) {
            c = c || a.pg();
            if (!c || !c[B]) return c;
            for (var d = b == 1, f = 0, g = c[D][E]; f < g; f++) {
                var h = d ? f : g - f - 1,
                    k = c[D][h],
                    o;
                try {
                    o = zr(k)
                } catch (q) {
                    continue
                }
                var w = o.Wd();
                if (a.hb())
                    if (rr(k)) {
                        if (o.Cb(a)) return yr(a, b, k)
                    } else {
                        if (a.ib(w, 1, 1) == 0) {
                            a.Qa = a.Ua = h;
                            break
                        }
                    } else if (a.Cb(o)) {
                    if (!rr(k)) {
                        d ? a.Qa = h : a.Ua = h + 1;
                        break
                    }
                    return yr(a, b, k)
                } else if (a.ib(w, 1, 0) < 0 && a.ib(w, 0, 1) > 0) return yr(a, b, k)
            }
            return c
        }

        function Ar(a, b) {
            var c = b == 1,
                d = c ? a.A() : a.I();
            if (d[v] == 1) {
                for (var d = d[D], f = d[E], g = c ? 1 : -1, h = c ? 0 : f - 1; h >= 0 && h < f; h += g) {
                    var k = d[h];
                    if (!rr(k) && a.b[yc]((b == 1 ? Qf : cf) + Xf + (b == 1 ? Qf : cf), zr(k).Wd()) == 0) return c ? h : h + 1
                }
                return h == -1 ? 0 : h
            } else return f = a.b[Nb](), g = vr(d), f.setEndPoint(c ? df : Sf, g), f = f[Qa][E], c ? d[E] - f : f
        }

        function Br(a, b, c) {
            var d;
            d = d || Pn(a[Fb]());
            var f;
            b[v] != 1 && (f = !0, b = d.l(bf, j, b));
            a[Ra](c);
            d = d || Pn(a[Fb]());
            var g = c = b.id;
            if (!c) c = b.id = Yh + fr++;
            a.pasteHTML(b.outerHTML);
            (b = d.h(c)) && (g || b[Ec](vi));
            f && (a = b[B], Bo(b), b = a);
            return b
        }

        function Cr(a) {
            this.b = a
        }

        function Dr(a) {
            this.b = a
        }

        function Er(a) {
            return X && !Dn() ? new ur(a, Rn(a[Fb]())) : Y ? new Dr(a) : Z ? new tr(a) : To ? new Cr(a) : new pr(a)
        }

        function zr(a) {
            if (X && !Dn()) {
                var b = new ur(vr(a), Rn(a));
                if (rr(a)) {
                    for (var c, d = a;
                        (c = d[B]) && rr(c);) d = c;
                    b.gb = d;
                    b.Qa = 0;
                    for (d = a;
                        (c = d[pc]) && rr(c);) d = c;
                    b.fb = d;
                    b.Ua = d[v] == 1 ? d[D][E] : d[E];
                    b.xb = a
                } else b.gb = b.fb = b.xb = a[K], b.Qa = Wm(b.xb[D], a), b.Ua = b.Qa + 1;
                a = b
            } else a = Y ? new Dr(qr(a)) : Z ? new tr(qr(a)) : To ? new Cr(qr(a)) : new pr(qr(a));
            return a
        }

        function rr(a) {
            var b;
            a: if (a[v] != 1) b = !1;
            else {
                switch (a[Cc]) {
                case Pe:
                case Qe:
                case Se:
                case Ue:
                case Xe:
                case gf:
                case kf:
                case nf:
                case of:
                case mf:
                case pf:
                case Af:
                case Df:
                case Ef:
                case Cf:
                case Gf:
                case Hf:
                case Lf:
                case Of:
                    b = !1;
                    break a
                }
                b = !0
            }
            return b || a[v] == 3
        }

        function Fr() {}

        function Gr() {}

        function Hr(a, b) {
            var c = new Gr;
            c.Tc = a;
            c.nb = !! b;
            return c
        }

        function Ir(a, b, c, d) {
            var f = new Gr;
            f.nb = Jr(a, b, c, d);
            if (a[Cc] == Ue) var g = a[K],
            b = Wm(g[D], a), a = g;
            c[Cc] == Ue && (g = c[K], d = Wm(g[D], c), c = g);
            f.nb ? (f.ob = c, f.Eb = d, f.pb = a, f.Fb = b) : (f.ob = a, f.Eb = b, f.pb = c, f.Fb = d);
            return f
        }

        function Kr(a) {
            a.ob = a.Eb = a.pb = a.Fb = j
        }

        function Lr(a) {
            var z;
            var b;
            if (!(b = a.Tc)) {
                b = a.A();
                var c = a.D(),
                    d = a.I(),
                    f = a.aa();
                if (X && !Dn()) {
                    var g = b,
                        h = c,
                        k = d,
                        o = f,
                        q = !1;
                    g[v] == 1 && (h = g[D][h], q = !h, g = h || g[pc] || g, h = 0);
                    var w = vr(g);
                    h && w[fb](ch, h);
                    if (g == k && h == o) w[Ra](!0);
                    else q && w[Ra](!1), q = !1, k[v] == 1 && (z = (h = k[D][o]) || k[pc] || k, k = z, o = 0, q = !h), g = vr(k), g[Ra](!q), o && g[rc](ch, o), w.setEndPoint(df, g);
                    o = new ur(w, Rn(b));
                    o.gb = b;
                    o.Qa = c;
                    o.fb = d;
                    o.Ua = f;
                    b = o
                } else b = Y ? new Dr(sr(b, c, d, f)) : Z ? new tr(sr(b, c, d, f)) : To ? new Cr(sr(b, c, d, f)) : new pr(sr(b, c, d, f));
                b = a.Tc = b
            }
            return b
        }

        function Mr(a) {
            if (X && !Dn()) {
                var b = !1;
                try {
                    b = a[K]
                } catch (c) {}
                return !!b
            } else return ko(a[nc][mc], a)
        }

        function Nr(a) {
            this.b = a.hd() ? a.I() : a.A();
            this.f = a.hd() ? a.aa() : a.D();
            this.c = a.hd() ? a.A() : a.I();
            this.j = a.hd() ? a.D() : a.aa()
        }

        function Or() {}

        function Pr(a) {
            var b = new Or;
            b.Ka = a;
            return b
        }

        function Qr(a) {
            for (var b = Rn(arguments[0])[mc].createControlRange(), c = 0, d = arguments[E]; c < d; c++) b.addElement(arguments[c]);
            return Pr(b)
        }

        function Rr(a) {
            if (!a.Ge && (a.Ge = [], a.Ka))
                for (var b = 0; b < a.Ka[E]; b++) a.Ge[s](a.Ka[cb](b));
            return a.Ge
        }

        function Sr(a) {
            if (!a.He) a.He = Rr(a)[Xa](), a.He.sort(function (a, c) {
                return a[ac] - c[ac]
            });
            return a.He
        }

        function Tr(a) {
            this.b = Rr(a)
        }

        function Ur(a) {
            if (a) this.Oc = Sr(a), this.wd = this.Oc[Na](), this.nf = Rm(this.Oc) || this.wd;
            mr[I](this, this.wd, !1)
        }

        function Vr() {
            this.b = [];
            this.c = [];
            this.f = this.d = j
        }

        function Wr(a) {
            var b = new Vr;
            b.c = a;
            b.b = Xr(a, function (a) {
                return a.gd()
            });
            return b
        }

        function Yr(a) {
            if (!a.d) a.d = lr(a), a.d.sort(function (a, c) {
                var d = a.A(),
                    f = a.D(),
                    g = c.A(),
                    h = c.D();
                return d == g && f == h ? 0 : Jr(d, f, g, h) ? 1 : -1
            });
            return a.d
        }

        function Zr(a) {
            this.b = Xr(lr(a), function (a) {
                return a.$f()
            })
        }

        function $r(a) {
            if (a) this.nc = Xr(Yr(a), function (a) {
                return hn(a)
            });
            mr[I](this, a ? this.A() : j, !1)
        }

        function as(a) {
            return (a = kr(a || l)) && bs(a)
        }

        function bs(a) {
            var b, c = !1;
            if (a[nb]) try {
                b = a[nb]()
            } catch (d) {
                return j
            } else if (a[Kb])
                if (a[Kb] > 1) {
                    b = new Vr;
                    for (var c = 0, f = a[Kb]; c < f; c++) b.b[s](a.getRangeAt(c));
                    return b
                } else b = a.getRangeAt(0), c = Jr(a.anchorNode, a.anchorOffset, a.focusNode, a.focusOffset);
                else return j;
            return b && b.addElement ? Pr(b) : Hr(Er(b), c)
        }

        function Jr(a, b, c, d) {
            if (a == c) return d < b;
            var f;
            if (a[v] == 1 && b)
                if (f = a[D][b]) a = f, b = 0;
                else if (ko(a, c)) return !0;
            if (c[v] == 1 && d)
                if (f = c[D][d]) c = f, d = 0;
                else if (ko(c, a)) return !1;
            return (lo(a, c) || b - d) > 0
        }

        function cs(a) {
            return a[E] || a[D][E]
        }

        function ds(a) {
            return !!a && a[v] == 3
        }

        function es(a, b) {
            if (ds(a)) {
                for (var c = b ? Pj : ok, d = b ? ok : Pj, f = [a[Kc]]; ds(a[c]);) a = a[c], f[s](a[Kc]), jo(a[d]);
                b || f.reverse();
                c = f[L](M);
                a[Kc] != c && Ia(a, c)
            }
            return a
        }

        function fs(a, b, c) {
            pp[I](this, a, c);
            this.k = b
        }

        function gs(a, b) {
            var c = a[K],
                d = Wm(c[D], a) + (b ? 0 : 1),
                c = hs(c, d, b);
            Ir(c.k, c.m, c.k, c.m)[yb]()
        }

        function is(a) {
            var b = as($n(Rn(a)));
            (a = js(a, b)) && a[yb]()
        }

        function ks(a) {
            for (var b = j, c = a[B]; c;) {
                var d = c[Mb];
                if (c[v] == 3)
                    if (c[Kc] == M) a[oc](c);
                    else b ? (b.nodeValue += c[Kc], a[oc](c)) : b = c;
                    else ks(c), b = j;
                c = d
            }
        }

        function js(a, b) {
            if (b) {
                var c = ls(b),
                    d = b.Nc();
                a: {
                    for (var d = d[v] == 1 ? d : d[K], f = 0; d;) {
                        var g = d && d[lb][Lc]();
                        if (d && ((d[v] != 1 ? j : X ? Ho(d, Ah) : Go(d, Ah)) == Lg || g == hl || g == fl || g == uj)) break a;
                        d = d[K];
                        f++
                    }
                    d = j
                }
            }
            d ? (d = oo(d, a), X ? ks(d) : d.normalize()) : a && (X ? ks(a) : a.normalize());
            return c ? c() : j
        }

        function ls(a) {
            var b = ms(hs(a.A(), a.D())),
                c = ns(b),
                d = b.k[Ub];
            if (b.k[v] == 3) b.k = j;
            var f = ms(hs(a.I(), a.aa())),
                g = ns(f),
                h = f.k[Ub];
            if (f.k[v] == 3) f.k = j;
            return function () {
                if (!b.k && d) b.k = d[Mb], b.k || (b = new os(d, cs(d)));
                if (!f.k && h) f.k = h[Mb], f.k || (f = new os(h, cs(h)));
                return Ir(b.k || c.k[B] || c.k, b.m, f.k || g.k[B] || g.k, f.m)
            }
        }

        function ms(a) {
            var b;
            if (a.k[v] == 3)
                for (b = a.k[Ub]; b && b[v] == 3; b = b[Ub]) a.m += cs(b);
            else b = a.k[Ub];
            var c = a.k[K];
            a.k = b ? b[Mb] : c[B];
            return a
        }

        function os(a, b) {
            this.k = a;
            this.m = b
        }

        function ns(a) {
            var b = a.k[K];
            return new os(b, Wm(b[D], a.k))
        }

        function hs(a, b, c) {
            for (; a[v] == 1;) {
                var d = a[D][b];
                if (!d && !a[pc]) break;
                d ? (a = d[Ub], c && a ? b = cs(a) : (a = d, b = 0)) : (a = a[pc], b = cs(a))
            }
            return new os(a, b)
        }

        function ps(a) {
            er[I](this, a)
        }

        function qs(a, b, c, d) {
            Fp[I](this, a, b, c);
            this.d = a.C();
            this.j = !1;
            this.yc = j;
            this.z = d || j
        }

        function rs(a) {
            return a.z || Ir(a.H.k, a.H.m, a.V.k, a.V.m)
        }

        function ss(a) {
            if (!a.p) {
                var b = ts(a.b);
                if (b) a.p = new ps(b)
            }
        }

        function us(a) {
            if (a.p) {
                try {
                    a.p.restore()
                } catch (b) {}
                a.p = j
            }
        }

        function vs(a) {
            for (var b; b = a.d.h(a.Fa());)
                if (b[Cc][Hc]() != Nf) b[Ec](vi);
                else break;
            return b
        }

        function ws(a, b, c) {
            b[Ec](vi);
            if (xm(b[G].cssText == j ? M : n(b[G].cssText)) && !Mn(b)[E]) {
                xs(a, b);
                var d = b[K],
                    f, g, h, k, o;
                if (c) f = a.H, g = a.V, h = Wm(d[D], b), k = Wm(b[D], f.k), o = Wm(b[D], g.k);
                Bo(b);
                c && (f[Dc](d[D][h + k], f.m), g[Dc](d[D][h + o], g.m))
            }
        }

        function xs(a, b) {
            if (a.j && a.yc && a.c == a.yc) {
                var c = Tm(b[D], function (a) {
                    return a[v] == 3 && a[Kc] == this.yc
                }, a) || Tm(b[D], function (a) {
                    return a[v] == 3 && a[Kc][x](this.yc) != -1
                }, a);
                if (c) {
                    var d = c[Kc],
                        f = a.yc,
                        g = d[x](f);
                    Ia(c, d[J](0, g) + d[J](g + f[E]));
                    V([a.H, a.V], function (a) {
                        c == a.k && g < a.m && a[Dc](c, r.max(g, a.m - f[E]))
                    });
                    a.yc = j
                }
            }
        }

        function ys(a, b) {
            if (a.b.Id() && a.j) {
                for (var c = !0, d, f; d = vs(a);) {
                    f = d[K];
                    if (b && c) {
                        var g = a.H,
                            h = a.V,
                            k = a.c,
                            o = Um(d[D], function (a) {
                                return ds(a) && a[Kc][x](k) >= 0
                            });
                        if (o >= 0) {
                            var c = d[D][o],
                                o = c[Kc][x](k),
                                q = o + k[E];
                            g[Dc](c, o);
                            h[Dc](c, q);
                            c = !1;
                            ws(a, d, !0)
                        }
                    }
                    a.d[zc](f, d) && ws(a, d)
                }
                a.j = !1
            }
        }

        function zs(a, b) {
            if (!a.H || !a.V || !a.H.Ef() || !a.V.Ef()) return !1;
            var c = a.H,
                d = a.V,
                f = {
                    type: Dg,
                    $h: a.q()
                }, g = S(b) && b[Ya](b[E] - 1) == N;
            g && (b = b[J](0, b[E] - 1));
            if (a.xc() && S(b) && !g) {
                var h = c.k,
                    g = h[Kc];
                Ia(h, g[J](0, c.m) + b + g[J](d.m));
                d.ed(c.m + b[E]);
                a.c = b
            } else {
                h = rs(a);
                S(b) && (b = a.d.b[$a](b));
                var h = h.vf(b),
                    k = h[K];
                g ? (g = p[xb](Tk), ka(g, hd), io(g, h), c[Dc](g, 0), d[Dc](g, 1)) : (g = Wm(k[D], h), c[Dc](k, g), d[Dc](k, g + 1));
                a.c = zm(a.d.wg(h))
            }
            a.f = d.qb();
            f.Zh = a.c;
            oq(a.b, f);
            return !0
        }

        function As(a, b) {
            this.z = a[Cc][Hc]() == mf;
            Yq[I](this, a, b || tk)
        }

        function ts(a) {
            var b = as(zo(a.C())),
                c;
            c = a.Z();
            c = Hr(zr(c), i);
            return b && b.xd() && c.Cb(b, !0) && $n(Rn(X ? b.Nc() : b.A())) == zo(a.C()) ? b : j
        }

        function Bs(a) {
            return !(a && !(Cs[a[Cc]] || a[Cc] && a[Cc][Hc]() == Ue))
        }

        function Ds(a, b, c) {
            var d = a.Z();
            if (!b || b == d || Bs(b)) return j;
            for (var f; !(f = c ? b[Ub] : b[Mb]);)
                if (b = b[K], !b || b == d || Bs(b)) return j;
            for (b = f; d = c ? b[pc] : b[B];) {
                if (!d || Bs(d)) return j;
                b = d
            }
            return !ds(b) ? j : !b[Kc] ? Ds(a, b, c) : b
        }

        function Es(a, b, c, d, f) {
            this.j = a;
            this.c = b;
            this.b = {};
            a = 0;
            for (b = c[E]; a < b; a++) this.b[c[Ya](a)] = !0;
            this.f = d || {};
            this.d = !! f
        }

        function Fs(a, b, c, d, f) {
            this.c = a;
            this.f = b;
            this.d = c;
            this.b = d;
            this.j = f || this.d
        }

        function Gs(a) {
            return $[a]
        }

        function Hs(a, b) {
            return a.b.isChar(b) && !a.b.b[b]
        }

        function Is(a) {
            return a.b.d
        }

        function Js(a, b) {
            this.X = a;
            this.B = b;
            this.b = [a, b][L](Vl)
        }

        function Ks(a, b) {
            var c = [a, b][L](Vl);
            return Ls[c] || (Ls[c] = new Js(a, b))
        }

        function Ms() {
            $.en = Ns;
            $.am = Os;
            $.ar = Ps;
            $.bn = Qs;
            $.zh = Rs;
            $.el = Ss;
            $.gu = Ts;
            $.iw = Us;
            $.hi = Vs;
            $.ja = Ws;
            $.kn = Xs;
            $.ml = Ys;
            $.mr = Zs;
            $.ne = $s;
            $.or = at;
            $.fa = bt;
            $.pa = ct;
            $.ru = dt;
            $.sa = et;
            $.sr = ft;
            $.si = gt;
            $.ta = ht;
            $.te = it;
            $.ti = jt;
            $.ur = kt
        }

        function lt(a, b) {
            var c;
            a instanceof lt ? (mt(this, b == j ? a.md : b), nt(this, a.fc), ot(this, a.Pd), pt(this, a.Hc), qt(this, a.od), rt(this, a.Ic), st(this, a.c.W()), tt(this, a.Od)) : a && (c = n(a)[qb](ut)) ? (mt(this, !! b), nt(this, c[1] || M, !0), ot(this, c[2] || M, !0), pt(this, c[3] || M, !0), qt(this, c[4]), rt(this, c[5] || M, !0), st(this, c[6] || M, !0), tt(this, c[7] || M, !0)) : (mt(this, !! b), this.c = new vt(j, this, this.md))
        }

        function nt(a, b, c) {
            wt(a);
            delete a.b;
            a.fc = c ? b ? ga(b) : M : b;
            if (a.fc) a.fc = a.fc[u](/:$/, M)
        }

        function ot(a, b, c) {
            wt(a);
            delete a.b;
            a.Pd = c ? b ? ga(b) : M : b
        }

        function pt(a, b, c) {
            wt(a);
            delete a.b;
            a.Hc = c ? b ? ga(b) : M : b
        }

        function qt(a, b) {
            wt(a);
            delete a.b;
            b ? (b = Number(b), (ha(b) || b < 0) && e(m("Bad port number " + b)), a.od = b) : a.od = j
        }

        function rt(a, b, c) {
            wt(a);
            delete a.b;
            a.Ic = c ? b ? ga(b) : M : b
        }

        function st(a, b, c) {
            wt(a);
            delete a.b;
            b instanceof vt ? (a.c = b, a.c.f = a, xt(a.c, a.md)) : (c || (b = yt(b, zt)), a.c = new vt(b, a, a.md))
        }

        function At(a, b, c) {
            wt(a);
            delete a.b;
            km(c) || (c = [n(c)]);
            a = a.c;
            Bt(a);
            Ct(a);
            b = Dt(a, b);
            if (a.hc(b)) {
                var d = a.L.get(b);
                km(d) ? a.G -= d[E] : a.G--
            }
            c[E] > 0 && (a.L.set(b, c), a.G += c[E])
        }

        function tt(a, b, c) {
            wt(a);
            delete a.b;
            a.Od = c ? b ? ga(b) : M : b
        }

        function wt(a) {
            a.Sj && e(m("Tried to modify a read-only Uri"))
        }

        function mt(a, b) {
            a.md = b;
            a.c && xt(a.c, b)
        }

        function yt(a, b) {
            var c = j;
            S(a) && (c = a, Et[Ma](c) || (c = encodeURI(a)), c.search(b) >= 0 && (c = c[u](b, Ft)));
            return c
        }

        function Ft(a) {
            a = a[wc](0);
            return $c + (a >> 4 & 15)[Wb](16) + (a & 15)[Wb](16)
        }

        function vt(a, b, c) {
            this.b = a || j;
            this.f = b || j;
            this.d = !! c
        }

        function Bt(a) {
            if (!a.L && (a.L = new wn, a.G = 0, a.b))
                for (var b = a.b[ic](ad), c = 0; c < b[E]; c++) {
                    var d = b[c][x](Ke),
                        f = j,
                        g = j;
                    d >= 0 ? (f = b[c][J](0, d), g = b[c][J](d + 1)) : f = b[c];
                    f = ga(f[u](/\+/g, N));
                    f = Dt(a, f);
                    Gt(a, f, g ? ga(g[u](/\+/g, N)) : M)
                }
        }

        function Gt(a, b, c) {
            Bt(a);
            Ct(a);
            b = Dt(a, b);
            if (a.hc(b)) {
                var d = a.L.get(b);
                km(d) ? d[s](c) : a.L.set(b, [d, c])
            } else a.L.set(b, c);
            a.G++
        }

        function Ct(a) {
            delete a.c;
            delete a.b;
            a.f && delete a.f.b
        }

        function Dt(a, b) {
            var c = n(b);
            a.d && (c = c[Lc]());
            return c
        }

        function xt(a, b) {
            b && !a.d && (Bt(a), Ct(a), vn(a.L, function (a, b) {
                var f = b[Lc]();
                b != f && (this.remove(b), Gt(this, f, a))
            }, a));
            a.d = b
        }

        function Ht(a, b) {
            this.c = new lt(a);
            this.b = b ? b : Zg;
            this.Fd = 5E3
        }

        function It(a, b, c, d) {
            return function () {
                Jt(a, b, !1);
                d && d(c)
            }
        }

        function Kt(a, b, c, d) {
            return function (f) {
                R.clearTimeout(d);
                Jt(a, b, !0);
                c[Ac](i, arguments)
            }
        }

        function Jt(a, b, c) {
            R[dc](function () {
                jo(b)
            }, 0);
            R._callbacks_[a] && (c ? delete R._callbacks_[a] : R._callbacks_[a] = hm)
        }

        function Lt(a) {
            this.b = ke;
            this.c = a
        }

        function Mt(a, b) {
            this.p = a || qi;
            this.f = b || ah
        }

        function Nt(a, b) {
            if (b.key == a.c) {
                var c = b.Th;
                if (c && c.Na) {
                    var d = S(c.Na) ? p[Wa](c.Na) : c.Na;
                    d && d[Cc] == Lf && typeof R._callbacks_[c.Na] == Vh && (c.Fd && R.clearTimeout(c.Fd), Jt(c.Na, d, !1))
                }
            }
        }

        function Ot(a, b) {
            a && Pt(this, a, b)
        }

        function Pt(a, b, c) {
            a.pf && Qt(a);
            a.J = b;
            a.of = Vp(a.J, pj, a, c);
            a.qg = Vp(a.J, oj, a.Jj, c, a);
            a.pf = Vp(a.J, qj, a.Kj, c, a)
        }

        function Qt(a) {
            if (a.of) fq(a.of), fq(a.qg), fq(a.pf), a.of = j, a.qg = j, a.pf = j;
            a.J = j;
            a.uc = -1;
            a.Vb = -1
        }

        function Rt(a, b, c, d) {
            d && this.Xc(d, i);
            wa(this, nj);
            sa(this, a);
            this.charCode = b;
            this.repeat = c
        }

        function St(a) {
            switch (a[C]) {
            case oj:
            case pj:
                if (a[hc] || a[gb] || a[Xb]) return !0;
                break;
            case gh:
                if (a[hc] || a[gb] || a[Xb] || a[Bc]) return !0;
                break;
            case nj:
                if (a[hc] || a[gb] || a[Xb] || a[Bc] || a.Lh) return !0
            }
            return !1
        }

        function Tt(a, b) {
            var c = a.Ha,
                d, f;
            X && a[C] == pj ? (d = b[A], f = d != 13 && d != 27 ? c[A] : 0) : Y && a[C] == pj ? (d = b[A], f = c[vb] >= 0 && c[vb] < 63232 && Iq(d) ? c[vb] : 0) : To ? (d = b[A], f = Iq(d) ? c[A] : 0) : (d = c[A] || b[A], f = c[vb] || 0, Ko && f == 63 && !d && (d = 191));
            var g = d,
                h = c.keyIdentifier;
            d ? d >= 63232 && d in Ut ? g = Ut[d] : d == 25 && a[Bc] && (g = 9) : h && h in Vt && (g = Vt[h]);
            d = g == b.lastKey;
            b.lastKey = g;
            return new Rt(g, f, d, c)
        }

        function Wt(a, b) {
            Ip[I](this, Mh);
            this.text = a;
            this.c = b
        }

        function Xt(a, b, c) {
            Wt[I](this, a[L](vd), b);
            this.d = a;
            this.f = !! c
        }

        function Yt() {}

        function Zt(a) {
            this.af = a || Pn();
            this.bf = $t
        }

        function au(a, b) {
            switch (a) {
            case 1:
                return b ? xh : Gh;
            case 2:
                return b ? ni : Dl;
            case 4:
                return b ? sg : uh;
            case 8:
                return b ? Fk : El;
            case 16:
                return b ? dh : Cl;
            case 32:
                return b ? Oh : Mg;
            case 64:
                return b ? Xj : hh
            }
            e(m("Invalid component state"))
        }

        function bu(a) {
            return a.M || (a.M = new Dq(a))
        }

        function cu(a, b) {
            a == b && e(m($f));
            b && a.Pa && a.Na && du(a.Pa, a.Na) && a.Pa != b && e(m($f));
            a.Pa = b;
            Zt.g.og[I](a, b)
        }

        function eu(a, b, c) {
            a.K && e(m(Ze));
            a.J || a.l();
            b ? b[db](a.J, c || j) : a.af.b[mc][Ja](a.J);
            (!a.Pa || a.Pa.K) && a.S()
        }

        function fu(a) {
            if (a.bf == j) a.bf = So(a.K ? a.J : a.af.b[mc]);
            return a.bf
        }

        function gu(a) {
            return a.Ja ? a.Ja[E] : 0
        }

        function du(a, b) {
            return a.Sb && b ? (b in a.Sb ? a.Sb[b] : i) || j : j
        }

        function hu(a, b) {
            return a.Ja ? a.Ja[b] || j : j
        }

        function iu(a, b, c) {
            a.Ja && V(a.Ja, b, c)
        }

        function ju(a, b) {
            return a.Ja && b ? Wm(a.Ja, b) : -1
        }

        function ku(a) {
            for (; a.Ja && a.Ja[E] != 0;) a[oc](hu(a, 0), !0)
        }

        function lu(a) {
            a = a || {};
            this.d = a.Ig || [13];
            this.f = a.Yb || [27];
            this.j = a.ub || [];
            this.c = a.Jg || [8];
            this.b = new wn
        }

        function mu(a, b, c) {
            return !!c[vb] && a.vg(b, c, n[ub](c[vb]))
        }

        function nu(a, b, c, d) {
            b = b.Fa();
            a.b.get(b) == j && a.b.set(b, new wn);
            a.b.get(b).set(c, d)
        }

        function ou() {
            lu[I](this, pu)
        }

        function qu(a, b, c, d) {
            Ip[I](this, a);
            this.c = b;
            this.value = c;
            this.d = d
        }

        function ru(a) {
            this.z = {};
            this.p = {};
            this.b = a || this.Ob()
        }

        function su(a) {
            ru[I](this, a)
        }

        function tu(a, b) {
            var c = uu(a);
            c && c[E] && V(c, function (a) {
                if (a) {
                    if (!b.f) {
                        var c = b.dc();
                        if (c) b.f = new Nq(c), b.f.f = !0
                    }
                    b.f && (c = Nk + a, b.f.gj(a) || (b.f.$g(a, a), b.j.w(b.f, c, b)), b.d[c] || (b.d[c] = []), a = b.d[c], Vm(a, this) || a[s](this))
                }
            }, a)
        }

        function vu(a, b) {
            V(uu(a), function (a) {
                var d = Nk + a,
                    f = b.d[d];
                f && (Xm(f, this), f[E] == 0 && (b.f.sj(a, a), b.j.Ca(b.f, d, b), delete b.d[d]))
            }, a)
        }

        function wu(a, b, c) {
            this.N = a;
            this.X = b;
            this.B = c
        }

        function xu() {
            this.b = {};
            this.b[Ks(Fh, Ag)] = mg;
            this.b[Ks(Fh, Cg)] = og;
            this.b[Ks(Fh, kj)] = pd;
            this.b[Ks(Fh, Lh)] = ng;
            this.b[Ks(Fh, Ak)] = pd;
            this.b[Ks(Fh, Vk)] = Zl;
            this.b[Ks(Fh, ql)] = mg
        }

        function yu(a, b, c, d) {
            for (var f = b.V, g = b.H, h = f.mc(); g.m > 0;)
                if (g[fb](-1), b = rp(g, g.m), zu(a, c, b)) {
                    g[fb](1);
                    break
                }
            if (d)
                for (d = h[E]; f.m < d;) {
                    b = rp(f, f.m);
                    if (zu(a, c, b)) break;
                    f[fb](1)
                }
        }

        function zu(a, b, c) {
            return !Hs($[b.X], c) && !(a.b[b] && a.b[b][x](c) != -1)
        }

        function Au(a, b, c) {
            if (!c) return !1;
            for (var d = c[E] - 1; d >= 0; d--)
                if (zu(a, b, c[Ya](d))) return !1;
            return !0
        }

        function Bu(a, b) {
            Ms();
            ru[I](this, a.id);
            this.d = a;
            this.zd = b
        }

        function Cu(a, b) {
            var c = a.b + he;
            return b[x](c) == 0 ? b[u](c, M) : b
        }

        function uu(a) {
            var b = a.d.b;
            return a.Ob() == a.b ? [b] : []
        }

        function Du(a, b, c) {
            return a[qc](b) && a.N(b) && Vm(a.oc(), c[C]) && a.Fe(a.ea(b))
        }

        function Eu(a, b) {
            a[Cb](xk, b);
            a.b = b
        }

        function Fu(a, b, c) {
            a[Cb](Eg + b, c)
        }

        function Gu(a, b) {
            a || e(m("Invalid class name " + a));
            om(b) || e(m("Invalid decorator function " + b))
        }

        function Hu() {}

        function Iu(a, b) {
            var c = new a;
            c.v = function () {
                return b
            };
            return c
        }

        function Ju(a, b, c) {
            if (a = a.h ? a.h() : a)
                if (X && !W(Ae)) {
                    var d = Ku(Mn(a), b);
                    d[s](b);
                    vm(c ? Nn : On, a)[Ac](j, d)
                } else c ? Nn(a, b) : On(a, b)
        }

        function Ku(a, b) {
            var c = [];
            b && (a = a[Xa]([b]));
            V([], function (d) {
                Lu(d, vm(Vm, a)) && (!b || Vm(d, b)) && c[s](d[L](hg))
            });
            return c
        }

        function Mu(a, b) {
            for (var c = []; b;) {
                var d = b & -b;
                c[s](a.lf(d));
                b &= ~d
            }
            return c
        }

        function Nu(a, b, c) {
            Zt[I](this, c);
            if (!b) {
                for (var b = this.constructor, d; b;) {
                    d = qm(b);
                    if (d = Ou[d]) break;
                    b = b.g ? b.g.constructor : j
                }
                b = d ? om(d.Q) ? d.Q() : new d : j
            }
            this.c = b;
            this.Hd(a)
        }

        function Pu(a, b) {
            a.K && b != a.Uf && Qu(a, b);
            a.Uf = b
        }

        function Qu(a, b) {
            var c = bu(a),
                d = a.h();
            b ? (c.w(d, Jj, a.ee).w(d, Gj, a.Fc).w(d, Kj, a.Jc).w(d, Ij, a.ue), X && c.w(d, th, a.Eh)) : (c.Ca(d, Jj, a.ee).Ca(d, Gj, a.Fc).Ca(d, Kj, a.Jc).Ca(d, Ij, a.ue), X && c.Ca(d, th, a.Eh))
        }

        function Ru(a, b) {
            Su(a, 2, b) && Tu(a, 2, b)
        }

        function Uu(a, b) {
            Su(a, 4, b) && Tu(a, 4, b)
        }

        function Vu(a, b) {
            Su(a, 16, b) && Tu(a, 16, b)
        }

        function Tu(a, b, c) {
            if (a.Ea & b && c != !! (a.U & b)) a.c.bg(a, b, c), a.U = c ? a.U | b : a.U & ~b
        }

        function Wu(a, b, c) {
            a.K && a.U & b && !c && e(m(Ze));
            !c && a.U & b && Tu(a, b, !1);
            a.Ea = c ? a.Ea | b : a.Ea & ~b
        }

        function Xu(a, b) {
            return !!(a.Dh & b) && !! (a.Ea & b)
        }

        function Su(a, b, c) {
            return !!(a.Ea & b) && !! (a.U & b) != c && (!(a.jg & b) || xq(a, au(b, c))) && !a.Oe
        }

        function Yu() {}

        function Zu(a, b) {
            Nu[I](this, j, a || Yu.Q(), b);
            Wu(this, 1, !1);
            Wu(this, 2, !1);
            Wu(this, 4, !1);
            Wu(this, 32, !1);
            this.U = 1
        }

        function $u() {}

        function av(a, b) {
            var c = new a;
            c.v = function () {
                return b
            };
            return c
        }

        function bv(a, b) {
            if (a) a.tabIndex = b ? 0 : -1
        }

        function cv(a) {
            var b = dv,
                a = a ? av(b, a) : om(b.Q) ? b.Q() : new b;
            ev(a);
            return a
        }

        function fv(a) {
            var b = gv,
                a = a ? Iu(b, a) : om(b.Q) ? b.Q() : new b;
            ev(a);
            return a
        }

        function ev(a) {
            if (km(i) && i[E] > 0) {
                var b = a.Tb;
                a.Tb = function (a) {
                    a = b[I](this, a);
                    an(a, i);
                    Tm(a, function (a) {
                        return a[x](hj) >= 0
                    }) && alert(nh + a[L](N));
                    return a
                }
            }
        }

        function hv(a, b) {
            this.c = a instanceof Jn ? a : new Jn(a, b)
        }

        function gv() {
            this.b = []
        }

        function iv(a, b) {
            var c = a.b[b];
            if (!c) {
                switch (b) {
                case 0:
                    c = a.v() + Od;
                    break;
                case 1:
                    c = a.v() + Fd;
                    break;
                case 2:
                    c = a.v() + Id
                }
                a.b[b] = c
            }
            return c
        }

        function jv(a, b, c) {
            a = iv(a, 2);
            return c.l(O, a, b)
        }

        function kv(a, b) {
            var c = a.ab(b);
            if (c) {
                var c = c[B],
                    d = iv(a, 1);
                return !!c && !! c[bc] && c[bc][x](d) != -1
            }
            return !1
        }

        function lv(a, b, c, d) {
            if (d != kv(a, c))
                if (d ? Nn(c, Oi) : On(c, Oi), c = a.ab(c), d) a = iv(a, 1), c[db](b.C().l(O, a), c[B] || j);
                else c[oc](c[B])
        }

        function dv() {}

        function mv(a, b, c, d) {
            Nu[I](this, a, d || gv.Q(), c);
            this.sd = b
        }

        function nv(a, b, c, d, f) {
            mv[I](this, a, b, c, d);
            this.b = f || ov
        }

        function ov(a) {
            return a[A] == 32 || a[A] == 13
        }

        function pv(a, b, c) {
            Zt[I](this, c);
            this.Xd = b || $u.Q();
            this.vd = a || Jl
        }

        function qv(a) {
            return a.td || a.h()
        }

        function rv(a, b) {
            if (a.Rb) {
                var c = qv(a),
                    d = a.K;
                a.td = b;
                var f = qv(a);
                if (d) a.td = c, sv(a, !1), a.td = b, Pt(tv(a), f), sv(a, !0)
            } else e(m("Can't set key event target for container that doesn't support keyboard focus!"))
        }

        function tv(a) {
            return a.Ce || (a.Ce = new Ot(qv(a)))
        }

        function sv(a, b) {
            var c = bu(a),
                d = qv(a);
            b ? c.w(d, Oh, a.Jh).w(d, Mg, a.mf).w(tv(a), nj, a.Ne) : c.Ca(d, Oh, a.Jh).Ca(d, Mg, a.mf).Ca(tv(a), nj, a.Ne)
        }

        function uv(a, b) {
            var c = b.h(),
                c = c.id || (c.id = b.Fa());
            if (!a.sc) a.sc = {};
            a.sc[c] = b
        }

        function vv(a, b) {
            var c = hu(a, b);
            c ? Ru(c, !0) : a.Ba > -1 && Ru(hu(a, a.Ba), !1)
        }

        function wv(a) {
            xv(a, function (a, c) {
                return (a + 1) % c
            }, gu(a) - 1)
        }

        function yv(a) {
            xv(a, function (a, c) {
                a--;
                return a < 0 ? c - 1 : a
            }, 0)
        }

        function xv(a, b, c) {
            for (var c = c < 0 ? ju(a, a.ua) : c, d = gu(a), c = b[I](a, c, d), f = 0; f <= d;) {
                var g = hu(a, c);
                if (g && a.Mh(g)) {
                    vv(a, c);
                    break
                }
                f++;
                c = b[I](a, c, d)
            }
        }

        function zv() {}

        function Av(a, b, c) {
            Nu[I](this, a, c || zv.Q(), b);
            Wu(this, 1, !1);
            Wu(this, 2, !1);
            Wu(this, 4, !1);
            Wu(this, 32, !1);
            this.U = 1
        }

        function Bv(a, b) {
            pv[I](this, Jl, b || dv.Q(), a);
            this.tb(!1)
        }

        function Cv(a, b) {
            if (ko(a.h(), b)) return !0;
            for (var c = 0, d = gu(a); c < d; c++) {
                var f = hu(a, c);
                if (typeof f.Wf == Vh && f.Wf(b)) return !0
            }
            return !1
        }

        function Dv(a, b) {
            Bv[I](this, a, b);
            this.Ed = !0;
            this.tb(!0);
            this.Ta(!1, !0);
            this.Mb = new wn
        }

        function Ev(a, b, c, d, f) {
            var g = a.P;
            (g || Lq() - a.kh < 150) && a.Ti ? a.Yb() : (a.jh = f || j, oq(a, Kg) && (c = typeof c != "undefined" ? c : 4, g || Aa(a.h()[G], li), Zo(a.h(), !0), b.b(a.h(), c, d), g || Aa(a.h()[G], Ml), vv(a, -1), a.Ta(!0)))
        }

        function Fv(a, b, c) {
            Dv[I](this, a, b);
            this.yj = c || [8, 27]
        }

        function Gv(a, b) {
            a.Dj = b
        }

        function Hv(a, b, c, d, f) {
            b = new nv(b, c, a.C(), d || a.Ff, a.Dj);
            a.Ib(b, !0);
            f && Eo(b.h(), f);
            return b
        }

        function Iv(a, b, c) {
            Ea(this, a);
            this.d = b || a;
            this.j = c || new Do(NaN, NaN, NaN, NaN);
            this.c = Rn(a);
            this.b = new Dq(this);
            Vp(this.d, [wl, Gj], this.Cf, !1, this)
        }

        function Jv(a, b) {
            if (xq(a, new Kv(Wk, a, b[Ob], b[Pb], b)) !== !1) a.ec = !0
        }

        function Lv(a) {
            var b = a[C];
            b == wl || b == vl ? a.Xc(a.Ha[eb][0], a[mb]) : (b == ul || b == tl) && a.Xc(a.Ha.changedTouches[0], a[mb])
        }

        function Mv(a, b, c) {
            var d = Ao(Pn(a.c));
            b += d.x - a.f.x;
            c += d.y - a.f.y;
            a.f = d;
            a.Ld += b;
            a.Md += c;
            b = Nv(a, a.Ld);
            a = Ov(a, a.Md);
            return new Jn(b, a)
        }

        function Pv(a, b, c, d) {
            na(a[H][G], c + pk);
            a[H][G].top = d + pk;
            xq(a, new Kv(Ch, a, b[Ob], b[Pb], b, c, d))
        }

        function Nv(a, b) {
            var c = a.j,
                d = !ha(c[y]) ? c[y] : j,
                c = !ha(c[t]) ? c[t] : 0;
            return r.min(d != j ? d + c : ca, r.max(d != j ? d : -ca, b))
        }

        function Ov(a, b) {
            var c = a.j,
                d = !ha(c.top) ? c.top : j,
                c = !ha(c[Gc]) ? c[Gc] : 0;
            return r.min(d != j ? d + c : ca, r.max(d != j ? d : -ca, b))
        }

        function Kv(a, b, c, d, f, g, h, k) {
            Ip[I](this, a);
            ya(this, c);
            za(this, d);
            this.c = f;
            na(this, gm(g) ? g : b.Ld);
            this.top = gm(h) ? h : b.Md;
            this.f = b;
            this.d = !! k
        }

        function Qv() {}

        function Rv() {}

        function Sv(a, b, c) {
            Nu[I](this, a, b || Rv.Q(), c)
        }

        function Tv() {}

        function Uv(a, b, c) {
            Sv[I](this, a, b || Tv.Q(), c)
        }

        function Vv(a, b) {
            Fv[I](this, a, b, []);
            this.xg = {
                32: 0
            };
            this.Rf = !1;
            this.T = 0;
            this.F = !0;
            this.Ya = {};
            this.ia = [];
            this.Ec = !1;
            this.d = j;
            this.uf = !1;
            this.p = j;
            this.Tj = this.b = 0;
            this.tf = this.z = j
        }

        function Wv(a) {
            a.Ec = !0;
            Mq(function () {
                this.Ec = !1
            }, 0, a)
        }

        function Xv(a, b, c) {
            var d = b.index;
            Xm(a.ia, b);
            on(a.Ya, d);
            var f = a.O(),
                g = b.Td[E],
                h = b.Ud[E],
                k = d - g;
            return f[J](k, d) == b.Td ? (a.Ia(f[J](0, k) + b.Ud + f[J](d)), (c ? h : 0) - g) : 0
        }

        function Yv(a, b) {
            var c = hu(a, b);
            c && c[qc]() && xq(a, new Ip(rg, c));
            return !0
        }

        function Zv(a, b, c) {
            var d = b ? a.T + a.jd : a.T - a.jd;
            if (d >= a.ac[E]) {
                if (a.F) a.F = xq(a, new Wt(a.Wa(), d)), a.jb.Ga(a.F)
            } else d < 0 || (a.ig(d), (mm(c) ? c : b) ? wv(a) : yv(a))
        }

        function $v(a, b) {
            var c = ao(Tk);
            qo(c, b);
            var d = a.c[D];
            a.b = a.b;
            a.c[db](c, d[cb](a.b));
            a.b++
        }

        function aw(a, b) {
            b != a.b && b >= 0 && b < a.c[D][E] && (a.c[oc](a.c[D][cb](b)), b < a.b && a.b--)
        }

        function bw(a, b) {
            var c = a.c[D][E],
                b = (b + c) % c;
            if (b >= 0 && b != a.b) {
                var d = a.c[D];
                a.c[oc](a.z);
                b < c - 1 ? a.c[db](a.z, d[cb](b)) : a.c[Ja](a.z);
                a.b = b
            }
        }

        function cw(a, b) {
            this.d = a;
            this.f = b;
            this.c = new Dq;
            this.b = j
        }

        function dw() {
            var a = cv(Qi),
                b = fv(Si);
            return new cw(a, b)
        }

        function ew(a) {
            this.b = {};
            if (a)
                for (var b = 0; b < a[E]; b++) this.b[fw(a[b])] = j
        }

        function fw(a) {
            return a in gw || n(a)[wc](0) == 32 ? N + a : a
        }

        function hw(a, b) {
            this.b = this.Lb = a;
            this.gc = [];
            this.Vf(b)
        }

        function iw(a, b) {
            V(a.gc, b)
        }

        function jw(a, b) {
            this.rc = {};
            this.df = {};
            this.c = [];
            hw[I](this, a, b)
        }

        function kw(a) {
            var b = a.b;
            lw(a, b, 1, 0);
            return a.q(b)
        }

        function lw(a, b, c, d) {
            b = a.q(b);
            b != a.Lb && (a.rc[b] == i ? (a.rc[b] = c, a.df[b] = d) : (a.rc[b] += c, a.df[b] += d), a.rc[b] < 0 && (a.rc[b] = 0))
        }

        function mw(a) {
            var b = M;
            b += a.Lb;
            V(a.gc, function (a) {
                this.rc[a] != i && (b += Ce + a + xd + this.df[a] + xd + this.rc[a] + Ce)
            }, a);
            return b
        }

        function nw() {
            this.b = {}
        }

        function ow(a) {
            return a && pw[a]
        }

        function qw(a) {
            var b = /^([aei]l) /i;
            return a && (rw[a] || a[u](b, Zc))
        }

        function sw(a) {
            return a && rw[a]
        }

        function tw(a) {
            return a && rw[a]
        }

        function uw(a) {
            if (!a) return M;
            var b = vw[a];
            if (b) return b;
            var c = ww[a];
            c && (b = c[1] = c[0][Ya]((c[0][x](c[1]) + 1) % c[E]));
            return b || a
        }

        function xw(a, b) {
            return (a[Sa](-1) == Mj && b != Tl ? a[Sa](0, -1) + yw.nn : a) + b
        }

        function zw() {
            var a = new nw,
                b = Ks(Fh, Ag);
            a.b[b[Wb]()] = ow;
            b = Ks(Fh, Cg);
            a.b[b[Wb]()] = qw;
            b = Ks(Fh, Ul);
            a.b[b[Wb]()] = uw;
            b = Ks(Fh, Lh);
            a.b[b[Wb]()] = sw;
            b = Ks(Fh, ql);
            a.b[b[Wb]()] = ow;
            b = Ks(Fh, Gl);
            a.b[b[Wb]()] = tw;
            return a
        }

        function Aw(a, b) {
            this.text = km(a) ? a : [a];
            this.Xb = !! b;
            qa(this, ti)
        }

        function Bw(a, b, c, d) {
            Aw[I](this, a, c || b.X == b.B);
            this.X = b.X;
            this.B = b.B;
            this.d = this.b = 1;
            this.f = !! d;
            this.j = this.c = !1
        }

        function Cw(a, b, c) {
            a = new Bw(a, b);
            a.b = c > 0 ? c : 0;
            return a
        }

        function Dw(a, b, c, d) {
            a = new Bw(a, b);
            a.b = c > 0 ? c : 0;
            a.c = !0;
            a.j = d;
            return a
        }

        function Ew(a, b) {
            a.d = b > 0 ? b : 0
        }

        function Fw(a) {
            return Ks(a.X, a.B)
        }

        function Gw(a, b) {
            return a.X == b.X && a.B == b.B && !a.f && !b.f && !a.Xb && !b.Xb && a[Qa][E] + b[Qa][E] < 5 ? (an(a[Qa], b[Qa]), !0) : !1
        }

        function Hw(a, b) {
            return Lu(b[Qa], function (a) {
                return Vm(this[Qa], a)
            }, a) && a.b >= (b.b || 0)
        }

        function Iw(a) {
            if (a.B == Ul) return hk;
            else if (a.B == mj || a.B == lj) return zl;
            return yl + a.B
        }

        function Jw(a, b, c, d) {
            Bu[I](this, a, b);
            this.ia = c;
            this.c = d;
            this.Zc = zw();
            this.M = new ou;
            this.j = {};
            this.oa = j;
            this.F = {};
            this.f = new Jq(a.Jd);
            this.T = !1
        }

        function Kw(a) {
            var b = a.c.Xa(j);
            b.Qe(a.M);
            b[Bb](rg, T(a.oh, a, b));
            var c = T(a.lh, a, b);
            b[Bb](bl, c);
            b[Bb](zh, c);
            c = T(a.mh, a);
            b[Bb](Mh, c);
            a.f[Bb](sl, T(a.nh, a, b))
        }

        function Lw(a) {
            return (a = a[qb](/['a-z]+/i)) ? a[0] : M
        }

        function Mw(a, b, c, d) {
            if (!Lw(c)) return !1;
            Bq(a.oa, a.b).yd = c;
            var f = Ks(Fh, Ul),
                a = a.ia.Ad(Cw(c, f, d), T(a.Yi, a, b));
            return mm(a)
        }

        function Nw(a, b, c) {
            var d = cn(arguments, 2),
                f = [];
            V(a, function (a) {
                var c = om(b) ? b : a[b];
                f[s](c[Ac](a, d))
            })
        }

        function Ow(a, b, c) {
            for (var d = cn(arguments, 2), f = a[E], g = 0; g < f; g++) {
                var h = a[g];
                if ((om(b) ? b : h[b])[Ac](h, d)) return !0
            }
            return !1
        }

        function Pw() {
            this.b = []
        }

        function Qw(a) {
            if (a.Bb != a.Qb) {
                var b = a.b[a.Bb];
                delete a.b[a.Bb];
                a.Bb++;
                return b
            }
        }

        function Rw(a) {
            return a.Bb == a.Qb ? i : a.b[a.Bb]
        }

        function Sw(a, b) {
            this.ub = a;
            this.b = b
        }

        function Tw() {
            this.d = !1;
            this.f = {};
            this.M = {};
            this.b = new Pw
        }

        function Uw(a, b) {
            return Sm(b, function (a, b) {
                return a[b] || (a[b] = {})
            }, a)
        }

        function Vw(a, b, c) {
            var d = [Fw(b)[Wb]()],
                f = b.q();
            b.Xb && (f = Uw(a.M, d)[f]);
            return Uw(c || a.f, d)[f]
        }

        function Ww(a) {
            var b;
            if (!a.b.Sa()) {
                if (a.d && a.c) {
                    var c = a.c.ub;
                    b = Rw(a.b);
                    if (Hw(c, b.ub)) {
                        Qw(a.b);
                        return
                    }
                    a.bh(a.c);
                    a.c = j
                }
                if (!a.c) b = Qw(a.b), a.dh(b, T(a.Mi, a, b)), a.c = b
            }
        }

        function Xw(a, b, c, d) {
            Tw[I](this);
            this.d = !! c;
            this.F = a;
            this.p = b;
            this.j = {};
            this.z = {};
            this.T = d || mp;
            if (l[jb] && l[jb].Timer) this.Ac = new l[jb].Timer
        }

        function Yw(a, b, c) {
            a.Ac && (c ? a.Ac.tick(b, c) : a.Ac.tick(b))
        }

        function Zw(a, b, c) {
            var d = b;
            S(b) && c && (d = new Bw(b, c));
            return d && d.Xb ? d : Vw(a, d, a.z)
        }

        function $w(a, b) {
            var c = Uw(a.z, [Fw(b)[Wb]()]);
            b.c ? c[b.q()] = b : V(b[Qa], function (a, f) {
                var g = M;
                f >= 0 && f < b[Qa][E] && (g = b[Qa][f]);
                g = new Bw(g, Fw(b), b.Xb, b.f);
                Ew(g, b.d);
                var h = b.b;
                g.b = h > 0 ? h : 0;
                c[a] = g
            })
        }

        function ax(a, b) {
            var c = [];
            kn(a.j, function (a, d) {
                var h = Vw(this, new Bw(d, b));
                if (h) c[s](mw(h)), h.rc = {}, h.df = {}
            }, a);
            var d = M;
            c[E] > 0 && (d = c[L](vd) + Ee);
            a.j = {};
            return d
        }

        function bx(a, b, c, d) {
            Bu[I](this, a, b);
            this.c = c;
            this.f = d
        }

        function cx(a, b, c) {
            Bu[I](this, a, b);
            this.c = {};
            this.f = T(this.aj, this);
            this.j = c;
            this.Zc = zw();
            this.oa = j
        }

        function dx(a, b) {
            if (St(b)) return !0;
            var c = b[C] == pj,
                d = b[C] == oj;
            if (!d && !c) return !0;
            if (!c && Z) return !0;
            var f = b[A] == 13 || b[A] == 9;
            if (!Z) {
                if (c && f) return !0;
                if (d && !f) return !0
            }
            c = b[A] || b[vb];
            return b[Bc] && c == 32 ? !0 : Z && b[A] == 46 ? !0 : Z && b[A] == 8 ? !0 : Z && !Gq(b) ? !0 : !a.Cd() ? !0 : !1
        }

        function ex(a, b, c) {
            a.id = this.Ob();
            Bu[I](this, a, b);
            this.c = Sm(c, function (c, f) {
                c[s](f(a, b));
                return c
            }, [])
        }

        function fx() {}

        function gx(a, b, c, d) {
            return nm(d) && d >= b && d <= c ? d : a
        }

        function hx(a) {
            this.kb = a.kb;
            this.Af = a.Af;
            this.zc = gx(5, 5, 200, a.zc);
            this.ad = gx(5, 2, this.zc, a.ad);
            this.Dd = gx(5, 5, this.zc - this.ad, a.Dd);
            this.Jd = gx(100, 50, 500, a.Jd)
        }

        function ix(a, b) {
            var c = a % b;
            return c * b < 0 ? c + b : c
        }

        function jx(a, b) {
            Fv[I](this, a, b, []);
            this.p = 5;
            this.F = 0;
            this.Ec = this.Ya = !1;
            this.d = j;
            this.ac = kx(this, [
                [37, this.Rg],
                [39, this.Sg],
                [36, this.Tg],
                [35, this.Ug],
                [8, this.Ng],
                [46, this.Qg],
                [13, this.Ve],
                [27, this.ld],
                [17, 66, this.Rg],
                [17, 70, this.Sg],
                [17, 65, this.Tg],
                [17, 69, this.Ug],
                [17, 72, this.Ng],
                [17, 68, this.Qg],
                [17, 77, this.Ve],
                [17, 71, this.ld]
            ]);
            this.jd = kx(this, [
                [37, this.Vg],
                [39, this.Wg],
                [38, this.Mf],
                [40, this.We],
                [33, this.Pg],
                [34, this.Og],
                [36, this.Bi],
                [35, this.Ci],
                [13, this.Ve],
                [27, this.ld],
                [8, this.ld],
                [9, this.We],
                [32, this.We],
                [16, 32, this.Mf],
                [16, 37, this.Of],
                [16, 39, this.Nf],
                [16, 38, this.Pg],
                [16, 40, this.Og],
                [17, 66, this.Vg],
                [17, 70, this.Wg],
                [17, 80, this.Mf],
                [17, 78, this.We],
                [17, 65, this.Di],
                [17, 69, this.Ei],
                [17, 73, this.Of],
                [17, 79, this.Nf],
                [17, 81, this.Of],
                [17, 87, this.Nf],
                [17, 77, this.Ve],
                [17, 72, this.ld],
                [17, 71, this.ld]
            ]);
            this.T = {};
            this.z = [];
            this.ia = ih;
            this.b = [];
            this.R = 0;
            this.f = !0
        }

        function kx(a, b) {
            var c = {}, d = [16, 17, 91, 18];
            V(b, function (a) {
                var b = Vm(a, 16),
                    h = Vm(a, 17),
                    k = Vm(a, 91),
                    o = Vm(a, 18),
                    q = Tm(a, function (a) {
                        return nm(a) && !Vm(d, a)
                    }),
                    a = Tm(a, om);
                c[q + ((b ? 1024 : 0) + (h ? 2048 : 0) + (k ? 4096 : 0) + (o ? 8192 : 0))] = a
            }, a);
            return c
        }

        function lx(a, b) {
            var c = b[A] + ((b[Bc] ? 1024 : 0) + (b[hc] ? 2048 : 0) + (b[gb] ? 4096 : 0) + (b[Xb] ? 8192 : 0));
            return (c = mx(a) ? a.ac[c] : a.jd[c]) ? (c = c[I](a, b), mm(c) ? c : !0) : !1
        }

        function nx(a, b) {
            var c = a.F + b,
                d = a.b[a.R];
            if (!(0 <= c && c < d.lb[E])) return !1;
            la(d, c);
            vv(a, b);
            ox(a);
            return !0
        }

        function px(a, b) {
            var c = a.b[a.R].lb;
            if (c[E] != 0) {
                var d = a.b[a.R][Za] + b;
                d < 0 && (d = c[E] - 1);
                if ((r[Va](d / a.p) + 2) * a.p >= c[E] && qx(a)) a.f = xq(a, new Xt(rx(a), c[E] + 1));
                if (c[E] <= d) {
                    if (qx(a)) return;
                    d = 0
                }
                sx(a, d)
            }
        }

        function tx(a) {
            a.Ec = !0;
            Mq(function () {
                this.Ec = !1
            }, 0, a)
        }

        function ux(a) {
            a[jc]();
            a[bb]();
            return !0
        }

        function vx(a, b, c) {
            var d = b.index;
            Xm(a.z, b);
            on(a.T, d);
            var f = a.O(),
                g = b.Td[E],
                h = b.Ud[E],
                k = d - g;
            if (f[J](k, d) != b.Td) return 0;
            a.Ia(f[J](0, k) + b.Ud + f[J](d));
            return (c ? h : 0) - g
        }

        function mx(a) {
            return a.ia == ih
        }

        function wx(a) {
            return a.ia == lh
        }

        function xx(a, b) {
            var c = Xr(a.b, function (a) {
                return a.Lc
            }),
                d = Xr(b, function (a) {
                    return a.Lb
                });
            en(c, d) ? (a.b = Xr(a.b, function (a, c) {
                var d = a.lb[a[Za]],
                    k = !d ? 0 : Um(b[c].gc, function (a) {
                        return a.q() == d.q()
                    });
                return new yx(b[c].Lb, b[c].gc, k)
            }), a.f = !0) : zx(a, b)
        }

        function zx(a, b) {
            a.b = Xr(b, function (a) {
                return new yx(a.Lb, a.gc)
            });
            a.R = 0;
            a.f = !0
        }

        function Ax(a) {
            sx(a, a.b[a.R][Za])
        }

        function sx(a, b) {
            if (!(a.R < 0 || a.b[E] <= a.R)) {
                var c = a.b[a.R].lb,
                    b = c[E] < 1 ? 0 : r.min(r.max(b, 0), c[E] - 1);
                a.F = r[Va](b / a.p) * a.p;
                ku(a);
                for (var d = 0; d < a.p; d++) {
                    var f = a.F + d;
                    f < c[E] && (f = c[f], Hv(a, f.Ye(d), f))
                }
                vv(a, b - a.F);
                la(a.b[a.R], b);
                tx(a);
                ox(a)
            }
        }

        function ox(a) {
            if (wx(a)) {
                var b = a.C(),
                    c = a.La().v(),
                    d = c + de,
                    f = c + ce;
                b.Kg(a.c);
                b.fj(a.c, Xr(Bx(a), function (a, c) {
                    return b.l(Tk, c == this.R ? d : f, a[u](/ /g, Xl))
                }, a));
                Cx(a)
            }
        }

        function Dx(a, b, c) {
            a.Ya = !0;
            a.Yb();
            a.Ya = !1;
            b = new Ip(b ? bl : zh, a);
            if (c) b.b = c;
            return oq(a, b)
        }

        function rx(a) {
            return Xr(a.b, function (a) {
                return a.Lc
            })
        }

        function Bx(a) {
            return Xr(a.b, function (a) {
                return a.lb[E] <= a[Za] ? a.Lc : a.lb[a[Za]].q()
            }, a)
        }

        function Cx(a) {
            var b = a.b[a.R],
                b = b[Za] + 1 + ie + b.lb[E];
            qx(a) && (b += ud);
            qo(a.jb, b)
        }

        function qx(a) {
            return a.b[a.R].lb[E] >= Sm(a.b, function (a, c) {
                return r.max(a, c.lb[E])
            }, 0) && a.f
        }

        function yx(a, b, c) {
            this.Lc = a;
            this.lb = b || [];
            la(this, nm(c) && 0 <= c && c < this.lb[E] ? c : 0)
        }

        function Ex() {
            lu[I](this, Fx)
        }

        function Gx(a) {
            var b = a.O(),
                a = (a = a.Nb()) ? a.D() : b[E];
            return {
                left: b[J](0, a),
                right: b[J](a)
            }
        }

        function Hx(a, b, c, d) {
            Bu[I](this, a, b);
            this.M = c;
            this.j = d;
            this.f = new Ex;
            this.c = j
        }

        function Ix(a, b) {
            this.c = a;
            this.d = b;
            this.b = new Dq
        }

        function Jx() {
            var a = cv(Mi),
                b = fv(Ni);
            return new Ix(a, b)
        }

        function Kx(a) {
            this.N = !! a.N;
            this.Sh = "am,ar,bn,zh,el,gu,iw,hi,ja,kn,ml,mr,ne,or,fa,pa,ru,sa,sr,si,ta,te,ti,ur" [ic](vd);
            this.X = a.yg || Fh;
            this.B = a.zg;
            if (a.Vd) S(a.Vd) ? Lx(a.Vd) : pm(a.Vd), this.b = a.Vd;
            this.Bf = gx(120, 40, 120, a.Bf);
            this.Jd = gx(100, 50, 1E3, a.Jd);
            this.Jf = gx(5, 2, 10, a.Jf);
            this.kb = a.kb != i ? a.kb : 3
        }

        function Lx(a) {
            a = Rq(a);
            return a[E] != 1 || !(a[0].Wc ^ Mx.Oj) || !(a[0].Wc ^ Mx.NONE) || /[^a-zA-Z]/ [Ma](n[ub](a[0][A])) ? j : {
                keyCode: a[0][A],
                Wc: a[0].Wc
            }
        }

        function Nx(a, b) {
            this.b = a;
            this.c = b
        }

        function Ox(a, b, c, d) {
            b = (c = c[0]) && c[d] ? nm(c[d]) ? c[d] : Sm(c[d], function (a, b) {
                return a + b
            }, 0) : b[E];
            return new Nx(a, b)
        }

        function Px(a, b) {
            this.c = a;
            this.b = b
        }

        function Qx() {
            var a = cv(ij),
                b = fv(jj);
            return new Px(a, b)
        }

        function Rx(a, b) {
            var c = b.c[Sx];
            if (!c) c = new Fv(Pn(p[mc]), a.c), c.Ff = a.b, eu(c, i), b.c[Sx] = c;
            return c
        }

        function Tx(a, b, c, d, f, g) {
            var h = Rx(a, b);
            h.j = f;
            ku(h);
            g && Eo(h.h(), g);
            iw(d, function (a) {
                Hv(h, a, a)
            });
            a = d.Lb;
            Hv(h, a, a, i, {
                direction: zj
            });
            Ev(h, c);
            Y && (zo(h.C())[wb](), h.h()[wb]());
            wv(h)
        }

        function Ux(a, b) {
            var c = b || new Kx({
                Vd: ph,
                N: !0,
                yg: Fh,
                zg: ki,
                Jf: 5,
                Jd: 100
            }),
                d = new xu,
                f = new Xw(a, new hx({
                    kb: c.kb,
                    ad: 5
                })),
                g = new Xw(a, new hx({
                    kb: c.kb,
                    ad: 10,
                    Dd: 40,
                    zc: 50
                }), !0, Ox),
                h = new Xw(a, new hx({
                    kb: c.kb,
                    ad: 18,
                    Dd: 90,
                    zc: 198
                }), !0, Ox),
                k = Qx(),
                o = dw(),
                q = Jx();
            return new ex(c, d, [
                function (a, b) {
                    return new cx(a, b, f)
                },
                function (a, b) {
                    return new bx(a, b, f, k)
                },
                function (a, b) {
                    return new Jw(a, b, g, o)
                },
                function (a, b) {
                    return new Hx(a, b, h, q)
                }
            ])
        }

        function Vx() {}

        function Wx(a, b, c) {
            return c.l(O, Gi + (b + Bd), a)
        }

        function Xx(a, b, c, d) {
            Sv[I](this, a, c || Vx.Q(), d);
            Wu(this, 64, !0);
            b && this.Rd(b);
            this.z = new Jq(500);
            if ((Yx || Zx) && !W(ye)) this.Pe = !0
        }

        function $x(a) {
            a.b || a.Rd(new Bv(a.C()));
            return a.b || j
        }

        function ay(a, b, c) {
            var d = bu(a),
                c = c ? d.w : d.Ca;
            c[I](d, b, rg, a.Sc);
            c[I](d, b, ni, a.Gj);
            c[I](d, b, Dl, a.Hj)
        }

        function by(a, b, c, d) {
            Xx[I](this, a, b, c || cy.Q(), d);
            Wu(this, 16, !0)
        }

        function cy() {}

        function dy(a, b, c) {
            mv[I](this, a, b, c);
            Wu(this, 8, !0);
            if (a = this.h()) b = this.La(), a && (Eu(a, Dj), lv(b, this, a, !0))
        }

        function ey() {}

        function fy(a, b, c) {
            Sv[I](this, a, b || ey.Q(), c)
        }

        function gy(a) {
            var b = {}, a = n(a),
                c = a[Ya](0) == Vc ? a : Vc + a;
            if (hy[Ma](c)) return b.sf = iy(c), wa(b, ji), b;
            else {
                a: {
                    var d = a[qb](jy);
                    if (d) {
                        var c = Number(d[1]),
                            f = Number(d[2]),
                            d = Number(d[3]);
                        if (c >= 0 && c <= 255 && f >= 0 && f <= 255 && d >= 0 && d <= 255) {
                            c = [c, f, d];
                            break a
                        }
                    }
                    c = []
                }
                if (c[E]) return f = c[0], a = c[1], c = c[2], f = Number(f), a = Number(a), c = Number(c), (ha(f) || f < 0 || f > 255 || ha(a) || a < 0 || a > 255 || ha(c) || c < 0 || c > 255) && e(m('"(' + f + vd + a + vd + c + '") is not a valid RGB color')), f = ky(f[Wb](16)), a = ky(a[Wb](16)), c = ky(c[Wb](16)), b.sf = Vc + f + a + c, wa(b, wk), b;
                else if (ly &&
                    (c = ly[a[Lc]()])) return b.sf = c, wa(b, Nj), b
            }
            e(m(a + " is not a valid color string"))
        }

        function iy(a) {
            hy[Ma](a) || e(m(pd + a + "' is not a valid hex color"));
            a[E] == 4 && (a = a[u](my, Wc));
            return a[Lc]()
        }

        function ky(a) {
            return a[E] == 1 ? le + a : a
        }

        function ny() {}

        function oy(a, b) {
            return b.l(O, Bi, a)
        }

        function py(a, b) {
            if (a && a[B]) {
                var c;
                try {
                    c = gy(b).sf
                } catch (d) {
                    c = j
                }
                a[B][G].borderBottomColor = c || (X ? M : Al)
            }
        }

        function qy() {}

        function ry(a, b, c, d) {
            for (var f = [], g = 0, h = 0; g < c[Gc]; g++) {
                for (var k = [], o = 0; o < c[t]; o++) {
                    var q = b && b[h++];
                    k[s](sy(a, q, d))
                }
                f[s](d.l(xl, a.v() + ae, k))
            }
            a = d.l(fl, a.v() + fe, d.l(gl, a.v() + Ad, f));
            a.cellSpacing = 0;
            a.cellPadding = 0;
            Eu(a, di);
            return a
        }

        function sy(a, b, c) {
            a = c.l(hl, {
                "class": a.v() + Cd,
                id: a.v() + Cd + ty++
            }, b);
            Eu(a, ei);
            return a
        }

        function uy(a, b, c) {
            for (b = b.h(); c && c[v] == 1 && c != b;) {
                if (c[Cc] == Uf && Vm(Mn(c), a.v() + Cd)) return c[B];
                c = c[K]
            }
            return j
        }

        function vy(a, b, c, d) {
            c && (c = c[K], a = a.v() + Dd, d ? Nn(c, a) : On(c, a), Fu(b.h()[B], ug, c.id))
        }

        function wy(a) {
            this.b = [];
            xy(this, a)
        }

        function xy(a, b) {
            b && (V(b, function (a) {
                this.pd(a, !1)
            }, a), an(a.b, b))
        }

        function yy(a, b) {
            if (b != a.$a) a.pd(a.$a, !1), a.$a = b, a.pd(b, !0);
            oq(a, Fk)
        }

        function zy(a, b, c) {
            Nu[I](this, a, b || qy.Q(), c)
        }

        function Ay(a) {
            var b = a.Oa;
            return b && b[a.ic]
        }

        function By(a, b) {
            if (b != a.ic) Cy(a, a.ic, !1), a.ic = b, Cy(a, b, !0)
        }

        function Dy(a, b) {
            if (a.r) {
                var c = a.r;
                yy(c, c.b[b] || j)
            }
        }

        function Cy(a, b, c) {
            if (a.h()) {
                var d = a.Oa;
                d && b >= 0 && b < d[E] && vy(a.La(), a, d[b], c)
            }
        }

        function Ey(a) {
            var b = a.Oa;
            b ? a.eb && a.eb[t] ? (b = r[Ua](b[E] / a.eb[t]), (!nm(a.eb[Gc]) || a.eb[Gc] < b) && Ha(a.eb, b)) : (b = r[Ua](r.sqrt(b[E])), a.eb = new Ln(b, b)) : a.eb = new Ln(0, 0)
        }

        function Fy(a, b, c) {
            this.b = a || [];
            zy[I](this, j, b || qy.Q(), c);
            this.b = this.b;
            this.d = j;
            a = Gy(this);
            this.c.Cc(this.h(), a);
            this.Hd(a)
        }

        function Gy(a) {
            return Xr(a.b, function (a) {
                var c = this.C().l(O, {
                    "class": this.La().v() + Hd,
                    style: Ig + a
                });
                a[Ya](0) == Vc && (a = iy(a), a = Jf + [da(a[Rb](1, 2), 16), da(a[Rb](3, 2), 16), da(a[Rb](5, 2), 16)][L](wd) + sd);
                c.title = a;
                return c
            }, a)
        }

        function Hy(a) {
            if (a) try {
                return gy(a).sf
            } catch (b) {}
            return j
        }

        function Iy(a, b, c, d) {
            Xx[I](this, a, b, c || ny.Q(), d)
        }

        function Jy(a) {
            var b = new Bv(a);
            kn(Ky, function (c) {
                c = new Fy(c, j, a);
                c.h() && e(m(Ze));
                c.eb = nm(8) ? new Ln(8, i) : 8;
                Ey(c);
                b.Ib(c, !0)
            });
            return b
        }

        function Ly() {}

        function My() {}

        function Ny(a, b, c, d) {
            Iy[I](this, a, b, c || My.Q(), d)
        }

        function Oy(a, b, c, d) {
            Xx[I](this, a, b, c || Ly.Q(), d)
        }

        function Py(a, b, c, d) {
            Xx[I](this, a, b, c, d);
            this.Zf = a;
            Qy(this)
        }

        function Ry(a, b) {
            a.r = new wy;
            b && iu(b, function (a) {
                this.r.Vc(a)
            }, a);
            Sy(a)
        }

        function Sy(a) {
            a.r && bu(a).w(a.r, Fk, a.Ej)
        }

        function Qy(a) {
            var b = a.r ? a.r.$a : j,
                b = b ? b.Kc() : a.Zf;
            a.c.Cc(a.h(), b);
            a.Hd(b)
        }

        function Ty(a, b, c, d) {
            Py[I](this, a, b, c || Ly.Q(), d)
        }

        function Uy(a, b, c) {
            mv[I](this, a, b, c);
            Wu(this, 16, !0);
            if (a = this.h()) b = this.La(), a && (Eu(a, Cj), lv(b, this, a, !0))
        }

        function Vy(a, b, c) {
            Sv[I](this, a, b || Tv.Q(), c);
            Wu(this, 16, !0)
        }

        function Wy() {
            return X && W(ze) && !W(Ae)
        }

        function Xy(a) {
            a || Yy(af, Yj);
            var b = Zy,
                c = a[b.Vh],
                d = a[b.Wh],
                f = a[b.Uh],
                a = a[b.Xh],
                g;
            this.Gb = [];
            var b = T(function (a) {
                Vm($y, a) || Yy(af, ag + a + Pc)
            }, this),
                h;
            km(d) && d[E] > 0 ? (V(d, b), h = d) : S(d) ? (h = az[d]) ? this.Gb = h : (g = d, b(g), h = bz) : Yy(af, qf + g + De);
            this.Gb = h;
            g = g || h[0];
            c == Fh && Vm($y, g) || Yy(af, bg + c + Rc + g);
            S(f) ? (d = Lx(f)) || Yy(af, yf) : f && Yy(af, yf);
            c = new Kx({
                kb: 8,
                yg: c,
                zg: g,
                N: a,
                Sh: this.Gb
            });
            this.z = f;
            this.j = {};
            this.f = {};
            this.d = Ux(new Mt(i, ah), c);
            this.M = cz;
            this.p = new yq(!0);
            this.c = new zq(this.p);
            qn(Bq(this.c, this.d.b), new wu(c.N,
                c.X, c.B));
            try {
                Cq(this.c, this.d)
            } catch (k) {}
            this.b = new wq;
            this.c[Bb](sh, this.Yh)
        }

        function dz() {
            var a = {}, b;
            for (b in ez) {
                var c = ez[b];
                Wm($y, c) != -1 && (a[$[c].c] = c)
            }
            fz.Ah.uj = a
        }

        function gz(a) {
            return function (b) {
                Vu(a, b.transliterationEnabled)
            }
        }

        function hz(a) {
            return function (b) {
                var c = b.targetLanguage;
                iu(a, function (a) {
                    a.sd.language == c ? Vu(a, !0) : Vu(a, !1)
                })
            }
        }

        function iz(a) {
            return function (b) {
                for (var c = 0; c < this.Gb[E]; ++c) {
                    var d = this.Gb[c],
                        d = Wy() ? Xi + d : $i + d;
                    if (On(a, d)) break
                }
                b = b.targetLanguage;
                b = Wy() ? Xi + b : $i + b;
                Nn(a, b)
            }
        }

        function Yy(a, b) {
            e(m("Exception in " + a + ": " + b))
        }

        function jz(a, b) {
            var c = a.d.ea(a.c),
                d;
            for (d in a.f) a.f[d][Gb](a.M.Kd, new wu(b, c.X, c.B));
            d = 0;
            for (var f in a.f) d++;
            if (d == 0) Bq(a.c, a.d.b).N = b;
            oq(a.b, {
                type: Ck,
                transliterationEnabled: b,
                sourceLanguage: c.X,
                targetLanguage: c.B,
                destinationLanguage: c.B
            })
        }

        function kz(a) {
            for (var b in fz)
                if (fz[b].code == a) {
                    a = fz[b].uj;
                    b = {};
                    var c = i;
                    for (c in a) b[c] = a[c];
                    return b
                }
            return {}
        }

        function lz() {
            return X && W(ze) || Z && W(ne) || Y && W(we)
        };
        var mz = new em;
        l.jstiming = {
            Timer: em,
            load: mz
        };
        try {
            var nz = j;
            l.chrome && l.chrome.csi && (nz = r[Va](l.chrome.csi().pageT));
            nz == j && l.gtbExternal && (nz = l.gtbExternal.pageT());
            nz == j && l[Sb] && (nz = l[Sb].pageT);
            nz && (l[jb].pt = nz)
        } catch (oz) {};
        var R = this,
            rm = "closure_uid_" + r[Va](r.random() * 2147483648)[Wb](36),
            sm = 0,
            Lq = Date.now || function () {
                return +new Date
            };
        fa[F].bind = fa[F][Jb] || function (a, b) {
            if (arguments[E] > 1) {
                var c = ia[F][Sa][I](arguments, 1);
                c[Jc](this, a);
                return T[Ac](j, c)
            } else return T(this, a)
        };
        var Bm = /^[a-zA-Z0-9\-_.!~*'()]*$/,
            Em = /&/g,
            Fm = /</g,
            Gm = />/g,
            Hm = /\"/g,
            Dm = /[&<>\"]/,
            Lm = /&([^;\s<&]+);?/g,
            fr = r.random() * 2147483648 | 0,
            Qm = {};
        var Ym = ia[F],
            Wm = Ym[x] ? function (a, b, c) {
                return Ym[x][I](a, b, c)
            } : function (a, b, c) {
                c = c == j ? 0 : c < 0 ? r.max(0, a[E] + c) : c;
                if (S(a)) return !S(b) || b[E] != 1 ? -1 : a[x](b, c);
                for (; c < a[E]; c++)
                    if (c in a && a[c] === b) return c;
                return -1
            }, V = Ym[zb] ? function (a, b, c) {
                Ym[zb][I](a, b, c)
            } : function (a, b, c) {
                for (var d = a[E], f = S(a) ? a[ic](M) : a, g = 0; g < d; g++) g in f && b[I](c, f[g], g, a)
            }, Xr = Ym.map ? function (a, b, c) {
                return Ym.map[I](a, b, c)
            } : function (a, b, c) {
                for (var d = a[E], f = ia(d), g = S(a) ? a[ic](M) : a, h = 0; h < d; h++) h in g && (f[h] = b[I](c, g[h], h, a));
                return f
            }, vq =
                Ym.some ? function (a, b, c) {
                    return Ym.some[I](a, b, c)
            } : function (a, b, c) {
                for (var d = a[E], f = S(a) ? a[ic](M) : a, g = 0; g < d; g++)
                    if (g in f && b[I](c, f[g], g, a)) return !0;
                return !1
            }, Lu = Ym.every ? function (a, b, c) {
                return Ym.every[I](a, b, c)
            } : function (a, b, c) {
                for (var d = a[E], f = S(a) ? a[ic](M) : a, g = 0; g < d; g++)
                    if (g in f && !b[I](c, f[g], g, a)) return !1;
                return !0
            };
        var jn = "StopIteration" in R ? R.StopIteration : m("StopIteration");
        Da(gn[F], function () {
            e(jn)
        });
        gn[F].wc = function () {
            return this
        };
        var rn = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",");
        Q = wn[F];
        Q.G = 0;
        Q.Sd = 0;
        Q.yb = function () {
            xn(this);
            for (var a = [], b = 0; b < this.b[E]; b++) a[s](this.c[this.b[b]]);
            return a
        };
        Q.Pb = function () {
            xn(this);
            return this.b[Xa]()
        };
        Q.hc = function (a) {
            return yn(this.c, a)
        };
        Q.Sa = function () {
            return this.G == 0
        };
        xa(Q, function () {
            this.c = {};
            Ba(this.b, 0);
            this.Sd = this.G = 0
        });
        ra(Q, function (a) {
            return yn(this.c, a) ? (delete this.c[a], this.G--, this.Sd++, this.b[E] > 2 * this.G && xn(this), !0) : !1
        });
        Q.get = function (a, b) {
            return yn(this.c, a) ? this.c[a] : b
        };
        Q.set = function (a, b) {
            yn(this.c, a) || (this.G++, this.b[s](a), this.Sd++);
            this.c[a] = b
        };
        Q.W = function () {
            return new wn(this)
        };
        Q.wc = function (a) {
            xn(this);
            var b = 0,
                c = this.b,
                d = this.c,
                f = this.Sd,
                g = this,
                h = new gn;
            Da(h, function () {
                for (;;) {
                    f != g.Sd && e(m("The map has changed since the iterator was created"));
                    b >= c[E] && e(jn);
                    var h = c[b++];
                    return a ? h : d[h]
                }
            });
            return h
        };
        var pz, qz, rz, sz, tz, Ko, Pq;
        tz = sz = rz = qz = pz = !1;
        var uz;
        if (uz = zn()) {
            var vz = An();
            pz = uz[x]("Opera") == 0;
            qz = !pz && uz[x]("MSIE") != -1;
            sz = (rz = !pz && uz[x]("WebKit") != -1) && uz[x]("Mobile") != -1;
            tz = !pz && !rz && vz.product == "Gecko"
        }
        var To = pz,
            X = qz,
            Z = tz,
            Y = rz,
            Yn = sz,
            wz = An(),
            xz = wz && wz.platform || M;
        Ko = xz[x]("Mac") != -1;
        Pq = xz[x]("Win") != -1;
        var Lo = !! An() && (An().appVersion || M)[x]("X11") != -1,
            yz;
        a: {
            var zz = M,
                Az;
            if (To && R.opera) var Bz = R.opera.version,
            zz = typeof Bz == Vh ? Bz() : Bz;
            else if (Z ? Az = /rv\:([^\);]+)(\)|;)/ : X ? Az = /MSIE\s+([^\);]+)(\)|;)/ : Y && (Az = /WebKit\/(\S+)/), Az) var Cz = Az[Pa](zn()),
            zz = Cz ? Cz[1] : M;
            if (X) {
                var Dz, Ez = R[ec];
                Dz = Ez ? Ez.documentMode : i;
                if (Dz > ea(zz)) {
                    yz = n(Dz);
                    break a
                }
            }
            yz = zz
        }
        var Cn = yz,
            Bn = {}, En = {};
        var Sn;
        Jn[F].W = function () {
            return new Jn(this.x, this.y)
        };
        Q = Ln[F];
        Q.W = function () {
            return new Ln(this[t], this[Gc])
        };
        Q.Sa = function () {
            return !(this[t] * this[Gc])
        };
        Q.ceil = function () {
            ja(this, r[Ua](this[t]));
            Ha(this, r[Ua](this[Gc]));
            return this
        };
        Q.floor = function () {
            ja(this, r[Va](this[t]));
            Ha(this, r[Va](this[Gc]));
            return this
        };
        Q.round = function () {
            ja(this, r.round(this[t]));
            Ha(this, r.round(this[Gc]));
            return this
        };
        var co = !X || Dn();
        !Z && !X || X && Dn() || Z && W("1.9.1");
        var to = X && !W("9");
        var Wn = {
            cellpadding: "cellPadding",
            cellspacing: "cellSpacing",
            colspan: "colSpan",
            rowspan: "rowSpan",
            valign: "vAlign",
            height: "height",
            width: "width",
            usemap: "useMap",
            frameborder: "frameBorder",
            maxlength: "maxLength",
            type: "type"
        }, wo = {
                SCRIPT: 1,
                STYLE: 1,
                HEAD: 1,
                IFRAME: 1,
                OBJECT: 1
            }, xo = {
                IMG: N,
                BR: Nc
            };
        Q = Qn[F];
        Q.C = Pn;
        Q.h = function (a) {
            return S(a) ? this.b[Wa](a) : a
        };
        Q.Dg = Vn;
        Q.l = function (a, b, c) {
            return bo(this.b, arguments)
        };
        Q.Aa = function (a, b) {
            a[Ja](b)
        };
        Q.fj = function (a, b) {
            eo(Rn(a), a, arguments, 1)
        };
        Q.Kg = ho;
        Fa(Q, ko);
        Q.wg = so;
        Co[F].W = function () {
            return new Co(this.top, this[Mc], this[xc], this[y])
        };
        Fa(Co[F], function (a) {
            return !this || !a ? !1 : a instanceof Co ? a[y] >= this[y] && a[Mc] <= this[Mc] && a.top >= this.top && a[xc] <= this[xc] : a.x >= this[y] && a.x <= this[Mc] && a.y >= this.top && a.y <= this[xc]
        });
        Do[F].W = function () {
            return new Do(this[y], this.top, this[t], this[Gc])
        };
        Fa(Do[F], function (a) {
            return a instanceof Do ? this[y] <= a[y] && this[y] + this[t] >= a[y] + a[t] && this.top <= a.top && this.top + this[Gc] >= a.top + a[Gc] : a.x >= this[y] && a.x <= this[y] + this[t] && a.y >= this.top && a.y <= this.top + this[Gc]
        });
        var ap = Z ? "MozUserSelect" : Y ? "WebkitUserSelect" : j,
            ep = {
                thin: 2,
                medium: 4,
                thick: 6
            }, ip = /[^\d]+$/,
            jp = {
                cm: 1,
                "in": 1,
                mm: 1,
                pc: 1,
                pt: 1
            }, kp = {
                em: 1,
                ex: 1
            };
        var Fz = lp(!1),
            Gz = lp(!0);
        np[F].Oe = !1;
        np[F].s = function () {
            if (!this.Oe) this.Oe = !0, this.n()
        };
        np[F].n = function () {
            this.Qj && op[Ac](j, this.Qj)
        };
        U(pp, np);
        pp[F].n = function () {
            this.b = j
        };
        pp[F].ef = function (a) {
            return !!a && this.b == a.b && this.m == a.m
        };
        pp[F].move = function (a) {
            return this.ed(this.m + a)
        };
        U(sp, pp);
        Q = sp[F];
        Q.qb = function () {
            return new sp(this.b, this.m)
        };
        Q.Tf = Gz;
        Q.mc = function () {
            return this.b[ab] || M
        };
        Q.Ef = function () {
            return !!this.b[nc] && !! this.b[K] && this.m >= 0 && this.m <= this.mc()[E]
        };
        Q.ed = function (a) {
            if (a <= this.mc()[E] && a >= 0) this.m = a;
            return this
        };
        wp[F].b = bm();
        U(xp, wp);
        xp[F].b = function (a, b, c) {
            up(this.c, this.d, a, b, i, c)
        };
        U(yp, xp);
        yp[F].f = P(5);
        yp[F].b = function (a, b, c, d) {
            var f = up(this.c, this.d, a, b, j, c, 10, d);
            if (f & 496) {
                var g = zp(f, this.d),
                    b = zp(f, b),
                    f = up(this.c, g, a, b, j, c, 10, d);
                f & 496 && (g = zp(f, g), b = zp(f, b), this.j ? up(this.c, g, a, b, j, c, this.f(), d) : up(this.c, g, a, b, j, c, 0, d))
            }
        };
        U(Ap, yp);
        Ap[F].f = function () {
            return 65 | (this.p ? 32 : 132)
        };
        U(Bp, wp);
        Bp[F].b = function (a, b, c, d) {
            var f = No(a);
            up(f, 0, a, b, new Jn(this.c.x + f[vc], this.c.y + f[Tb]), c, j, d)
        };
        U(Cp, Bp);
        Cp[F].b = function (a, b, c, d) {
            var f = No(a),
                f = Qo(f),
                g;
            g = Pn(a);
            g = Zn(g.b);
            g = new Jn(this.c.x + g[vc], this.c.y + g[Tb]);
            var h = b,
                k = vp(g, a, h, c, f, 10, d);
            if ((k & 496) != 0) {
                if (k & 16 || k & 32) h ^= 2;
                if (k & 64 || k & 128) h ^= 1;
                k = vp(g, a, h, c, f, 10, d);
                (k & 496) != 0 && vp(g, a, b, c, f, i, d)
            }
        };
        U(Fp, np);
        Q = Fp[F];
        Q.n = function () {
            this.b = this.f = this.V = this.H = j
        };
        Q.Fa = function () {
            if (!this.Na)
                for (var a = this.b.C(); a.h(this.Na = qm(this.b) + ig + (this.b.rb++)[Wb](36)););
            return this.Na
        };
        Q.Sa = function () {
            return this.H.ef(this.V)
        };
        Q.move = function (a) {
            this.H[fb](a);
            this.V[fb](a)
        };
        Q.q = function () {
            return this.xc() ? this.H.mc()[J](this.H.m, this.V.m) : M
        };
        Ga(Q, function (a, b) {
            this.H = a;
            this.V = b
        });
        var Hz;
        U(Ip, np);
        Q = Ip[F];
        Q.n = function () {
            delete this[C];
            delete this[H];
            delete this[mb]
        };
        Q.Yc = !1;
        Q.Ee = !0;
        Q.stopPropagation = function () {
            this.Yc = !0
        };
        Q.preventDefault = function () {
            this.Ee = !1
        };
        U(Kp, Fp);
        Q = Kp[F];
        Q.n = function () {
            delete this.b.p[this.Fa()]
        };
        Q.xc = Gz;
        Q.Kf = function () {
            this.b.p[this.Fa()] = this
        };
        Q.replace = function (a) {
            if (!S(a)) return !1;
            if (this.q() == a) return !0;
            if (this.c != this.q()) return !1;
            var b = this.b.Z(),
                c = Fn(b, !1)[1],
                d = {
                    type: Dg,
                    $h: this.c
                }, f = b[Tb],
                g = this.H,
                h = this.V;
            b.value = qp(g, 0, g.m) + a + qp(h, h.m);
            var k = g.m + a[E];
            c >= h.m ? c += a[E] - this.c[E] : c > g.m && (c = k);
            if (k != h.m) {
                var o = k - h.m;
                ar(this.b, function (a) {
                    a.H.m >= h.m && a[fb](o)
                })
            }
            h.ed(k);
            this.f && this.f.ed(c);
            this.b.Mg() && (g = h.qb(), g.ed(c), this.b.Nd(g));
            b.scrollTop = f;
            d.Zh = this.c = a;
            oq(this.b, d);
            return !0
        };
        Q.Hb = function (a) {
            this.b.Nd(a ? this.V : this.H)
        };
        Q.Me = function (a, b) {
            var c = this.H,
                d = this.V,
                f = c.b,
                g;
            if (X && !W(9) && f[C] && f[C][Hc]() == Vf) {
                var h = c.b,
                    k = d || c.qb()[fb](1),
                    o = Pn(h),
                    q = as(zo(o)).gd(),
                    d = q[Ka](),
                    w = 0,
                    z = f = 0;
                if (zo(Pn(c.b)).frameElement) z = Uo(zo(o).frameElement), f = z.x, z = z.y;
                c = h[ab][J](c.m, k.m) || n[ub](160);
                try {
                    g = hp(h) + 2
                } catch (ua) {
                    g = 16
                }
                if (So(h)) {
                    for (k = q[Nb](); k.boundingHeight <= g && k[$b] == k[Qa];)
                        if (w = q.boundingLeft - k.boundingLeft, k.moveStart(ch, -1) == 0) break;
                    h = Ro(h).x;
                    h = r.max(d[y] - w, h);
                    b && (h += c[E] * 4)
                } else h = d[y], b && (h -= c[E] * 4);
                g = new Cp(h + f, d.top + g + z)
            } else g =
                Dp(c, d, a);
            return g
        };
        Lp[N] = hm;
        var Op = !X || Dn(),
            Iz = X && !W(Be);
        U(Mp, Ip);
        var Pp = [1, 4, 2];
        Q = Mp[F];
        Ea(Q, j);
        Q.relatedTarget = j;
        Q.offsetX = 0;
        Q.offsetY = 0;
        ya(Q, 0);
        za(Q, 0);
        oa(Q, 0);
        pa(Q, 0);
        Q.button = 0;
        sa(Q, 0);
        Q.charCode = 0;
        Q.ctrlKey = !1;
        Q.altKey = !1;
        Q.shiftKey = !1;
        Q.metaKey = !1;
        Q.Lh = !1;
        Q.Ha = j;
        Q.Xc = function (a, b) {
            var c = wa(this, a[C]);
            Ip[I](this, c);
            Ea(this, a[H] || a.srcElement);
            ma(this, b);
            var d = a[Oa];
            if (d) {
                if (Z) {
                    var f;
                    a: {
                        try {
                            Lp(d[lb]);
                            f = !0;
                            break a
                        } catch (g) {}
                        f = !1
                    }
                    f || (d = j)
                }
            } else if (c == Jj) d = a.fromElement;
            else if (c == Ij) d = a.toElement;
            this.relatedTarget = d;
            this.offsetX = a.offsetX !== i ? a.offsetX : a.layerX;
            this.offsetY = a.offsetY !== i ? a.offsetY : a.layerY;
            ya(this, a[Ob] !== i ? a[Ob] : a.pageX);
            za(this, a[Pb] !== i ? a[Pb] : a.pageY);
            oa(this, a[ob] || 0);
            pa(this, a[pb] || 0);
            this.button = a.button;
            sa(this, a[A] || 0);
            this.charCode =
                a[vb] || (c == pj ? a[A] : 0);
            this.ctrlKey = a[hc];
            this.altKey = a[Xb];
            this.shiftKey = a[Bc];
            this.metaKey = a[gb];
            this.Lh = Ko ? a[gb] : a[hc];
            this.state = a.state;
            this.Ha = a;
            delete this.Ee;
            delete this.Yc
        };
        Q.stopPropagation = function () {
            Mp.g[jc][I](this);
            this.Ha[jc] ? this.Ha[jc]() : this.Ha.cancelBubble = !0
        };
        Q.preventDefault = function () {
            Mp.g[bb][I](this);
            var a = this.Ha;
            if (a[bb]) a[bb]();
            else if (a.returnValue = !1, Iz) try {
                (a[hc] || a[A] >= 112 && a[A] <= 123) && sa(a, -1)
            } catch (b) {}
        };
        Q.Nj = dm("Ha");
        Q.n = function () {
            Mp.g.n[I](this);
            this.Ha = j;
            Ea(this, j);
            ma(this, j);
            this.relatedTarget = j
        };
        U(Qp, np);
        Qp[F].b = j;
        Qp[F].d = j;
        Qp[F].n = function () {
            Qp.g.n[I](this);
            for (var a = this.c; a[E];) Tp(this, a.pop());
            delete this.c
        };
        var Jz, Kz = (Jz = "ScriptEngine" in R && R.ScriptEngine() == "JScript") ? R.ScriptEngineMajorVersion() + he + R.ScriptEngineMinorVersion() + he + R.ScriptEngineBuildVersion() : le;
        var Lz = 0;
        Q = Up[F];
        Q.key = 0;
        Q.Gc = !1;
        Q.gh = !1;
        Q.Xc = function (a, b, c, d, f, g) {
            om(a) ? this.b = !0 : a && a[Eb] && om(a[Eb]) ? this.b = !1 : e(m(xf));
            this.nd = a;
            this.c = b;
            this.src = c;
            wa(this, d);
            this.capture = !! f;
            this.Xe = g;
            this.gh = !1;
            this.key = ++Lz;
            this.Gc = !1
        };
        va(Q, function (a) {
            return this.b ? this.nd[I](this.Xe || this.src, a) : this.nd[Eb][I](this.nd, a)
        });
        var Xp, kq, Yp, jq, Zp, Mz, hq, $p, iq, Nz, Oz;
        (function () {
            function a() {
                return {
                    G: 0,
                    mb: 0
                }
            }

            function b() {
                return []
            }

            function c() {
                function a(b) {
                    b = h[I](a.src, a.key, b);
                    if (!b) return b
                }
                return a
            }

            function d() {
                return new Up
            }

            function f() {
                return new Mp
            }
            var g = Jz && !(Mm(Kz, te) >= 0),
                h;
            Mz = function (a) {
                h = a
            };
            if (g) {
                Xp = function () {
                    return Rp(k)
                };
                kq = function (a) {
                    Sp(k, a)
                };
                Yp = function () {
                    return Rp(o)
                };
                jq = function (a) {
                    Sp(o, a)
                };
                Zp = function () {
                    return Rp(q)
                };
                hq = function () {
                    Sp(q, c())
                };
                $p = function () {
                    return Rp(w)
                };
                iq = function (a) {
                    Sp(w, a)
                };
                Nz = function () {
                    return Rp(z)
                };
                Oz = function (a) {
                    Sp(z,
                        a)
                };
                var k = new Qp(0, 600);
                k.b = a;
                var o = new Qp(0, 600);
                o.b = b;
                var q = new Qp(0, 600);
                q.b = c;
                var w = new Qp(0, 600);
                w.b = d;
                var z = new Qp(0, 600);
                z.b = f
            } else Xp = a, kq = hm, Yp = b, jq = hm, Zp = c, hq = hm, $p = d, iq = hm, Nz = f, Oz = hm
        })();
        var aq = {}, Wp = {}, bq = {}, cq = {};
        Mz(function (a, b) {
            if (!aq[a]) return !0;
            var c = aq[a],
                d = c[C],
                f = Wp;
            if (!(d in f)) return !0;
            var f = f[d],
                g, h;
            Hz === i && (Hz = X && !R[Bb]);
            if (Hz) {
                var k;
                if (!(k = b)) a: {
                    k = "window.event" [ic](he);
                    for (var o = R; g = k[Na]();)
                        if (o[g] != j) o = o[g];
                        else {
                            k = j;
                            break a
                        }
                    k = o
                }
                g = k;
                k = !0 in f;
                o = !1 in f;
                if (k) {
                    if (g[A] < 0 || g.returnValue != i) return !0;
                    a: {
                        var q = !1;
                        if (g[A] == 0) try {
                            sa(g, -1);
                            break a
                        } catch (w) {
                            q = !0
                        }
                        if (q || g.returnValue == i) g.returnValue = !0
                    }
                }
                q = Nz();
                q.Xc(g, this);
                g = !0;
                try {
                    if (k) {
                        for (var z = Yp(), ua = q[mb]; ua; ua = ua[K]) z[s](ua);
                        h = f[!0];
                        h.mb = h.G;
                        for (var La =
                            z[E] - 1; !q.Yc && La >= 0 && h.mb; La--) ma(q, z[La]), g &= mq(h, z[La], d, !0, q);
                        if (o) {
                            h = f[!1];
                            h.mb = h.G;
                            for (La = 0; !q.Yc && La < z[E] && h.mb; La++) ma(q, z[La]), g &= mq(h, z[La], d, !1, q)
                        }
                    } else g = nq(c, q)
                } finally {
                    z && (Ba(z, 0), jq(z)), q.s(), Oz(q)
                }
                return g
            }
            d = new Mp(b, this);
            try {
                g = nq(c, d)
            } finally {
                d.s()
            }
            return g
        });
        var qq, uq = {};
        U(wq, np);
        Q = wq[F];
        Q.xh = !0;
        Q.kf = j;
        Q.og = cm("kf");
        Q.addEventListener = function (a, b, c, d) {
            Vp(this, a, b, c, d)
        };
        Q.removeEventListener = function (a, b, c, d) {
            dq(this, a, b, c, d)
        };
        Q.n = function () {
            wq.g.n[I](this);
            lq(this);
            this.kf = j
        };
        U(yq, np);
        yq[F].get = function (a, b) {
            var c = qm(a),
                c = this.c ? this.b : this.b[c] || (this.b[c] = {}),
                d = S(b) ? b : b.b;
            return this.d ? c : c[d] || (c[d] = {})
        };
        var Aq = new yq;
        U(zq, wq);
        zq[F].n = function () {
            kn(this.qc, function (a) {
                var b = a.Ob();
                this.qc[b] && (a.Ab(this), delete this.qc[b])
            }, this);
            this.c = this.ia = this.qc = j;
            zq.g.n[I](this)
        };
        zq[F].execCommand = function (a, b) {
            var c, d = [this];
            an(d, arguments);
            for (var f in this.qc)
                if (c = this.qc[f], c[qc](this) && c.tg(a)) return c[Gb][Ac](c, d)
        };
        var Pz, Qz, Rz, Sz, Tz, Uz, Vz;
        Vz = Uz = Tz = Sz = Rz = Qz = Pz = !1;
        var Wz = zn();
        Wz && (Wz[x]("Firefox") != -1 ? Pz = !0 : Wz[x]("Camino") != -1 ? Qz = !0 : Wz[x]("iPhone") != -1 || Wz[x]("iPod") != -1 ? Rz = !0 : Wz[x]("iPad") != -1 ? Sz = !0 : Wz[x]("Android") != -1 ? Tz = !0 : Wz[x]("Chrome") != -1 ? Uz = !0 : Wz[x]("Safari") != -1 && (Vz = !0));
        var Xz = Qz,
            Yx = Rz,
            Zx = Sz,
            Yz = Tz,
            Zz = Uz,
            $z = Vz;
        var aA;
        a: {
            var bA = M,
                cA, dA;
            if (Pz) cA = /Firefox\/([0-9.]+)/;
            else if (X || To) {
                aA = Cn;
                break a
            } else Zz ? cA = /Chrome\/([0-9.]+)/ : $z ? cA = /Version\/([0-9.]+)/ : Yx || Zx ? (cA = /Version\/(\S+).*Mobile\/(\S+)/, dA = !0) : Yz ? cA = /Android\s+([0-9.]+)(?:.*Version\/([0-9.]+))?/ : Xz && (cA = /Camino\/([0-9.]+)/); if (cA) var eA = cA[Pa](zn()),
            bA = eA ? dA ? eA[1] + he + eA[2] : eA[2] || eA[1] : M;
            aA = bA
        }
        var fA = aA;
        X && Dn();
        Z || Y || To || X && Dn();
        Y && W("534.16");
        X && W("7.0");
        Z && W(pe);
        X || To || Z && W(qe);
        X || Y && W(ve);
        Y && W("531");
        Y && W(xe);
        Z && W(qe) || X || To || Y && W("531");
        Z || Y && W("526");
        Zz && Mm(fA, "4") >= 0 || $z && W("533") || Z && W("2.0");
        To && W("11.10");
        Zz && Mm(fA, "12");
        U(Dq, np);
        var gA = [];
        Dq[F].w = function (a, b, c, d, f) {
            km(b) || (gA[0] = b, b = gA);
            for (var g = 0; g < b[E]; g++) this.b[s](Vp(a, b[g], c || this, d || !1, f || this.c || this));
            return this
        };
        Dq[F].Ca = function (a, b, c, d, f) {
            if (km(b))
                for (var g = 0; g < b[E]; g++) this.Ca(a, b[g], c, d, f);
            else {
                a: {
                    c = c || this;
                    f = f || this.c || this;
                    d = !! d;
                    if (a = eq(a, b, d))
                        for (b = 0; b < a[E]; b++)
                            if (!a[b].Gc && a[b].nd == c && a[b][kb] == d && a[b].Xe == f) {
                                a = a[b];
                                break a
                            }
                    a = j
                }
                if (a) a = a.key, fq(a), Xm(this.b, a)
            }
            return this
        };
        Dq[F].n = function () {
            Dq.g.n[I](this);
            Fq(this)
        };
        va(Dq[F], function () {
            e(m("EventHandler.handleEvent not implemented"))
        });
        var Tq = {
            8: "backspace",
            9: "tab",
            13: Ih,
            16: Jk,
            17: oh,
            18: yg,
            19: "pause",
            20: "caps-lock",
            27: "esc",
            32: "space",
            33: "pg-up",
            34: "pg-down",
            35: Hh,
            36: "home",
            37: "left",
            38: "up",
            39: "right",
            40: "down",
            45: "insert",
            46: "delete",
            48: le,
            49: me,
            50: "2",
            51: "3",
            52: "4",
            53: "5",
            54: ze,
            55: Ae,
            56: Be,
            57: "9",
            61: "equals",
            65: pg,
            66: "b",
            67: "c",
            68: "d",
            69: "e",
            70: Kh,
            71: Wh,
            72: "h",
            73: ti,
            74: "j",
            75: "k",
            76: "l",
            77: "m",
            78: Mj,
            79: Uj,
            80: bk,
            81: "q",
            82: "r",
            83: Bk,
            84: "t",
            85: "u",
            86: "v",
            87: "w",
            88: "x",
            89: Tl,
            90: "z",
            93: "context",
            96: "num-0",
            97: "num-1",
            98: "num-2",
            99: "num-3",
            100: "num-4",
            101: "num-5",
            102: "num-6",
            103: "num-7",
            104: "num-8",
            105: "num-9",
            106: "num-multiply",
            107: "num-plus",
            109: "num-minus",
            110: "num-period",
            111: "num-division",
            112: "f1",
            113: "f2",
            114: "f3",
            115: "f4",
            116: "f5",
            117: "f6",
            118: "f7",
            119: "f8",
            120: "f9",
            121: "f10",
            122: "f11",
            123: "f12",
            187: "equals",
            188: vd,
            190: he,
            191: ie,
            220: "\\",
            224: "win"
        };
        U(Jq, wq);
        Jq[F].d = !1;
        var Kq = R.window;
        Q = Jq[F];
        Q.Dc = j;
        Q.Li = function () {
            if (this.d) {
                var a = Lq() - this.j;
                if (a > 0 && a < this.c * 0.8) this.Dc = this.b[dc](this.f, this.c - a);
                else if (oq(this, sl), this.d) this.Dc = this.b[dc](this.f, this.c), this.j = Lq()
            }
        };
        Q.start = function () {
            this.d = !0;
            if (!this.Dc) this.Dc = this.b[dc](this.f, this.c), this.j = Lq()
        };
        Q.stop = function () {
            this.d = !1;
            if (this.Dc) this.b.clearTimeout(this.Dc), this.Dc = j
        };
        Q.n = function () {
            Jq.g.n[I](this);
            this[Vb]();
            delete this.b
        };
        var Sq;
        U(Nq, wq);
        var Mx = {
            NONE: 0,
            Oj: 1,
            ck: 2,
            Xj: 4,
            ok: 8
        }, Oq = [27, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 19],
            hA = {
                Ri: Lk,
                Qi: Nk
            };
        Q = Nq[F];
        Q.$g = function (a, b) {
            Vq(this.d, Qq(1, arguments), a)
        };
        Q.sj = function (a) {
            Vq(this.d, Qq(0, arguments), j)
        };
        Q.gj = function (a) {
            var b;
            a: {
                b = Qq(0, arguments);
                for (var c = this.d; b[E] > 0 && c;) {
                    var d = b[Na](),
                        c = c[d[A] & 255 | d.Wc << 8];
                    if (S(c)) {
                        b = !0;
                        break a
                    }
                }
                b = !1
            }
            return b
        };
        Q.n = function () {
            Nq.g.n[I](this);
            this.d = {};
            dq(this.b, oj, this.Ke, !1, this);
            Ko && Z && W(pe) && dq(this.b, qj, this.Ag, !1, this);
            Pq && !Z && (dq(this.b, pj, this.Bg, !1, this), dq(this.b, qj, this.Cg, !1, this));
            this.b = j
        };
        Q.Ag = function (a) {
            if (a[A] == 224) this.Nh = !0, Mq(function () {
                this.Nh = !1
            }, 400, this);
            else {
                var b = a[gb] || this.Nh;
                if ((a[A] == 67 || a[A] == 88 || a[A] == 86) && b) a.metaKey = b, this.Ke(a)
            }
        };
        Q.Bg = function (a) {
            if (a[A] > 32 && Uq(a)) this.j = !0
        };
        Q.Cg = function (a) {
            !this.j && Uq(a) && this.Ke(a)
        };
        Q.Ke = function (a) {
            var b;
            b = a[A];
            if (b == 16 || b == 17 || b == 18) b = !1;
            else {
                var c = a[H],
                    d = c[Cc] == Vf || c[Cc] == of || c[Cc] == Ve || c[Cc] == Mf,
                    f = !d && (c.isContentEditable || c[nc] && c[nc].designMode == Wj);
                b = !d && !f ? !0 : this.M[b] || this.f ? !0 : f ? !1 : this.F && (a[Xb] || a[hc] || a[gb]) ? !0 : c[Cc] == of && (c[C] == jl || c[C] == dk) ? b == 13 : c[Cc] == of || c[Cc] == Ve ? b != 32 : !1
            } if (b)
                if (a[C] == oj && Uq(a)) this.j = !1;
                else {
                    b = a[A] & 255 | ((a[Bc] ? 1 : 0) | (a[hc] ? 2 : 0) | (a[Xb] ? 4 : 0) | (a[gb] ? 8 : 0)) << 8;
                    var g, h, c = Lq();
                    this.c.Bc[E] && c - this.c.Gg <= 1500 ? g = Wq(this, this.c.Bc) : Ba(this.c.Bc, 0);
                    g = g ? g[b] : this.d[b];
                    if (!g) g = this.d[b], this.c.Bc = [];
                    g && S(g) ? h = g : g ? (this.c.Bc[s](b), this.c.Gg = c, Z && a[bb]()) : Ba(this.c.Bc, 0);
                    h && (this.p && a[bb](), this.z && a[jc](), b = a[H], g = xq(this, new Xq(hA.Ri, h, b)), h = new Xq(hA.Qi + h, h, b), g &= oq(this, h), g || a[bb](), Ba(this.c.Bc, 0))
                }
        };
        U(Xq, Ip);
        U(Yq, zq);
        var $q = 0;
        Q = Yq[F];
        Q.n = function () {
            Yq.g.n[I](this);
            this.j.s();
            this.j = j;
            if (this.f) this.f.s(), this.f = j;
            this.Mb = this.b = this.M = this.p = this.d = j
        };
        Q.dc = function () {
            return this.Z()
        };
        Q.C = function () {
            return this.Mb || (this.Mb = Pn(this.Z()))
        };
        Q.Z = function () {
            return this.b || (this.b = this.M)
        };
        Q.w = function (a, b) {
            this.d[a] || (this.d[a] = [], this.F ? tq(this.dc(), a, this) : this.j.w(this.dc(), a, this));
            var c = this.d[a];
            Vm(c, b) || c[s](b)
        };
        Q.Ca = function (a, b) {
            var c = this.d[a];
            c && (Xm(c, b), c[E] == 0 && (this.j.Ca(this.dc(), a, this), delete this.d[a]))
        };
        va(Q, function (a) {
            for (var b = this.d[a[C]], c = 0, d = b[E]; c < d; c++) {
                var f = b[c];
                if (f[qc](this)) {
                    var g;
                    if (a instanceof Xq) {
                        g = f;
                        var h = a,
                            k;
                        if (k = g[qc](this)) k = g.d.b, k = h.ih && h.ih[x](k) != -1 || i;
                        k ? (h = !g.N(this), k = g.ea(this), this[Gb]([g.b, bh][L](he), new wu(h, k.X, k.B)), g = !0) : g = !1;
                        if (g) {
                            a[bb]();
                            continue
                        }
                    }
                    if (g = f[Eb](this, a)) {
                        a[jc]();
                        a[bb]();
                        break
                    }
                }
            }
        });
        Q.rf = hm;
        Q.Be = hm;
        Q.Yd = hm;
        Q.Ze = function (a) {
            this.Yd(a)
        };
        U(cr, Yq);
        Q = cr[F];
        Q.Wb = function () {
            var a = Fn(this.b, !1),
                b = new sp(this.b, a[0]),
                a = new sp(this.b, a[1]);
            return new Kp(this, b, a)
        };
        Q.Cd = function () {
            var a = Fn(this.b, !1);
            return a[0] == a[1]
        };
        Q.Nd = function (a) {
            var b = this.b,
                a = a.m;
            Gn(b) ? (b.selectionStart = a, b.selectionEnd = a) : X && (a = In(b, a), b = b[rb](), b[Ra](!0), b[fb](ch, a), b[yb]());
            Z && this.sb()
        };
        Q.Ch = function (a) {
            var b = a.V.m,
                c = this.b,
                a = a.H.m;
            if (Gn(c)) c.selectionStart = a;
            else if (X) {
                var d = Hn(c),
                    f = d[0];
                f[Ta](d[1]) && (a = In(c, a), f[Ra](!0), f[fb](ch, a), f[yb]())
            }
            c = this.b;
            Gn(c) ? c.selectionEnd = b : X && (d = Hn(c), a = d[1], d[0][Ta](a) && (b = In(c, b), c = In(c, Fn(c, !0)[0]), a[Ra](!0), a[rc](ch, b - c), a[yb]()));
            this.sb()
        };
        Q.Id = function () {
            return !!this.b.disabled
        };
        Q.Mg = function () {
            return this.b == yo(this.C()).activeElement
        };
        Q.sb = function () {
            this.b[wb]()
        };
        Q.rf = function () {
            return So(this.b)
        };
        Q.Be = function () {
            return this.rf() ? yk : zj
        };
        Q.Yd = function (a) {
            this.b[Cb](vh, a);
            return !0
        };
        Q.Ze = function (a) {
            var b = this.b.getAttribute(vh);
            (!b || b != a) && this.Yd(a)
        };
        U(dr, np);
        dr[F].restore = function (a) {
            var b = this.d();
            a || this.s();
            return b
        };
        U(er, dr);
        er[F].b = function (a) {
            jo(gr(this, !0));
            jo(gr(this, !1));
            return a
        };
        er[F].d = function () {
            var a = j,
                b = gr(this, !0),
                c = gr(this, !1);
            if (b && c) {
                var a = b[K],
                    b = Wm(a[D], b),
                    d = c[K],
                    c = Wm(d[D], c);
                d == a && (c -= 1);
                a = Ir(a, b, d, c);
                a = this.b(a);
                a[yb]()
            } else this.b();
            return a
        };
        er[F].n = function () {
            this.b();
            this.c = j
        };
        U(hr, gn);
        Q = hr[F];
        Q.k = j;
        Q.cb = 0;
        Q.Qf = !1;
        Q.Ub = function (a) {
            this.k = a.k;
            this.cb = a.cb;
            this.c = a.c;
            this.b = a.b;
            this.d = a.d
        };
        Q.W = function () {
            return new hr(this.k, this.b, !this.d, this.cb, this.c)
        };
        Da(Q, function () {
            var a;
            if (this.Qf) {
                (!this.k || this.d && this.c == 0) && e(jn);
                a = this.k;
                var b = this.b ? -1 : 1;
                if (this.cb == b) {
                    var c = this.b ? a[pc] : a[B];
                    c ? ir(this, c) : ir(this, a, b * -1)
                } else(c = this.b ? a[Ub] : a[Mb]) ? ir(this, c) : ir(this, a[K], b * -1);
                this.c += this.cb * (this.b ? -1 : 1)
            } else this.Qf = !0;
            (a = this.k) || e(jn);
            return a
        });
        Q.splice = function (a) {
            var b = this.k,
                c = this.b ? 1 : -1;
            if (this.cb == c) this.cb = c * -1, this.c += this.cb * (this.b ? -1 : 1);
            this.b = !this.b;
            hr[F][gc][I](this);
            this.b = !this.b;
            for (var c = lm(arguments[0]) ? arguments[0] : arguments, d = c[E] - 1; d >= 0; d--) io(c[d], b);
            jo(b)
        };
        jr[F].hd = P(!1);
        jr[F].containsNode = function (a, b) {
            return this.Cb(Hr(zr(a), i), b)
        };
        jr[F].vf = function (a) {
            this.$b() || this.vc();
            return this.Ie(a, !0)
        };
        U(mr, hr);
        U(nr, mr);
        Q = nr[F];
        Q.tc = j;
        Q.Db = j;
        Q.De = 0;
        Q.ud = 0;
        Q.A = dm("tc");
        Q.I = dm("Db");
        Q.Zd = function () {
            return this.Qf && this.k == this.Db && (!this.ud || this.cb != 1)
        };
        Da(Q, function () {
            this.Zd() && e(jn);
            return nr.g[gc][I](this)
        });
        Q.Ub = function (a) {
            this.tc = a.tc;
            this.Db = a.Db;
            this.De = a.De;
            this.ud = a.ud;
            this.nb = a.nb;
            nr.g.Ub[I](this, a)
        };
        Q.W = function () {
            var a = new nr(this.tc, this.De, this.Db, this.ud, this.nb);
            a.Ub(this);
            return a
        };
        or[F].Cb = function (a, b) {
            var c = b && !a.hb(),
                d = a.Wd();
            try {
                return c ? this.ib(d, 0, 1) >= 0 && this.ib(d, 1, 0) <= 0 : this.ib(d, 0, 0) >= 0 && this.ib(d, 1, 1) <= 0
            } catch (f) {
                return X || e(f), !1
            }
        };
        or[F].containsNode = function (a, b) {
            return this.Cb(zr(a), b)
        };
        or[F].wc = function () {
            return new nr(this.A(), this.D(), this.I(), this.aa())
        };
        U(pr, or);
        Q = pr[F];
        Q.W = function () {
            return new this.constructor(this.b[tc]())
        };
        Q.Wd = dm("b");
        Q.pg = function () {
            return this.b.commonAncestorContainer
        };
        Q.A = function () {
            return this.b.startContainer
        };
        Q.D = function () {
            return this.b.startOffset
        };
        Q.I = function () {
            return this.b.endContainer
        };
        Q.aa = function () {
            return this.b.endOffset
        };
        Q.ib = function (a, b, c) {
            return this.b.compareBoundaryPoints(c == 1 ? b == 1 ? R.Range.START_TO_START : R.Range.START_TO_END : b == 1 ? R.Range.END_TO_START : R.Range.END_TO_END, a)
        };
        Q.hb = function () {
            return this.b.collapsed
        };
        Q.q = function () {
            return this.b[Wb]()
        };
        ta(Q, function (a) {
            this.qf($n(Rn(this.A())).getSelection(), a)
        });
        Q.qf = function (a) {
            a.removeAllRanges();
            a.addRange(this.b)
        };
        Q.vc = function () {
            var a = this.b;
            a.extractContents();
            if (a.startContainer.hasChildNodes() && (a = a.startContainer[D][a.startOffset])) {
                var b = a[Ub];
                vo(a) == M && jo(a);
                b && vo(b) == M && jo(b)
            }
        };
        Q.Qh = function (a, b) {
            var c = this.b[tc]();
            c[Ra](b);
            c.insertNode(a);
            c.detach();
            return a
        };
        Q.Rh = function (a, b) {
            var c = $n(Rn(this.A()));
            if (c = as(c)) var d = c.A(),
            f = c.I(), g = c.D(), h = c.aa();
            var k = this.b[tc](),
                o = this.b[tc]();
            k[Ra](!1);
            o[Ra](!0);
            k.insertNode(b);
            o.insertNode(a);
            k.detach();
            o.detach();
            if (c) {
                if (d[v] == 3)
                    for (; g > d[E];) {
                        g -= d[E];
                        do d = d[Mb]; while (d == a || d == b)
                    }
                if (f[v] == 3)
                    for (; h > f[E];) {
                        h -= f[E];
                        do f = f[Mb]; while (f == a || f == b)
                    }
                Ir(d, g, f, h)[yb]()
            }
        };
        Q.Ih = function (a) {
            this.b[Ra](a)
        };
        U(tr, pr);
        tr[F].qf = function (a, b) {
            var c = b ? this.I() : this.A(),
                d = b ? this.aa() : this.D(),
                f = b ? this.A() : this.I(),
                g = b ? this.D() : this.aa();
            a[Ra](c, d);
            (c != f || d != g) && a.extend(f, g)
        };
        U(ur, or);
        Q = ur[F];
        Q.xb = j;
        Q.gb = j;
        Q.fb = j;
        Q.Qa = -1;
        Q.Ua = -1;
        Q.W = function () {
            var a = new ur(this.b[Nb](), this.c);
            a.xb = this.xb;
            a.gb = this.gb;
            a.fb = this.fb;
            return a
        };
        Q.Wd = dm("b");
        Q.pg = function () {
            if (!this.xb) {
                var a = this.b[Qa],
                    b = this.b[Nb](),
                    c = a[u](/ +$/, M);
                (c = a[E] - c[E]) && b[rc](ch, -c);
                c = b[Fb]();
                b = b[$b][u](/(\r\n|\r|\n)+/g, N)[E];
                if (this.hb() && b > 0) return this.xb = c;
                for (; b > c.outerHTML[u](/(\r\n|\r|\n)+/g, N)[E];) c = c[K];
                for (; c[D][E] == 1 && c.innerText == (c[B][v] == 3 ? c[B][Kc] : c[B].innerText);) {
                    if (!rr(c[B])) break;
                    c = c[B]
                }
                a[E] == 0 && (c = xr(this, c));
                this.xb = c
            }
            return this.xb
        };
        Q.A = function () {
            if (!this.gb && (this.gb = yr(this, 1), this.hb())) this.fb = this.gb;
            return this.gb
        };
        Q.D = function () {
            if (this.Qa < 0 && (this.Qa = Ar(this, 1), this.hb())) this.Ua = this.Qa;
            return this.Qa
        };
        Q.I = function () {
            if (this.hb()) return this.A();
            if (!this.fb) this.fb = yr(this, 0);
            return this.fb
        };
        Q.aa = function () {
            if (this.hb()) return this.D();
            if (this.Ua < 0 && (this.Ua = Ar(this, 0), this.hb())) this.Qa = this.Ua;
            return this.Ua
        };
        Q.ib = function (a, b, c) {
            return this.b[yc]((b == 1 ? Qf : cf) + Xf + (c == 1 ? Qf : cf), a)
        };
        Q.xd = function () {
            var a = this.c[mc][rb]();
            a[kc](this.c[mc]);
            return this.Cb(new ur(a, this.c), !0)
        };
        Q.hb = function () {
            return this.b[yc](Rf, this.b) == 0
        };
        Q.q = function () {
            return this.b[Qa]
        };
        ta(Q, function () {
            this.b[yb]()
        });
        Q.vc = function () {
            if (!this.hb() && this.b[$b]) {
                var a = this.A(),
                    b = this.I(),
                    c = this.b[Qa],
                    d = this.b[Nb]();
                d.moveStart(ch, 1);
                d.moveStart(ch, -1);
                if (d[Qa] == c) this.b = d;
                this.b.text = M;
                wr(this);
                c = this.A();
                d = this.D();
                try {
                    var f = a[Mb];
                    if (a == b && a[K] && a[v] == 3 && f && f[v] == 3) a.nodeValue += f[Kc], jo(f), this.b = vr(c), this.b[fb](ch, d), wr(this)
                } catch (g) {}
            }
        };
        Q.Qh = function (a, b) {
            var c = Br(this.b[Nb](), a, b);
            wr(this);
            return c
        };
        Q.Rh = function (a, b) {
            var c = this.b[Nb](),
                d = this.b[Nb]();
            Br(c, a, !0);
            Br(d, b, !1);
            wr(this)
        };
        Q.Ih = function (a) {
            this.b[Ra](a);
            a ? (this.fb = this.gb, this.Ua = this.Qa) : (this.gb = this.fb, this.Qa = this.Ua)
        };
        U(Cr, pr);
        Cr[F].qf = function (a) {
            a[Ra](this.A(), this.D());
            (this.I() != this.A() || this.aa() != this.D()) && a.extend(this.I(), this.aa());
            a[Kb] == 0 && a.addRange(this.b)
        };
        U(Dr, pr);
        Dr[F].ib = function (a, b, c) {
            return W(xe) ? Dr.g.ib[I](this, a, b, c) : this.b.compareBoundaryPoints(c == 1 ? b == 1 ? R.Range.START_TO_START : R.Range.END_TO_START : b == 1 ? R.Range.START_TO_END : R.Range.END_TO_END, a)
        };
        Dr[F].qf = function (a, b) {
            a.removeAllRanges();
            b ? a.setBaseAndExtent(this.I(), this.aa(), this.A(), this.D()) : a.setBaseAndExtent(this.A(), this.D(), this.I(), this.aa())
        };
        U(Fr, jr);
        Fr[F].Cb = function (a, b) {
            var c = lr(this),
                d = lr(a);
            return (b ? vq : Lu)(d, function (a) {
                return vq(c, function (c) {
                    return c.Cb(a, b)
                })
            })
        };
        Fr[F].Ie = function (a, b) {
            if (b) {
                var c = this.A();
                c[K] && c[K][db](a, c)
            } else io(a, this.I());
            return a
        };
        Fr[F].ph = function (a, b) {
            this.Ie(a, !0);
            this.Ie(b, !1)
        };
        U(Gr, jr);
        Q = Gr[F];
        Q.Tc = j;
        Q.ob = j;
        Q.Eb = j;
        Q.pb = j;
        Q.Fb = j;
        Q.nb = !1;
        Q.W = function () {
            var a = new Gr;
            a.Tc = this.Tc;
            a.ob = this.ob;
            a.Eb = this.Eb;
            a.pb = this.pb;
            a.Fb = this.Fb;
            a.nb = this.nb;
            return a
        };
        Q.sg = P(jl);
        Q.gd = function () {
            return Lr(this).Wd()
        };
        Q.kd = P(1);
        Q.bc = function () {
            return this
        };
        Q.Nc = function () {
            return Lr(this).pg()
        };
        Q.A = function () {
            return this.ob || (this.ob = Lr(this).A())
        };
        Q.D = function () {
            return this.Eb != j ? this.Eb : this.Eb = Lr(this).D()
        };
        Q.I = function () {
            return this.pb || (this.pb = Lr(this).I())
        };
        Q.aa = function () {
            return this.Fb != j ? this.Fb : this.Fb = Lr(this).aa()
        };
        Q.hd = dm("nb");
        Q.Cb = function (a, b) {
            var c = a.sg();
            if (c == jl) return Lr(this).Cb(Lr(a), b);
            else if (c == kh) return c = Rr(a), (b ? vq : Lu)(c, function (a) {
                return this.containsNode(a, b)
            }, this);
            return !1
        };
        Q.xd = function () {
            return (!this.ob || Mr(this.ob)) && (!this.pb || Mr(this.pb)) && (!(X && !Dn()) || Lr(this).xd())
        };
        Q.$b = function () {
            return Lr(this).hb()
        };
        Q.q = function () {
            return Lr(this).q()
        };
        Q.wc = function () {
            return new nr(this.A(), this.D(), this.I(), this.aa())
        };
        ta(Q, function () {
            Lr(this)[yb](this.nb)
        });
        Q.vc = function () {
            Lr(this).vc();
            Kr(this)
        };
        Q.Ie = function (a, b) {
            var c = Lr(this).Qh(a, b);
            Kr(this);
            return c
        };
        Q.ph = function (a, b) {
            Lr(this).Rh(a, b);
            Kr(this)
        };
        Q.$f = function () {
            return new Nr(this)
        };
        Q.Ue = function (a) {
            a = this.hd() ? !a : a;
            this.Tc && this.Tc.Ih(a);
            a ? (this.pb = this.ob, this.Fb = this.Eb) : (this.ob = this.pb, this.Eb = this.Fb);
            this.nb = !1
        };
        U(Nr, dr);
        Nr[F].d = function () {
            return Ir(this.b, this.f, this.c, this.j)
        };
        Nr[F].n = function () {
            Nr.g.n[I](this);
            this.c = this.b = j
        };
        U(Or, Fr);
        Q = Or[F];
        Q.Ka = j;
        Q.Ge = j;
        Q.He = j;
        Q.W = function () {
            return Qr[Ac](this, Rr(this))
        };
        Q.sg = P(kh);
        Q.gd = function () {
            return this.Ka || p[mc].createControlRange()
        };
        Q.kd = function () {
            return this.Ka ? this.Ka[E] : 0
        };
        Q.bc = function (a) {
            a = this.Ka[cb](a);
            return Hr(zr(a), i)
        };
        Q.Nc = function () {
            return oo[Ac](j, Rr(this))
        };
        Q.A = function () {
            return Sr(this)[0]
        };
        Q.D = P(0);
        Q.I = function () {
            var a = Sr(this),
                b = Rm(a);
            return Tm(a, function (a) {
                return ko(a, b)
            })
        };
        Q.aa = function () {
            return this.I()[D][E]
        };
        Q.xd = function () {
            var a = !1;
            try {
                a = Lu(Rr(this), function (a) {
                    return X ? a[K] : ko(a[nc][mc], a)
                })
            } catch (b) {}
            return a
        };
        Q.$b = function () {
            return !this.Ka || !this.Ka[E]
        };
        Q.q = P(M);
        Q.wc = function () {
            return new Ur(this)
        };
        ta(Q, function () {
            this.Ka && this.Ka[yb]()
        });
        Q.vc = function () {
            if (this.Ka) {
                for (var a = [], b = 0, c = this.Ka[E]; b < c; b++) a[s](this.Ka[cb](b));
                V(a, jo);
                this.Ue(!1)
            }
        };
        Q.vf = function (a) {
            a = this.Ie(a, !0);
            this.$b() || this.vc();
            return a
        };
        Q.$f = function () {
            return new Tr(this)
        };
        Q.Ue = function () {
            this.He = this.Ge = this.Ka = j
        };
        U(Tr, dr);
        Tr[F].d = function () {
            for (var a = (this.b[E] ? Rn(this.b[0]) : p)[mc].createControlRange(), b = 0, c = this.b[E]; b < c; b++) a.addElement(this.b[b]);
            return Pr(a)
        };
        Tr[F].n = function () {
            Tr.g.n[I](this);
            delete this.b
        };
        U(Ur, mr);
        Q = Ur[F];
        Q.wd = j;
        Q.nf = j;
        Q.Oc = j;
        Q.A = dm("wd");
        Q.I = dm("nf");
        Q.Zd = function () {
            return !this.c && !this.Oc[E]
        };
        Da(Q, function () {
            if (this.Zd()) e(jn);
            else if (!this.c) {
                var a = this.Oc[Na]();
                ir(this, a, 1, 1);
                return a
            }
            return Ur.g[gc][I](this)
        });
        Q.Ub = function (a) {
            this.Oc = a.Oc;
            this.wd = a.wd;
            this.nf = a.nf;
            Ur.g.Ub[I](this, a)
        };
        Q.W = function () {
            var a = new Ur(j);
            a.Ub(this);
            return a
        };
        U(Vr, Fr);
        Q = Vr[F];
        Q.W = function () {
            var a = new Vr;
            a.b = $m(this.b);
            return a
        };
        Q.sg = P("mutli");
        Q.gd = function () {
            return this.b[0]
        };
        Q.kd = function () {
            return this.b[E]
        };
        Q.bc = function (a) {
            this.c[a] || (this.c[a] = Hr(Er(this.b[a]), i));
            return this.c[a]
        };
        Q.Nc = function () {
            if (!this.f) {
                for (var a = [], b = 0, c = this.kd(); b < c; b++) a[s](this.bc(b).Nc());
                this.f = oo[Ac](j, a)
            }
            return this.f
        };
        Q.A = function () {
            return Yr(this)[0].A()
        };
        Q.D = function () {
            return Yr(this)[0].D()
        };
        Q.I = function () {
            return Rm(Yr(this)).I()
        };
        Q.aa = function () {
            return Rm(Yr(this)).aa()
        };
        Q.xd = function () {
            return Lu(lr(this), function (a) {
                return a.xd()
            })
        };
        Q.$b = function () {
            return this.b[E] == 0 || this.b[E] == 1 && this.bc(0).$b()
        };
        Q.q = function () {
            return Xr(lr(this), function (a) {
                return a.q()
            })[L](M)
        };
        Q.wc = function () {
            return new $r(this)
        };
        ta(Q, function () {
            var a = kr($n(Rn(X ? this.Nc() : this.A())));
            a.removeAllRanges();
            for (var b = 0, c = this.kd(); b < c; b++) a.addRange(this.bc(b).gd())
        });
        Q.vc = function () {
            V(lr(this), function (a) {
                a.vc()
            })
        };
        Q.$f = function () {
            return new Zr(this)
        };
        Q.Ue = function (a) {
            if (!this.$b()) {
                var b = a ? this.bc(0) : this.bc(this.kd() - 1);
                this.c = [];
                this.f = this.d = j;
                b.Ue(a);
                this.c = [b];
                this.d = [b];
                this.b = [b.gd()]
            }
        };
        U(Zr, dr);
        Zr[F].d = function () {
            var a = Xr(this.b, function (a) {
                return a.restore()
            });
            return Wr(a)
        };
        Zr[F].n = function () {
            Zr.g.n[I](this);
            V(this.b, function (a) {
                a.s()
            });
            delete this.b
        };
        U($r, mr);
        Q = $r[F];
        Q.nc = j;
        Q.hf = 0;
        Q.A = function () {
            return this.nc[0].A()
        };
        Q.I = function () {
            return Rm(this.nc).I()
        };
        Q.Zd = function () {
            return this.nc[this.hf].Zd()
        };
        Da(Q, function () {
            try {
                var a = this.nc[this.hf],
                    b = a[gc]();
                ir(this, a.k, a.cb, a.c);
                return b
            } catch (c) {
                if (c !== jn || this.nc[E] - 1 == this.hf) e(c);
                else return this.hf++, this[gc]()
            }
        });
        Q.Ub = function (a) {
            this.nc = $m(a.nc);
            $r.g.Ub[I](this, a)
        };
        Q.W = function () {
            var a = new $r(j);
            a.Ub(this);
            return a
        };
        var Cs = sn("ADDRESS", "BLOCKQUOTE", Te, "CAPTION", "CENTER", Xe, "COLGROUP", "DIR", bf, "DL", "DD", "DT", "FIELDSET", "FORM", "H1", "H2", "H3", "H4", "H5", "H6", kf, pf, "OL", "LI", "MAP", "MENU", "OPTGROUP", "OPTION", "P", If, "TABLE", "TBODY", Uf, "TFOOT", "TH", "THEAD", Wf, "TL", "UL");
        sn(nf, mf, "EMBED");
        U(fs, pp);
        Q = fs[F];
        Q.n = function () {
            this.k = j
        };
        Q.qb = function () {
            return new fs(this.b, this.k, this.m)
        };
        Q.ef = function (a) {
            return fs.g.ef[I](this, a) && this.k == a.k
        };
        Q.Tf = function () {
            return !!this.k && this.k[v] == 3
        };
        Q.mc = function () {
            return this.k[Kc] || M
        };
        Q.Ef = function () {
            return !!this.b[nc] && !! this.b[K] && ko(this.b, this.k) && this.m >= 0 && this.m <= cs(this.k)
        };
        Q.ed = function (a) {
            if (a <= this.mc()[E] && a >= 0) this.m = a;
            return this
        };
        Ga(Q, function (a, b) {
            this.k = a;
            this.m = b
        });
        sn(jl, "file", "url");
        U(ps, er);
        ps[F].b = function (a) {
            var b = gr(this, !0),
                c = gr(this, !1),
                b = b && c ? oo(b, c) : b || c;
            ps.g.b[I](this);
            if (a) return js(b, a);
            else b && is(b)
        };
        U(qs, Fp);
        Q = qs[F];
        Q.n = function () {
            delete this.b.p[this.Fa()];
            ss(this);
            ys(this);
            us(this);
            this.p = this.d = j
        };
        Q.q = function () {
            return qs.g.q[I](this) || rs(this).q()
        };
        Q.xc = function () {
            return this.H.Tf() && this.H.k == this.V.k
        };
        Q.Kf = function () {
            if (!this.j) {
                if (!this.c) this.c = this.yc = $l;
                if (!this.Sa() && !this.xc()) {
                    var a = this.d.l(Nf, {
                        id: this.Fa()
                    }, M),
                        b = this.b.Z(),
                        c = rs(this).I();
                    c == b && (c = b[pc]);
                    io(a, c);
                    gs(a, !1)
                } else {
                    var a = this.H,
                        b = this.V,
                        c = b.k,
                        d = c == this.b.Z(),
                        c = c[K];
                    if (!d && c[Cc][Hc]() == Nf && xm(c.id == j ? M : n(c.id)) && zm(this.d.wg(c)) == this.q()) c.id = this.Fa();
                    else {
                        var c = a.m,
                            d = rs(this).vf(this.d.l(Nf, {
                                id: this.Fa()
                            })),
                            f = this.d.b[$a](this.c);
                        d[Ja](f);
                        a[Dc](f, 0);
                        b[Dc](f, f[Kc][E]);
                        this.f && this.f[Dc](f, this.f.m - c);
                        gs(d, !1)
                    }
                }
                this.b.p[this.Fa()] =
                    this;
                this.j = !0
            }
        };
        Q.replace = function (a) {
            if (!this.j) return this.c != this.q() ? !1 : zs(this, a);
            ss(this);
            if (this.j) ys(this, !0);
            else {
                var b = this.H,
                    c = this.V;
                (!this.d[zc](b.b, b.k) || !(this.d[zc](c.b, c.k) && this.q() == this.c)) && this[Dc](j, j)
            }
            a = zs(this, a);
            us(this);
            return a
        };
        Q.Hb = function (a) {
            var b = a ? this.V : this.H;
            b.Tf() ? this.b.Nd(b) : gs(b.k[D][b.m - (a ? 1 : 0)], !a)
        };
        Q.Me = function (a) {
            this.Kf();
            return Ep(vs(this), a)
        };
        U(As, Yq);
        Q = As[F];
        Q.Z = function () {
            return this.b || (this.b = !this.z ? this.M : po(this.M)[mc])
        };
        Q.C = function () {
            return this.jb || (this.jb = Pn(this.Z()))
        };
        Q.Id = function () {
            return this.z && this.Z()[nc].designMode[Lc]() == Wj ? !0 : this.Z().contentEditable[Lc]() == Bl
        };
        Q.Wb = function () {
            var a = ts(this);
            if (!a) return j;
            var b;
            if (a.$b()) {
                var c = new fs(this.Z(), a.A(), a.D());
                a: {
                    try {
                        b = a.A()
                    } catch (d) {
                        a = j;
                        break a
                    }
                    a = a.D();
                    if (a > 0 && !ds(b)) {
                        var f = b[D][a];
                        if (f && rr(f)) b = f, a = 0;
                        else if (f = b[D][a - 1], rr(f)) {
                            for (b = f; b[pc] && rr(b[pc]);) b = b[pc];
                            a = cs(b)
                        }
                    }
                    if (a == 0)
                        if (f = Ds(this, b, !0)) b = f, a = f[Kc][E];
                        else
                            for (; b[B] && rr(b[B]);) b = b[B];
                    a = new fs(this.Z(), b, a)
                }
                b = a.k;
                f = a.m;
                if (ds(b)) {
                    var g = b[Kc] ? b[Kc][E] : 0;
                    b = es(b, !1);
                    f += b[Kc][E] - g;
                    b = es(b, !0);
                    a[Dc](b, f)
                }
                b = new qs(this, a);
                c.ef(a) || this.Ch(b)
            } else b = this.Z(),
            c = new fs(b, a.A(), a.D()), b = new fs(b, a.I(), a.aa()), b = new qs(this, c, b, a);
            return b
        };
        Q.Cd = function () {
            var a = ts(this);
            return !a || a.$b()
        };
        Q.Nd = function (a) {
            if (this.Id()) {
                this.sb();
                var b = a.k,
                    a = a.m;
                if (this.C()[zc](this.Z(), b) && !(a < 0 || a > cs(b)))(b = Ir(b, a, b, a)) && b[yb]()
            }
        };
        Q.Ch = function (a) {
            this.Id() && (a = rs(a)) && a[yb]()
        };
        Q.Mg = function () {
            return !!ts(this)
        };
        Q.sb = function () {
            this.Id() && (this.z ? zo(this.C())[wb]() : this.Z()[wb]())
        };
        Q.rf = function () {
            return So(this.Z())
        };
        Q.Be = function () {
            return this.rf() ? yk : zj
        };
        Q.Yd = function (a) {
            this.Z()[Cb](vh, a);
            this.Ya = a;
            return !0
        };
        Q.Ze = function (a) {
            if (this.Ya) {
                var b = this.Be();
                if (b && b != this.Ya) this.ac = b
            }
            this.ac || this.Yd(a)
        };
        Q.dc = function () {
            return this.z ? po(this.M) : this.Z()
        };
        Q.w = function (a, b) {
            this.d[a] || (this.d[a] = [], this.z && !this.F ? this.j.w(this.dc(), a, this) : tq(this.dc(), a, this));
            var c = this.d[a];
            Vm(c, b) || c[s](b)
        };
        var iA = "`'-_~!@#$%^&*()+=[]\\{}|;:\",./<>?\u2026\u2018\u2019\u201c\u201d\u200e \t\r\n" + n[ub](160);
        Es[F].isChar = function (a) {
            if (this.b[a]) return !0;
            for (var b = 0, c = this.c[E]; b < c; b++) {
                var d = this.c[b];
                if (a >= d[sc] && a <= d.end) return !0
            }
            return !1
        };
        var jA = new Es("Ethi", [{
            start: "\u1200",
            end: "\u137f"
        }], "\u1360\u1361\u1362\u1363\u1364\u1365\u1366\u1367\u1368" + iA, {
            fontSize: 14,
            lineHeight: 1.5,
            Ra: 24
        });
        var $ = {};
        Fs[F].isChar = function (a) {
            return this.b.isChar(a)
        };
        var ez = {
            Yj: Ag,
            Zj: Cg,
            $j: "bn",
            ak: Ul,
            Ah: Fh,
            dk: "el",
            ek: "gu",
            fk: kj,
            gk: ki,
            hk: mj,
            ik: lj,
            jk: "kn",
            mk: "ml",
            nk: "mr",
            pk: "ne",
            qk: "or",
            rk: Lh,
            sk: "pa",
            tk: Ak,
            uk: "sa",
            vk: Vk,
            wk: "sr-latn",
            Ak: "si",
            Ck: "ta",
            Dk: il,
            Ek: ql,
            Fk: Gl
        }, Ls = {};
        Js[F].toString = dm("b");
        var Os;
        Os = new Fs("AMHARIC", Ag, "Amharic", jA);
        var kA = new Es("Arab", [{
            start: "\u0600",
            end: "\u06ff"
        }], "\u060c\u061b\u061f\u06d4" + iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        }, !0);
        var Ps;
        Ps = new Fs("ARABIC", Cg, "Arabic", kA);
        var lA = new Es("Beng", [{
            start: "\u0980",
            end: "\u09ff"
        }, {
            start: "\u200c",
            end: "\u200d"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var Qs;
        Qs = new Fs("BENGALI", "bn", "Bengali", lA);
        var mA = new Es("Hans", [{
            start: "\u4e00",
            end: "\u9fff"
        }], iA);
        var Rs;
        Rs = new Fs("CHINESE", Ul, "Chinese", mA, "Pinyin");
        var nA = new Es("Latn", [{
            start: pg,
            end: "z"
        }, {
            start: "A",
            end: "Z"
        }, {
            start: le,
            end: "9"
        }], iA);
        var Ns;
        Ns = new Fs("ENGLISH", Fh, "English", nA);
        var oA = new Es("Grek", [{
            start: "\u0370",
            end: "\u03ff"
        }, {
            start: le,
            end: "9"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var Ss;
        Ss = new Fs("GREEK", "el", "Greek", oA);
        var pA = new Es("Gujr", [{
            start: "\u0a80",
            end: "\u0aff"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var Ts;
        Ts = new Fs("GUJARATI", "gu", "Gujarati", pA);
        var qA = new Es("Hebr", [{
            start: "\u0590",
            end: "\u05ff"
        }, {
            start: le,
            end: "9"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        }, !0);
        var Us;
        Us = new Fs("HEBREW", kj, "Hebrew", qA);
        var rA = new Es("Deva", [{
            start: "\u0900",
            end: "\u097f"
        }], "\u0964\u0965" + iA, {
            fontSize: 14,
            lineHeight: 1.5,
            Ra: 24
        });
        var Vs;
        Vs = new Fs("HINDI", ki, "Hindi", rA);
        var sA = new Es("Jpan", [{
            start: "\u3040",
            end: "\u309f"
        }, {
            start: "\u30a0",
            end: "\u30ff"
        }, {
            start: "\u3400",
            end: "\u9fff"
        }], M);
        var Ws;
        Ws = new Fs("JAPANESE", lj, "Japanese", sA);
        var tA = new Es("Knda", [{
            start: "\u0c80",
            end: "\u0cff"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var Xs;
        Xs = new Fs("KANNADA", "kn", "Kannada", tA);
        var uA = new Es("Mlym", [{
            start: "\u0d00",
            end: "\u0d7f"
        }, {
            start: "\u200c",
            end: "\u200d"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var Ys;
        Ys = new Fs("MALAYALAM", "ml", "Malayalam", uA);
        var Zs;
        Zs = new Fs("MARATHI", "mr", "Marathi", rA);
        var $s;
        $s = new Fs("NEPALI", "ne", "Nepali", rA);
        var vA = new Es("Orya", [{
            start: "\u0b00",
            end: "\u0b7f"
        }, {
            start: "\u200c",
            end: "\u200d"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var at;
        at = new Fs("ORIYA", "or", "Oriya", vA);
        var bt;
        bt = new Fs("PERSIAN", Lh, "Persian", kA);
        var wA = new Es("Guru", [{
            start: "\u0a00",
            end: "\u0a7f"
        }], "\u0964\u0965" + iA, {
            fontSize: 14,
            lineHeight: 1.5,
            Ra: 24
        });
        var ct;
        ct = new Fs("PUNJABI", "pa", "Punjabi", wA);
        var xA = new Es("Cyrl", [{
            start: "\u0400",
            end: "\u04ff"
        }, {
            start: le,
            end: "9"
        }], iA, {
            fontSize: 14,
            lineHeight: 1.5,
            Ra: 24
        });
        var dt;
        dt = new Fs("RUSSIAN", Ak, "Russian", xA);
        var et;
        et = new Fs("SANSKRIT", "sa", "Sanskrit", rA);
        var ft;
        ft = new Fs("SERBIAN", Vk, "Serbian", xA);
        var yA = new Es("Sinh", [{
            start: "\u0d80",
            end: "\u0dff"
        }, {
            start: "\u200c",
            end: "\u200d"
        }, {
            start: le,
            end: "9"
        }], iA, {
            fontSize: 14,
            lineHeight: 1.5,
            Ra: 24
        });
        var gt;
        gt = new Fs("SINHALESE", "si", "Sinhalese", yA);
        var zA = new Es("Taml", [{
            start: "\u0b80",
            end: "\u0bff"
        }], iA, {
            fontSize: 14,
            lineHeight: 1.5,
            Ra: 24
        });
        var ht;
        ht = new Fs("TAMIL", "ta", "Tamil", zA);
        var AA = new Es("Telu", [{
            start: "\u0c00",
            end: "\u0c7f"
        }], iA, {
            fontSize: 16,
            lineHeight: 1.8,
            Ra: 28
        });
        var it;
        it = new Fs("TELUGU", il, "Telugu", AA);
        var jt;
        jt = new Fs("TIGRINYA", ql, "Tigrinya", jA);
        var kt;
        kt = new Fs("URDU", Gl, "Urdu", kA);
        var ut = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^/?#]*)@)?([\\w\\d\\-\\u0100-\\uffff.%]*)(?::([0-9]+))?)?([^?#]+)?(?:\\?([^#]*))?(?:#(.*))?$");
        Q = lt[F];
        Q.fc = M;
        Q.Pd = M;
        Q.Hc = M;
        Q.od = j;
        Q.Ic = M;
        Q.Od = M;
        Q.Sj = !1;
        Q.md = !1;
        Q.toString = function () {
            if (this.b) return this.b;
            var a = [];
            this.fc && a[s](yt(this.fc, BA), Ce);
            this.Hc && (a[s](je), this.Pd && a[s](yt(this.Pd, BA), Oe), a[s](S(this.Hc) ? aa(this.Hc) : j), this.od != j && a[s](Ce, n(this.od)));
            this.Ic && (this.Hc && this.Ic[Ya](0) != ie && a[s](ie), a[s](yt(this.Ic, this.Ic[Ya](0) == ie ? CA : DA)));
            var b = n(this.c);
            b && a[s](Me, b);
            this.Od && a[s](Vc, yt(this.Od, EA));
            return this.b = a[L](M)
        };
        Q.W = function () {
            var a = this.fc,
                b = this.Pd,
                c = this.Hc,
                d = this.od,
                f = this.Ic,
                g = this.c.W(),
                h = this.Od,
                k = new lt(j, this.md);
            a && nt(k, a);
            b && ot(k, b);
            c && pt(k, c);
            d && qt(k, d);
            f && rt(k, f);
            g && st(k, g);
            h && tt(k, h);
            return k
        };
        var Et = /^[a-zA-Z0-9\-_.!~*'():\/;?]*$/,
            BA = /[#\/\?@]/g,
            DA = /[\#\?:]/g,
            CA = /[\#\?]/g,
            zt = /[\#\?@]/g,
            EA = /#/g;
        Q = vt[F];
        Q.L = j;
        Q.G = j;
        ra(Q, function (a) {
            Bt(this);
            a = Dt(this, a);
            if (this.L.hc(a)) {
                Ct(this);
                var b = this.L.get(a);
                km(b) ? this.G -= b[E] : this.G--;
                return this.L.remove(a)
            }
            return !1
        });
        xa(Q, function () {
            Ct(this);
            this.L && this.L[Hb]();
            this.G = 0
        });
        Q.Sa = function () {
            Bt(this);
            return this.G == 0
        };
        Q.hc = function (a) {
            Bt(this);
            a = Dt(this, a);
            return this.L.hc(a)
        };
        Q.Pb = function () {
            Bt(this);
            for (var a = this.L.yb(), b = this.L.Pb(), c = [], d = 0; d < b[E]; d++) {
                var f = a[d];
                if (km(f))
                    for (var g = 0; g < f[E]; g++) c[s](b[d]);
                else c[s](b[d])
            }
            return c
        };
        Q.yb = function (a) {
            Bt(this);
            if (a)
                if (a = Dt(this, a), this.hc(a)) {
                    var b = this.L.get(a);
                    if (km(b)) return b;
                    else a = [], a[s](b)
                } else a = [];
                else
                    for (var b = this.L.yb(), a = [], c = 0; c < b[E]; c++) {
                        var d = b[c];
                        km(d) ? an(a, d) : a[s](d)
                    }
                return a
        };
        Q.set = function (a, b) {
            Bt(this);
            Ct(this);
            a = Dt(this, a);
            if (this.hc(a)) {
                var c = this.L.get(a);
                km(c) ? this.G -= c[E] : this.G--
            }
            this.L.set(a, b);
            this.G++;
            return this
        };
        Q.get = function (a, b) {
            Bt(this);
            a = Dt(this, a);
            if (this.hc(a)) {
                var c = this.L.get(a);
                return km(c) ? c[0] : c
            } else return b
        };
        Q.toString = function () {
            if (this.b) return this.b;
            if (!this.L) return M;
            for (var a = [], b = 0, c = this.L.Pb(), d = 0; d < c[E]; d++) {
                var f = c[d],
                    g = Am(f),
                    f = this.L.get(f);
                if (km(f))
                    for (var h = 0; h < f[E]; h++) b > 0 && a[s](ad), a[s](g), f[h] !== M && a[s](Ke, Am(f[h])), b++;
                else b > 0 && a[s](ad), a[s](g), f !== M && a[s](Ke, Am(f)), b++
            }
            return this.b = a[L](M)
        };
        Q.W = function () {
            var a = new vt;
            if (this.c) a.c = this.c;
            if (this.b) a.b = this.b;
            if (this.L) a.L = this.L.W();
            return a
        };
        var FA = 0;
        U(Mt, np);
        Mt[F].n = function () {
            this.d && Nt(this, this.b);
            this.d = j
        };
        Mt[F].j = function (a, b, c) {
            a(b, b ? c : j);
            this.b = j
        };
        U(Ot, wq);
        Q = Ot[F];
        Q.J = j;
        Q.of = j;
        Q.qg = j;
        Q.pf = j;
        Q.uc = -1;
        Q.Vb = -1;
        var GA = {
            3: 13,
            12: 144,
            63232: 38,
            63233: 40,
            63234: 37,
            63235: 39,
            63236: 112,
            63237: 113,
            63238: 114,
            63239: 115,
            63240: 116,
            63241: 117,
            63242: 118,
            63243: 119,
            63244: 120,
            63245: 121,
            63246: 122,
            63247: 123,
            63248: 44,
            63272: 46,
            63273: 36,
            63275: 35,
            63276: 33,
            63277: 34,
            63289: 144,
            63302: 45
        }, HA = {
                Up: 38,
                Down: 40,
                Left: 37,
                Right: 39,
                Enter: 13,
                F1: 112,
                F2: 113,
                F3: 114,
                F4: 115,
                F5: 116,
                F6: 117,
                F7: 118,
                F8: 119,
                F9: 120,
                F10: 121,
                F11: 122,
                F12: 123,
                "U+007F": 46,
                Home: 36,
                End: 35,
                PageUp: 33,
                PageDown: 34,
                Insert: 45
            }, IA = {
                61: 187,
                59: 186
            }, JA = X || Y && W(ve);
        Q = Ot[F];
        Q.Jj = function (a) {
            if (Y && (this.uc == 17 && !a[hc] || this.uc == 18 && !a[Xb])) this.Vb = this.uc = -1;
            JA && !Hq(a[A], this.uc, a[Bc], a[hc], a[Xb]) ? this[Eb](a) : Z && a[A] in IA ? this.Vb = IA[a[A]] : this.Vb = a[A]
        };
        Q.Kj = function () {
            this.Vb = this.uc = -1
        };
        va(Q, function (a) {
            var b = a.Ha,
                c, d;
            X && a[C] == pj ? (c = this.Vb, d = c != 13 && c != 27 ? b[A] : 0) : Y && a[C] == pj ? (c = this.Vb, d = b[vb] >= 0 && b[vb] < 63232 && Iq(c) ? b[vb] : 0) : To ? (c = this.Vb, d = Iq(c) ? b[A] : 0) : (c = b[A] || this.Vb, d = b[vb] || 0, Ko && d == 63 && !c && (c = 191));
            var f = c,
                g = b.keyIdentifier;
            c ? c >= 63232 && c in GA ? f = GA[c] : c == 25 && a[Bc] && (f = 9) : g && g in HA && (f = HA[g]);
            a = f == this.uc;
            this.uc = f;
            b = new Rt(f, d, a, b);
            try {
                oq(this, b)
            } finally {
                b.s()
            }
        });
        Q.h = dm("J");
        Q.n = function () {
            Ot.g.n[I](this);
            Qt(this)
        };
        U(Rt, Mp);
        var Ut = {
            3: 13,
            12: 144,
            63232: 38,
            63233: 40,
            63234: 37,
            63235: 39,
            63236: 112,
            63237: 113,
            63238: 114,
            63239: 115,
            63240: 116,
            63241: 117,
            63242: 118,
            63243: 119,
            63244: 120,
            63245: 121,
            63246: 122,
            63247: 123,
            63248: 44,
            63272: 46,
            63273: 36,
            63275: 35,
            63276: 33,
            63277: 34,
            63289: 144,
            63302: 45
        }, Vt = {
                Up: 38,
                Down: 40,
                Left: 37,
                Right: 39,
                Enter: 13,
                F1: 112,
                F2: 113,
                F3: 114,
                F4: 115,
                F5: 116,
                F6: 117,
                F7: 118,
                F8: 119,
                F9: 120,
                F10: 121,
                F11: 122,
                F12: 123,
                "U+007F": 46,
                Home: 36,
                End: 35,
                PageUp: 33,
                PageDown: 34,
                Insert: 45
            }, KA = {
                61: 187,
                59: 186
            }, LA = X || Y && W(ve);
        U(Wt, Ip);
        U(Xt, Wt);
        im(Yt);
        Yt[F].b = 0;
        Yt.Q();
        U(Zt, wq);
        Zt[F].Zi = Yt.Q();
        var $t = j;
        Q = Zt[F];
        Q.Na = j;
        Q.K = !1;
        Q.J = j;
        Q.bf = j;
        Q.sd = j;
        Q.Pa = j;
        Q.Ja = j;
        Q.Sb = j;
        Q.tj = !1;
        Q.Fa = function () {
            return this.Na || (this.Na = Ce + (this.Zi.b++)[Wb](36))
        };
        Q.h = dm("J");
        Q.og = function (a) {
            this.Pa && this.Pa != a && e(m("Method not supported"));
            Zt.g.og[I](this, a)
        };
        Q.C = dm("af");
        Q.l = function () {
            this.J = this.af.b[xb](O)
        };
        Q.S = function () {
            this.K = !0;
            iu(this, function (a) {
                !a.K && a.h() && a.S()
            })
        };
        Q.wb = function () {
            iu(this, function (a) {
                a.K && a.wb()
            });
            this.M && Fq(this.M);
            this.K = !1
        };
        Q.n = function () {
            Zt.g.n[I](this);
            this.K && this.wb();
            this.M && (this.M.s(), delete this.M);
            iu(this, function (a) {
                a.s()
            });
            !this.tj && this.J && jo(this.J);
            this.Pa = this.sd = this.J = this.Sb = this.Ja = j
        };
        Q.Ib = function (a, b) {
            this.mg(a, gu(this), b)
        };
        Q.mg = function (a, b, c) {
            a.K && (c || !this.K) && e(m(Ze));
            (b < 0 || b > gu(this)) && e(m("Child component index out of bounds"));
            if (!this.Sb || !this.Ja) this.Sb = {}, this.Ja = [];
            if (a.Pa == this) this.Sb[a.Fa()] = a, Xm(this.Ja, a);
            else {
                var d = this.Sb,
                    f = a.Fa();
                f in d && e(m('The object already contains the key "' + f + Uc));
                d[f] = a
            }
            cu(a, this);
            bn(this.Ja, b, 0, a);
            a.K && this.K && a.Pa == this ? (c = this.Pc(), c[db](a.h(), c[D][b] || j)) : c ? (this.J || this.l(), b = hu(this, b + 1), eu(a, this.Pc(), b ? b.J : j)) : this.K && !a.K && a.J && a.S()
        };
        Q.Pc = dm("J");
        Q.removeChild = function (a, b) {
            if (a) {
                var c = S(a) ? a : a.Fa(),
                    a = du(this, c);
                c && a && (on(this.Sb, c), Xm(this.Ja, a), b && (a.wb(), a.J && jo(a.J)), cu(a, j))
            }
            a || e(m("Child is not in parent component"));
            return a
        };
        U(lu, np);
        Q = lu[F];
        Q.zf = Fz;
        Q.yf = Fz;
        Q.Le = function (a, b) {
            return Vm(this.j, b[A])
        };
        Q.vg = Fz;
        Q.fd = Fz;
        U(ou, lu);
        var pu = {
            Ig: [13],
            Jg: [8, 37]
        }, MA = /[a-z\']/i;
        ou[F].vg = function (a, b, c) {
            return this.fd(c)
        };
        ou[F].fd = function (a) {
            return MA[Ma](a)
        };
        U(qu, Ip);
        U(ru, np);
        Q = ru[F];
        Q.cd = function (a) {
            return !!this.z[qm(a)]
        };
        Q.Za = function (a) {
            this.z[qm(a)] = !0
        };
        Q.Ab = function (a) {
            this.cd(a) && (this.cf(a), this.z[qm(a)] = !1)
        };
        Q.tg = P(!1);
        Q.execCommand = function (a, b, c) {
            var d = this.ug(a, b);
            if (gm(c = this.Oh(a, b, c))) return b = new qu(sh, b, d, c), oq(a, b), c
        };
        Q.Oh = hm;
        Q.ug = hm;
        Q.isEnabled = function (a) {
            return !!this.p[qm(a)]
        };
        Q.gf = function (a) {
            this.p[qm(a)] = !0
        };
        Q.cf = function (a) {
            this.p[qm(a)] = !1
        };
        U(su, ru);
        var NA = pn({
            gf: 0,
            cf: 1,
            isEnabled: 2,
            Za: 3,
            Ab: 4,
            cd: 5,
            execCommand: 6,
            ug: 7,
            tg: 8,
            handleEvent: 9
        });
        su[F].Za = function (a) {
            if (!this.cd(a)) {
                su.g.Za[I](this, a);
                var b = this.oc(),
                    c = this;
                b && b[E] && V(b, function (b) {
                    a.w(b, c)
                }, this);
                tu(this, a)
            }
        };
        su[F].Ab = function (a) {
            su.g.Ab[I](this, a);
            var b = this.oc();
            V(b, function (b) {
                a.Ca(b, this)
            }, this);
            vu(this, a)
        };
        U(Bu, su);
        var OA = {
            Kd: bh,
            Xf: "maybeChangeDirection"
        }, PA = pn(OA);
        Q = Bu[F];
        Q.Fe = Fz;
        Q.tg = function (a) {
            a = Cu(this, a);
            return !!a && a in PA
        };
        Q.Oh = function (a, b, c) {
            b = Cu(this, b);
            if (!b) return !1;
            switch (b) {
            case OA.Kd:
                b = c.N;
                Bq(a, this.b).N = b;
                b = c.X;
                c = c.B;
                if (nn(ez, b) && nn(ez, c)) b == c ? Bq(a, this.b).N = !1 : (a = Bq(a, this.b), a.X = b, a.B = c);
                return !0;
            case OA.Xf:
                return a.Ze(c), !0
            }
            return !1
        };
        Q.ug = function (a, b) {
            if (b = Cu(this, b)) switch (b) {
            case OA.Kd:
                var c = this.ea(a),
                    d = this.N(a);
                return new wu(d, c.X, c.B);
            case OA.Xf:
                return a.Be()
            }
        };
        Q.ea = function (a) {
            a = Bq(a, this.b);
            return Ks(a.X, a.B)
        };
        Q.N = function (a) {
            return Bq(a, this.b).N
        };
        Q.Za = function (a) {
            if (!this.cd(a)) {
                if (this.d) {
                    var b = Bq(a, this.b);
                    qn(b, new wu(this.d.N, this.d.X, this.d.B))
                }
                Bu.g.Za[I](this, a)
            }
        };
        var Ou = {};
        var QA;
        im(Hu);
        Q = Hu[F];
        Q.$d = bm();
        Q.l = function (a) {
            return a.C().l(O, this.Tb(a)[L](N), a.Oa)
        };
        Q.ab = function (a) {
            return a
        };
        Q.rd = function (a) {
            fu(a) && this.Gh(a.h(), !0);
            a[qc]() && this.tb(a, a.Mc)
        };
        Q.uh = function (a, b) {
            $o(a, !b, !X && !To)
        };
        Q.Gh = function (a, b) {
            Ju(a, this.v() + be, b)
        };
        Q.wh = function (a) {
            var b;
            return a.Ea & 32 && (b = a.h()) ? ro(b) : !1
        };
        Q.tb = function (a, b) {
            var c;
            if (a.Ea & 32 && (c = a.h())) {
                if (!b && a.U & 32) {
                    try {
                        c.blur()
                    } catch (d) {}
                    a.U & 32 && a.qd(j)
                }
                if (ro(c) != b) b ? c.tabIndex = 0 : c[Ec](dl)
            }
        };
        Q.bg = function (a, b, c) {
            var d = a.h();
            if (d) {
                var f = this.lf(b);
                f && Ju(a, f, c);
                this.ae(d, b, c)
            }
        };
        Q.ae = function (a, b, c) {
            QA || (QA = {
                1: yh,
                8: Gk,
                16: eh,
                64: Jh
            });
            (b = QA[b]) && Fu(a, b, c)
        };
        Q.Cc = function (a, b) {
            var c = this.ab(a);
            if (c && (ho(c), b))
                if (S(b)) qo(c, b);
                else {
                    var d = function (a) {
                        if (a) {
                            var b = Rn(c);
                            c[Ja](S(a) ? b[$a](a) : a)
                        }
                    };
                    km(b) ? V(b, d) : lm(b) && !(Qj in b) ? V($m(b), d) : d(b)
                }
        };
        Q.v = P(Ci);
        Q.Tb = function (a) {
            var b = this.v(),
                c = [b],
                d = this.v();
            d != b && c[s](d);
            b = Mu(this, a.U);
            c[s][Ac](c, b);
            (a = a.$c) && c[s][Ac](c, a);
            X && !W(Ae) && c[s][Ac](c, Ku(c));
            return c
        };
        Q.lf = function (a) {
            if (!this.c) {
                var b = this.v();
                this.c = {
                    1: b + Jd,
                    2: b + Qd,
                    4: b + zd,
                    8: b + ee,
                    16: b + Gd,
                    32: b + Ld,
                    64: b + Xd
                }
            }
            return this.c[a]
        };
        U(Nu, Zt);
        Q = Nu[F];
        Q.Oa = j;
        Q.U = 0;
        Q.Ea = 39;
        Q.Dh = 255;
        Q.jg = 0;
        Q.Mc = !0;
        Q.$c = j;
        Q.Uf = !0;
        Q.rh = !1;
        Q.La = dm("c");
        Q.l = function () {
            var a = this.c.l(this);
            this.J = a;
            var b = this.c.$d();
            b && Eu(a, b);
            this.rh || this.c.uh(a, !1);
            this.Mc || Zo(a, !1)
        };
        Q.Pc = function () {
            return this.c.ab(this.h())
        };
        Q.S = function () {
            Nu.g.S[I](this);
            this.c.rd(this);
            if (this.Ea & -2 && (this.Uf && Qu(this, !0), this.Ea & 32)) {
                var a = this.h();
                if (a) {
                    var b = this.j || (this.j = new Ot);
                    Pt(b, a);
                    bu(this).w(b, nj, this.lc).w(a, Oh, this.Ui).w(a, Mg, this.qd)
                }
            }
        };
        Q.wb = function () {
            Nu.g.wb[I](this);
            this.j && Qt(this.j);
            this.Mc && this[qc]() && this.c.tb(this, !1)
        };
        Q.n = function () {
            Nu.g.n[I](this);
            this.j && (this.j.s(), delete this.j);
            delete this.c;
            this.$c = this.Oa = j
        };
        Q.Hd = cm("Oa");
        Q.Kc = function () {
            var a = this.Oa;
            if (!a) return M;
            a = S(a) ? a : km(a) ? Xr(a, vo)[L](M) : so(a);
            return ym(a)
        };
        Q.isEnabled = function () {
            return !(this.U & 1)
        };
        Q.Ga = function (a) {
            var b = this.Pa;
            if ((!b || typeof b[qc] != Vh || b[qc]()) && Su(this, 1, !a)) a || (Uu(this, !1), Ru(this, !1)), this.Mc && this.c.tb(this, a), Tu(this, 1, !a)
        };
        Q.N = function () {
            return !!(this.U & 4)
        };
        Q.rg = function (a) {
            Su(this, 8, a) && Tu(this, 8, a)
        };
        Q.Y = function (a) {
            Su(this, 64, a) && Tu(this, 64, a)
        };
        Q.ee = function (a) {
            (!a[Oa] || !ko(this.h(), a[Oa])) && oq(this, Ih) && this[qc]() && Xu(this, 2) && Ru(this, !0)
        };
        Q.ue = function (a) {
            if ((!a[Oa] || !ko(this.h(), a[Oa])) && oq(this, sj)) Xu(this, 4) && Uu(this, !1), Xu(this, 2) && Ru(this, !1)
        };
        Q.Fc = function (a) {
            this[qc]() && (Xu(this, 2) && Ru(this, !0), Np(a) && (Xu(this, 4) && Uu(this, !0), this.c.wh(this) && this.h()[wb]()));
            !this.rh && Np(a) && a[bb]()
        };
        Q.Jc = function (a) {
            this[qc]() && (Xu(this, 2) && Ru(this, !0), this.N() && this.zb(a) && Xu(this, 4) && Uu(this, !1))
        };
        Q.Eh = function (a) {
            this[qc]() && this.zb(a)
        };
        Q.zb = function (a) {
            Xu(this, 16) && Vu(this, !(this.U & 16));
            Xu(this, 8) && this.rg(!0);
            Xu(this, 64) && this.Y(!(this.U & 64));
            var b = new Ip(rg, this);
            if (a)
                for (var c = [zg, qh, Fj, Kk, ik], d, f = 0; d = c[f]; f++) b[d] = a[d];
            return oq(this, b)
        };
        Q.Ui = function () {
            Xu(this, 32) && Su(this, 32, !0) && Tu(this, 32, !0)
        };
        Q.qd = function () {
            Xu(this, 4) && Uu(this, !1);
            Xu(this, 32) && Su(this, 32, !1) && Tu(this, 32, !1)
        };
        Q.lc = function (a) {
            return this.Mc && this[qc]() && this.Ae(a) ? (a[bb](), a[jc](), !0) : !1
        };
        Q.Ae = function (a) {
            return a[A] == 13 && this.zb(a)
        };
        om(Nu) || e(m("Invalid component class " + Nu));
        om(Hu) || e(m("Invalid renderer class " + Hu));
        var RA = qm(Nu);
        Ou[RA] = Hu;
        Gu(Ci, function () {
            return new Nu(j)
        });
        U(Yu, Hu);
        im(Yu);
        Yu[F].l = function (a) {
            return a.C().l(O, this.v())
        };
        Yu[F].Cc = bm();
        Yu[F].v = P(Li);
        U(Zu, Nu);
        Zu[F].S = function () {
            Zu.g.S[I](this);
            Eu(this.h(), Hk)
        };
        Gu(Li, function () {
            return new Zu
        });
        im($u);
        Q = $u[F];
        Q.Hh = bm();
        Q.l = function (a) {
            return a.C().l(O, this.Tb(a)[L](N))
        };
        Q.fg = function (a) {
            a = a.h();
            $o(a, !0, Z);
            if (X) a.hideFocus = !0;
            var b = this.Hh();
            b && Eu(a, b)
        };
        Q.v = P("inputapi-container");
        Q.Tb = function (a) {
            var b = this.v(),
                c = [b, a.vd == oi ? b + Pd : b + ge];
            a[qc]() || c[s](b + Jd);
            return c
        };
        U(hv, wp);
        hv[F].b = function (a, b, c, d) {
            vp(this.c, a, b, c, j, j, d)
        };
        U(gv, Hu);
        im(gv);
        Q = gv[F];
        Q.$d = P("menuitem");
        Q.l = function (a) {
            var b = a.C().l(O, this.Tb(a)[L](N), jv(this, a.Oa, a.C()));
            lv(this, a, b, !! (a.Ea & 8) || !! (a.Ea & 16));
            return b
        };
        Q.ab = function (a) {
            return a && a[B]
        };
        Q.Cc = function (a, b) {
            var c = this.ab(a),
                d = kv(this, a) ? c[B] : j;
            gv.g.Cc[I](this, a, b);
            d && !kv(this, a) && c[db](d, c[B] || j)
        };
        Q.lf = function (a) {
            switch (a) {
            case 2:
                return iv(this, 0);
            case 16:
            case 8:
                return Pi;
            default:
                return gv.g.lf[I](this, a)
            }
        };
        Q.v = P(Ji);
        U(dv, $u);
        im(dv);
        dv[F].Hh = P("menu");
        dv[F].v = P("inputapi-menu");
        dv[F].fg = function (a) {
            dv.g.fg[I](this, a);
            Fu(a.h(), gi, Bl)
        };
        U(mv, Nu);
        mv[F].Ma = function () {
            var a = this.sd;
            return a != j ? a : this.Kc()
        };
        mv[F].Kc = function () {
            var a = this.Oa;
            return km(a) ? (a = Xr(a, function (a) {
                return Vm(Mn(a), Ki) ? M : vo(a)
            })[L](M), ym(a)) : mv.g.Kc[I](this)
        };
        mv[F].Jc = function (a) {
            var b = this.Pa;
            if (b) {
                var c = b.lg;
                b.lg = j;
                if (b = c && nm(a[Ob])) b = new Jn(a[Ob], a[Pb]), b = c == b ? !0 : !c || !b ? !1 : c.x == b.x && c.y == b.y;
                if (b) return
            }
            mv.g.Jc[I](this, a)
        };
        Gu(Ji, function () {
            return new mv(j)
        });
        U(nv, mv);
        nv[F].Ae = function (a) {
            return this.b(a) && oq(this, {
                type: rg,
                eh: a
            })
        };
        U(pv, Zt);
        Q = pv[F];
        Q.td = j;
        Q.Ce = j;
        Q.Xd = j;
        Q.vd = j;
        Q.P = !0;
        Q.Uc = !0;
        Q.Rb = !0;
        Q.Ba = -1;
        Q.ua = j;
        Q.Jb = !1;
        Q.Aj = !1;
        Q.Bj = !0;
        Q.sc = j;
        Q.La = dm("Xd");
        Q.l = function () {
            this.J = this.Xd.l(this)
        };
        Q.Pc = function () {
            return this.h()
        };
        Q.S = function () {
            pv.g.S[I](this);
            iu(this, function (a) {
                a.K && uv(this, a)
            }, this);
            var a = this.h();
            this.Xd.fg(this);
            this.Ta(this.P, !0);
            bu(this).w(this, Ih, this.eg).w(this, ni, this.mj).w(this, Dl, this.oj).w(this, Xj, this.rj).w(this, hh, this.pj).w(a, Gj, this.nj).w(Rn(a), Kj, this.qj).w(a, [Gj, Kj, Jj, Ij], this.dg);
            this.Rb && sv(this, !0)
        };
        Q.wb = function () {
            vv(this, -1);
            this.ua && this.ua.Y(!1);
            this.Jb = !1;
            pv.g.wb[I](this)
        };
        Q.n = function () {
            pv.g.n[I](this);
            if (this.Ce) this.Ce.s(), this.Ce = j;
            this.Xd = this.ua = this.sc = this.td = j
        };
        Q.eg = P(!0);
        Q.mj = function (a) {
            var b = ju(this, a[H]);
            if (b > -1 && b != this.Ba) {
                var c = hu(this, this.Ba);
                c && Ru(c, !1);
                this.Ba = b;
                c = hu(this, this.Ba);
                this.Jb && Uu(c, !0);
                this.Bj && this.ua && c != this.ua && (c.Ea & 64 ? c.Y(!0) : this.ua.Y(!1))
            }
            Fu(this.h(), tg, a[H].h().id)
        };
        Q.oj = function (a) {
            if (a[H] == hu(this, this.Ba)) this.Ba = -1;
            Fu(this.h(), tg, M)
        };
        Q.rj = function (a) {
            if ((a = a[H]) && a != this.ua && a.Pa == this) this.ua && this.ua.Y(!1), this.ua = a
        };
        Q.pj = function (a) {
            if (a[H] == this.ua) this.ua = j
        };
        Q.nj = function (a) {
            if (this.Uc) this.Jb = !0;
            var b = qv(this);
            b && ro(b) ? b[wb]() : a[bb]()
        };
        Q.qj = function () {
            this.Jb = !1
        };
        Q.dg = function (a) {
            var b;
            a: {
                b = a[H];
                if (this.sc)
                    for (var c = this.h(); b && b !== c;) {
                        var d = b.id;
                        if (d in this.sc) {
                            b = this.sc[d];
                            break a
                        }
                        b = b[K]
                    }
                b = j
            }
            if (b) switch (a[C]) {
            case Gj:
                b.Fc(a);
                break;
            case Kj:
                b.Jc(a);
                break;
            case Jj:
                b.ee(a);
                break;
            case Ij:
                b.ue(a)
            }
        };
        Q.Jh = bm();
        Q.mf = function () {
            vv(this, -1);
            this.Jb = !1;
            this.ua && this.ua.Y(!1)
        };
        Q.Ne = function (a) {
            return this[qc]() && this.P && (gu(this) != 0 || this.td) && this.bd(a) ? (a[bb](), a[jc](), !0) : !1
        };
        Q.bd = function (a) {
            var b = hu(this, this.Ba);
            if (b && typeof b.lc == Vh && b.lc(a)) return !0;
            if (this.ua && this.ua != b && typeof this.ua.lc == Vh && this.ua.lc(a)) return !0;
            if (a[Bc] || a[hc] || a[gb] || a[Xb]) return !1;
            switch (a[A]) {
            case 27:
                if (this.Rb) qv(this).blur();
                else return !1;
                break;
            case 36:
                wv(this);
                break;
            case 35:
                yv(this);
                break;
            case 38:
                if (this.vd == Jl) this.kc();
                else return !1;
                break;
            case 37:
                if (this.vd == oi) fu(this) ? this.jc() : this.kc();
                else return !1;
                break;
            case 40:
                if (this.vd == Jl) this.jc();
                else return !1;
                break;
            case 39:
                if (this.vd ==
                    oi) fu(this) ? this.kc() : this.jc();
                else return !1;
                break;
            default:
                return !1
            }
            return !0
        };
        Q.Ib = function (a, b) {
            pv.g.Ib[I](this, a, b)
        };
        Q.mg = function (a, b, c) {
            a.jg |= 2;
            a.jg |= 64;
            (this.Rb || !this.Aj) && Wu(a, 32, !1);
            Pu(a, !1);
            pv.g.mg[I](this, a, b, c);
            c && this.K && uv(this, a);
            b <= this.Ba && this.Ba++
        };
        Q.removeChild = function (a, b) {
            if (a = S(a) ? du(this, a) : a) {
                var c = ju(this, a);
                c != -1 && (c == this.Ba ? Ru(a, !1) : c < this.Ba && this.Ba--);
                (c = a.h()) && c.id && on(this.sc, c.id)
            }
            a = pv.g[oc][I](this, a, b);
            Pu(a, !0);
            return a
        };
        Q.Ta = function (a, b) {
            if (b || this.P != a && oq(this, a ? Ok : mi)) {
                this.P = a;
                var c = this.h();
                c && (Zo(c, a), this.Rb && bv(qv(this), this.Uc && this.P), b || oq(this, this.P ? xg : wg));
                return !0
            }
            return !1
        };
        Q.isEnabled = dm("Uc");
        Q.Ga = function (a) {
            if (this.Uc != a && oq(this, a ? Gh : xh)) a ? (this.Uc = !0, iu(this, function (a) {
                a.Kh ? delete a.Kh : a.Ga(!0)
            })) : (iu(this, function (a) {
                a[qc]() ? a.Ga(!1) : a.Kh = !0
            }), this.Jb = this.Uc = !1), this.Rb && bv(qv(this), a && this.P)
        };
        Q.tb = function (a) {
            a != this.Rb && this.K && sv(this, a);
            this.Rb = a;
            this.Uc && this.P && bv(qv(this), a)
        };
        Q.Zb = dm("Ba");
        Q.jc = function () {
            xv(this, function (a, b) {
                return (a + 1) % b
            }, this.Ba)
        };
        Q.kc = function () {
            xv(this, function (a, b) {
                a--;
                return a < 0 ? b - 1 : a
            }, this.Ba)
        };
        Q.Mh = function (a) {
            return a.Mc && a[qc]() && !! (a.Ea & 2)
        };
        U(zv, Hu);
        im(zv);
        zv[F].v = P(Ii);
        U(Av, Nu);
        Gu(Ii, function () {
            return new Av(j)
        });
        Gu(Li, function () {
            return new Zu
        });
        U(Bv, pv);
        Q = Bv[F];
        Q.Ed = !0;
        Q.Lj = !1;
        Q.v = function () {
            return this.La().v()
        };
        Q.Vc = function (a) {
            this.Ib(a, !0)
        };
        Q.Ta = function (a, b, c) {
            (b = Bv.g.Ta[I](this, a, b)) && a && this.K && this.Ed && qv(this)[wb]();
            a && c && nm(c[Ob]) ? this.lg = new Jn(c[Ob], c[Pb]) : this.lg = j;
            return b
        };
        Q.eg = function (a) {
            this.Ed && qv(this)[wb]();
            return Bv.g.eg[I](this, a)
        };
        Q.Mh = function (a) {
            return (this.Lj || a[qc]()) && a.Mc && !! (a.Ea & 2)
        };
        U(Dv, Bv);
        Q = Dv[F];
        Q.Ti = !1;
        Q.kh = 0;
        Q.jh = j;
        Q.S = function () {
            Dv.g.S[I](this);
            vn(this.Mb, this.vj, this);
            var a = bu(this);
            a.w(this, rg, this.wj);
            a.w(yo(this.C()), Gj, this.Rc, !0);
            Y && a.w(yo(this.C()), jh, this.Rc, !0)
        };
        Q.vj = function (a) {
            bu(this).w(a.J, a.Uj, this.Fj)
        };
        Q.Yb = function () {
            if (this.P && (this.Ta(!1), !this.P)) this.kh = Lq(), this.jh = j
        };
        Q.wj = function () {
            this.Yb()
        };
        Q.Fj = function (a) {
            for (var b = this.Mb.Pb(), c = 0; c < b[E]; c++) {
                var d = this.Mb.get(b[c]);
                if (d.J == a[mb]) {
                    Ev(this, gm(d.Ij) ? new yp(d.J, d.Ij, !0) : new Cp(a[Ob], a[Pb]), d.Wj, d.Vj, d.J);
                    a[bb]();
                    a[jc]();
                    break
                }
            }
        };
        Q.Rc = function (a) {
            this.P && !Cv(this, a[H]) && this.Yb()
        };
        Q.mf = function (a) {
            Dv.g.mf[I](this, a);
            this.Yb()
        };
        Q.n = function () {
            Dv.g.n[I](this);
            this.Mb && (this.Mb[Hb](), delete this.Mb)
        };
        U(Fv, Dv);
        Q = Fv[F];
        Q.S = function () {
            Fv.g.S[I](this);
            this[Bb](rg, this.Cj, !1, this)
        };
        Q.bd = function (a) {
            if (Vm(this.yj, a[A]) && this.Rb) {
                this.Yb();
                oq(this, Mg);
                if (this.j) this.j(!1, M), this.j = j;
                return !0
            }
            return Fv.g.bd[I](this, a) || this.kg(a)
        };
        Q.kg = function (a) {
            return Gq(a)
        };
        Q.Cj = function (a) {
            a = a[H].sd || j;
            if (this.j) this.j(a != j, a), this.j = j
        };
        Q.Rc = function (a) {
            Fv.g.Rc[I](this, a);
            if (!this.P && this.j) this.j(!1, M), this.j = j
        };
        U(Iv, wq);
        var SA = X || Z && W("1.9.3");
        Q = Iv[F];
        ya(Q, 0);
        za(Q, 0);
        oa(Q, 0);
        pa(Q, 0);
        Q.Yg = 0;
        Q.Zg = 0;
        Q.Ld = 0;
        Q.Md = 0;
        Q.Pf = !0;
        Q.ec = !1;
        Q.Xg = 0;
        Q.Hi = 0;
        Q.Gi = !1;
        Q.Ga = cm("Pf");
        Q.n = function () {
            Iv.g.n[I](this);
            dq(this.d, [wl, Gj], this.Cf, !1, this);
            this.b.s();
            delete this[H];
            delete this.d;
            delete this.b
        };
        Q.Cf = function (a) {
            var b = a[C] == Gj;
            if (this.Pf && !this.ec && (!b || Np(a))) {
                Lv(a);
                if (this.Xg == 0)
                    if (Jv(this, a), this.ec) a[bb]();
                    else return;
                    else a[bb]();
                var b = this.c,
                    c = b[Qb],
                    d = !SA;
                this.b.w(b, [vl, Hj], this.Fi, d);
                this.b.w(b, [ul, Kj], this.Gd, d);
                SA ? (c.setCapture(!1), this.b.w(c, xj, this.Gd)) : this.b.w($n(b), Mg, this.Gd);
                X && this.Gi && this.b.w(b, Dh, Jp);
                this.p && this.b.w(this.p, Ek, this.Ii, d);
                ya(this, this.Yg = a[Ob]);
                za(this, this.Zg = a[Pb]);
                oa(this, a[ob]);
                pa(this, a[pb]);
                this.Ld = this[H].offsetLeft;
                this.Md = this[H][Fc];
                this.f = Ao(Pn(this.c));
                this.Hi = Lq()
            } else oq(this, Eh)
        };
        Q.Gd = function (a, b) {
            Fq(this.b);
            SA && this.c.releaseCapture();
            var c = Nv(this, this.Ld),
                d = Ov(this, this.Md);
            this.ec ? (Lv(a), this.ec = !1, xq(this, new Kv(Hh, this, a[Ob], a[Pb], a, c, d, b || a[C] == tl))) : oq(this, Eh);
            (a[C] == ul || a[C] == tl) && a[bb]()
        };
        Q.Fi = function (a) {
            if (this.Pf) {
                Lv(a);
                var b = a[Ob] - this[Ob],
                    c = a[Pb] - this[Pb];
                ya(this, a[Ob]);
                za(this, a[Pb]);
                oa(this, a[ob]);
                pa(this, a[pb]);
                if (!this.ec) {
                    var d = this.Yg - this[Ob],
                        f = this.Zg - this[Pb];
                    if (d * d + f * f > this.Xg && (Jv(this, a), !this.ec)) {
                        this.Gd(a);
                        return
                    }
                }
                c = Mv(this, b, c);
                b = c.x;
                c = c.y;
                this.ec && xq(this, new Kv(Jg, this, a[Ob], a[Pb], a, b, c)) !== !1 && (Pv(this, a, b, c), a[bb]())
            }
        };
        Q.Ii = function (a) {
            var b = Mv(this, 0, 0);
            ya(a, this[Ob]);
            za(a, this[Pb]);
            Pv(this, a, b.x, b.y)
        };
        U(Kv, Ip);
        U(Qv, Hu);
        im(Qv);
        Q = Qv[F];
        Q.$d = P(Xg);
        Q.ae = function (a, b, c) {
            b == 16 ? Fu(a, nk, c) : Qv.g.ae[I](this, a, b, c)
        };
        Q.l = function (a) {
            var b = Qv.g.l[I](this, a),
                c = a.p;
            if (c && b) b.title = c || M;
            (c = a.Ma()) && this.Qc(b, c);
            a.Ea & 16 && this.ae(b, 16, !1);
            return b
        };
        Q.Ma = hm;
        Q.Qc = hm;
        Q.v = P(zi);
        U(Rv, Qv);
        im(Rv);
        Q = Rv[F];
        Q.$d = bm();
        Q.l = function (a) {
            Pu(a, !1);
            a.Dh &= -256;
            Wu(a, 32, !1);
            return a.C().l(Xg, {
                "class": this.Tb(a)[L](N),
                disabled: !a[qc](),
                title: a.p || M,
                value: a.Ma() || M
            }, a.Kc() || M)
        };
        Q.rd = function (a) {
            bu(a).w(a.h(), gh, a.zb)
        };
        Q.uh = hm;
        Q.Gh = hm;
        Q.wh = function (a) {
            return a[qc]()
        };
        Q.tb = hm;
        Q.bg = function (a, b, c) {
            Rv.g.bg[I](this, a, b, c);
            if ((a = a.h()) && b == 1) a.disabled = c
        };
        Q.Ma = function (a) {
            return a[ab]
        };
        Q.Qc = function (a, b) {
            if (a) a.value = b
        };
        Q.ae = hm;
        U(Sv, Nu);
        Q = Sv[F];
        Q.Ma = dm("T");
        Q.vb = function (a) {
            this.T = a;
            this.La().Qc(this.h(), a)
        };
        Q.n = function () {
            Sv.g.n[I](this);
            delete this.T;
            delete this.p
        };
        Q.S = function () {
            Sv.g.S[I](this);
            if (this.Ea & 32) {
                var a = this.h();
                a && bu(this).w(a, qj, this.Ae)
            }
        };
        Q.Ae = function (a) {
            return a[A] == 13 && a[C] == nj || a[A] == 32 && a[C] == qj ? this.zb(a) : a[A] == 32
        };
        Gu(zi, function () {
            return new Sv(j)
        });
        U(Tv, Qv);
        im(Tv);
        Q = Tv[F];
        Q.l = function (a) {
            var b = {
                "class": Gi + this.Tb(a)[L](N),
                title: a.p || M
            };
            return a.C().l(O, b, this.Qd(a.Oa, a.C()))
        };
        Q.$d = P(Xg);
        Q.ab = function (a) {
            return a && a[B][B]
        };
        Q.Qd = function (a, b) {
            return b.l(O, Gi + (this.v() + Yd), b.l(O, Gi + (this.v() + Sd), a))
        };
        Q.v = P(Di);
        U(Uv, Sv);
        Gu(Di, function () {
            return new Uv(j)
        });
        U(Vv, Fv);
        Q = Vv[F];
        Q.Ni = function (a) {
            this.Ec && a[bb]()
        };
        Q.Fh = function (a) {
            this.ac = a;
            this.F = !0
        };
        Q.cg = cm("jd");
        Q.l = function () {
            Vv.g.l[I](this);
            var a = this.C(),
                b = this.h(),
                c = this.La().v(),
                d = go(a.b, Ie),
                f = Tn(a.b, hl, j, d)[0],
                g = c + Td,
                h = c + Ud,
                k = go(a.b, He),
                o = Tn(a.b, xl, j, k)[0];
            this.c = a.l(O, g);
            X && a.Dg(this.c, {
                hideFocus: !0
            });
            this.z = ao(Tk, Ri);
            a.Aa(this.c, this.z);
            g = a.l(O, h);
            a.Aa(o[B], this.c);
            a.Aa(o[pc], g);
            a.Aa(f, k);
            k = c + Wd;
            this.jb = new Uv(ao(O, c + Zd + k));
            this.jb.vb(fk);
            this.rb = new Uv(ao(O, c + $d + k));
            this.rb.vb(gk);
            this.f = new pv(oi, av($u, c + Vd));
            this.f.l();
            this.f.Ib(this.rb, !0);
            this.rb.Ga(!1);
            this.f.Ib(this.jb, !0);
            this.f.tb(!1);
            this.Eg =
                a.l(O, c + Id);
            c = go(a.b, Ge);
            k = Tn(a.b, xl, j, c)[0];
            a.Aa(k[B], this.Eg);
            a.Aa(k[pc], this.f.h());
            a.Aa(f, c);
            a.Aa(b, d)
        };
        Q.S = function () {
            Vv.g.S[I](this);
            this.f.S();
            this.f.Ta(!1);
            this.f[Bb](rg, this.Pi, !1, this);
            this[Bb](mi, this.Oi, !1, this);
            this[Bb](Ih, this.Ni, !1, this);
            this.Ta(!1, !0);
            $o(this.c, !1, Z);
            rv(this, this.c);
            if ((this.uf = !0) && !this.p && this.h()) this.p = new Iv(this.h()), X && bu(this).w(this.h(), Ij, this.p.Gd, i, this.p);
            else if (!this.uf && this.p) X && bu(this).Ca(this.h(), Ij), this.p.s(), this.p = j;
            this.Ed = !1
        };
        Q.Pc = function () {
            return this.Eg || this.h()
        };
        Q.Qe = cm("d");
        Q.dg = function (a) {
            a = Vv.g.dg[I](this, a);
            this.tf && Cv(this, p.activeElement) && this.tf.sb();
            return a
        };
        Q.bd = function (a) {
            if (!this.d) return !1;
            if (this.d.Le(this, a)) return this.d.zf(this, a);
            if (Vm(this.d.c, a[A]) && this.Ya) {
                var b = a[A] == 8,
                    c = !1;
                if (b)!this.ia || this.ia[E] == 0 ? c = !1 : (c = Rm(this.ia), c.wf != this.O() || c.xf != this.Wa() ? (this.ia = [], c = !1) : (Xv(this, c, !0), c = !0));
                c || ((c = this.Ya[this.b]) ? (this.Da(this.b + Xv(this, c, b)), c = !0) : c = !1);
                if (c) return !0;
                else if (b) return aw(this, this.b - 1), !0
            }
            if (a[A] == 46) return this.b < this.c[D][E] - 1 && aw(this, this.b + 1), !0;
            if (Vm(this.d.f, a[A])) return this.Va(!1);
            if (Vm(this.d.d, a[A])) return this.Va(!0);
            var b = (c = a[vb] != 0) ? n[ub](a[vb]) : M,
                d = mu(this.d, this, a);
            if (c) {
                if (gu(this) > 0 && !/[^0-9]/ [Ma](b)) return Yv(this, Om(b) - 1);
                if (d) {
                    if (b == pd) {
                        a = this.Wa();
                        if (c = !xm(a == j ? M : n(a))) c = a[E] - 1, c = c >= 0 && a[x](pd, c) == c;
                        if (c) return !0
                    }
                    $v(this, b);
                    return !0
                }
            }
            if (this.Zb() < 0 && a[A] in this.xg) return Yv(this, this.xg[a[A]]);
            switch (a[A]) {
            case 37:
                return bw(this, this.b - 1), !0;
            case 39:
                return bw(this, this.b + 1), !0;
            case 36:
                return this.Da(Um(this.O()[ic](M), this.d.fd, this.d)), !0;
            case 35:
                return this.Da(!1), !0;
            case 33:
            case 188:
                return Zv(this, !1, !0), !0;
            case 34:
            case 190:
                return Zv(this, !0, !0), !0;
            case 9:
                return !0
            }
            return Vv.g.bd[I](this, a)
        };
        Q.kg = function (a) {
            return !!a[vb] && !mu(this.d, this, a)
        };
        Q.jc = function () {
            this.Zb() == gu(this) - 1 ? Zv(this, !0) : Vv.g.jc[I](this)
        };
        Q.kc = function () {
            this.Zb() == 0 ? Zv(this, !1) : Vv.g.kc[I](this)
        };
        Q.Nb = function () {
            return Ir(this.c, this.b, this.c, this.b)
        };
        Q.Da = function (a) {
            var b = this.c[D][E];
            bw(this, mm(a) ? a ? 0 : b - 1 : a)
        };
        Q.Wa = function () {
            var a = this.O();
            this.b > 0 && (a = a[J](0, this.b));
            return Um(a[ic](M), this.d.fd, this.d) > -1 ? a : this.O()
        };
        Q.O = function () {
            return so(this.c) || M
        };
        Q.Ia = function (a) {
            var b = this.c[D];
            if (b && b[E] > 0) {
                for (var c = b[E], d = 0; d < c; d++) this.c[oc](b[cb](0));
                this.c[Ja](this.z);
                this.b = 0
            }
            for (b = 0; b < a[E]; b++) $v(this, a[Ya](b));
            this.P && this.Da(!1)
        };
        Q.fh = function (a, b) {
            if (a != b) {
                var c = this.O(),
                    d = c[x](a),
                    f = d + a[E] > this.b;
                d >= 0 && (c = c[u](a, b), f = this.b + b[E] - (f ? 0 : a[E]), this.Ia(c), this.Te(), d = d + b[E], this.ia[s](this.Ya[d] = {
                    Ud: a,
                    Td: b,
                    wf: this.O(),
                    xf: this.Wa(),
                    index: d
                }), this.Da(f))
            }
        };
        Q.Va = function (a) {
            this.Rf = !0;
            this.Yb();
            this.Rf = !1;
            this.b = 0;
            oq(this, a ? bl : zh);
            return !0
        };
        Q.Bd = function () {
            return this.K && this.P
        };
        Q.Oi = dm("Rf");
        Q.Pi = function (a) {
            var b = !1;
            switch (a[H] && a[H].Ma()) {
            case fk:
                Zv(this, !0);
                b = !0;
                break;
            case gk:
                Zv(this, !1), b = !0
            }
            return b
        };
        Q.ig = function (a) {
            var b = this.ac[E];
            if (!(a < 0 || a >= b)) {
                this.T = a;
                a = this.T + this.jd;
                this.rb.Ga(this.T > 0);
                this.jb.Ga(a < b || this.F && a >= b);
                ku(this);
                for (a = 0; a < this.jd; a++) {
                    var c = this.T + a;
                    c < b && (c = this.ac[c], Hv(this, c.Ye(a), c))
                }
                Wv(this);
                this.f.Ta(!0)
            }
        };
        Q.If = function (a, b) {
            this.Kb();
            Hv(this, a, M, i, b).Ga(!1)
        };
        Q.Te = function () {
            iu(this, function (a) {
                a.Ga(!1)
            });
            this.ac = [];
            this.F = !1;
            this.rb.Ga(!1);
            this.jb.Ga(!1)
        };
        Q.Kb = function () {
            ku(this);
            this.f.Ta(!1)
        };
        Ga(Q, function () {
            this.Ia(M);
            this.Ya = [];
            rv(this, this.c);
            this.Kb()
        });
        Q.Rc = function (a) {
            this.P && !Cv(this, a[H]) && this.Va(!1)
        };
        Q.qh = function (a) {
            this.Rc(a)
        };
        U(cw, np);
        var TA = Zq();
        Q = cw[F];
        Q.Xa = function (a) {
            if (!this.b) this.b = new Vv(Pn(p[mc]), this.d), this.b.Ff = this.f, eu(this.b, i), this.b[Dc]();
            if (a && !a.c[TA]) a.c[TA] = this.b;
            return this.b
        };
        Q.Df = function (a, b, c) {
            a = this.Xa(a);
            a[Dc]();
            Ev(a, b);
            c && a.Ia(c)
        };
        Q.Lf = function (a, b, c, d) {
            var d = d || 0,
                f = this.Xa(a);
            f.Fh(b.gc);
            f.cg(c);
            f.ig(d);
            wv(f);
            a = this.Xa(a);
            b = Yo(a.h());
            c = Xn(l);
            c[t] - b[y] - b[t] < 0 && (c = c[t] - b[t], Ev(a, new hv(new Jn(c > 0 ? c : 0, b.top))))
        };
        Q.ag = function (a) {
            a.c[TA] = j
        };
        Q.n = function () {
            this.b && this.b.s();
            this.c.s();
            cw.g.n[I](this)
        };
        var gw = {};
        Q = ew[F];
        xa(Q, function () {
            this.b = {}
        });
        Q.W = function () {
            var a = new ew,
                b;
            for (b in this.b) this.b[lc](b) && (a.b[b] = j);
            return a
        };
        Fa(Q, function (a) {
            return this.b[lc](fw(a))
        });
        Q.forEach = function (a, b) {
            for (var c in this.b) this.b[lc](c) && a[I](b, c[wc](0) == 32 ? c[Rb](1) : c, i, this)
        };
        Q.yb = function () {
            var a = [],
                b;
            for (b in this.b) this.b[lc](b) && a[s](b[wc](0) == 32 ? b[Rb](1) : b);
            return a
        };
        Q.Sa = function () {
            for (var a in this.b)
                if (this.b[lc](a)) return !1;
            return !0
        };
        ra(Q, function (a) {
            a = fw(a);
            return this.b[lc](a) ? (delete this.b[a], !0) : !1
        });
        Q.wc = function () {
            return hn(this.yb())
        };
        Q = hw[F];
        Q.Se = function (a) {
            if (this.q(a) != this.Lb) this.b = a
        };
        Q.Vf = function (a) {
            if (a && a[E] > 0) this.gc = a
        };
        Q.Re = function () {
            return this.gc[E]
        };
        Q.q = function (a) {
            return S(a) ? a : a.q()
        };
        Q.Ye = function (a, b) {
            return S(a) ? a : a.Ye(b)
        };
        U(jw, hw);
        jw[F].Se = function (a) {
            lw(this, this.b, -1, 0);
            jw.g.Se[I](this, a);
            lw(this, this.b, 0, 1)
        };
        jw[F].Re = function () {
            return Sm(this.c, function (a, b) {
                return r.max(a, b.Re())
            }, jw.g.Re[I](this))
        };
        jw[F].Vf = function (a) {
            jw.g.Vf[I](this, a);
            a && a[E] > 0 && jw.g.Se[I](this, a[0])
        };
        nw[F].get = function (a, b) {
            var c = this.b[a[Wb]()],
                d = S(b) ? b : n[ub](b[vb]);
            return c && (c = c(d)) && c != d ? new jw(d, [c]) : j
        };
        var pw = {
            ".": "\u1362",
            ",": "\u1363"
        }, rw = {
                ",": "\u060c",
                ";": "\u061b",
                "?": "\u061f"
            }, vw = {
                ".": "\u3002",
                "~": "\uff5e",
                "!": "\uff01",
                $: "\uffe5",
                "*": "\u00d7",
                "(": "\uff08",
                "<": "\u300a",
                ">": "\u300b",
                ",": "\uff0c",
                "?": "\uff1f",
                ":": "\uff1a",
                ";": "\uff1b",
                "[": "\u3010",
                "]": "\u3011",
                "\\": "\u3001",
                ")": "\uff09",
                "{": "\u300e",
                "}": "\u300f",
                "`": "\u00b7",
                "^": "\u2026\u2026",
                _: "\u2014\u2014",
                "@": "\uff20",
                "#": "\uff03",
                "-": "\uff0d",
                "=": "\uff1d",
                "+": "\uff0b",
                "|": "\uff5c",
                "%": "\uff05",
                "&": "\uff06",
                "/": "\uff0f",
                "`": "\uff40"
            }, ww = {
                "'": ["\u2018\u2019"],
                '"': ["\u201c\u201d"]
            }, yw = {
                va: "\u3094\u3041",
                vi: "\u3094\u3043",
                vu: "\u3094",
                ve: "\u3094\u3047",
                vo: "\u3094\u3049",
                vya: "\u3094\u3083",
                vyi: "\u3094\u3043",
                vyu: "\u3094\u3085",
                vye: "\u3094\u3047",
                vyo: "\u3094\u3087",
                qq: "\u3063q",
                vv: "\u3063v",
                ll: "\u3063l",
                xx: "\u3063x",
                kk: "\u3063k",
                gg: "\u3063g",
                ss: "\u3063s",
                zz: "\u3063z",
                jj: "\u3063j",
                tt: "\u3063t",
                dd: "\u3063d",
                hh: "\u3063h",
                ff: "\u3063f",
                bb: "\u3063b",
                pp: "\u3063p",
                mm: "\u3063m",
                yy: "\u3063y",
                rr: "\u3063r",
                wwa: "\u3063\u308f",
                wwi: "\u3063\u3046\u3043",
                wwu: "\u3063\u3046",
                wwe: "\u3063\u3046\u3047",
                wwo: "\u3063\u3092",
                wwyi: "\u3063\u3090",
                wwye: "\u3063\u3091",
                wwha: "\u3063\u3046\u3041",
                wwhi: "\u3063\u3046\u3043",
                wwhu: "\u3063\u3046",
                wwhe: "\u3063\u3046\u3047",
                wwho: "\u3063\u3046\u3049",
                cc: "\u3063c",
                kya: "\u304d\u3083",
                kyi: "\u304d\u3043",
                kyu: "\u304d\u3085",
                kye: "\u304d\u3047",
                kyo: "\u304d\u3087",
                gya: "\u304e\u3083",
                gyi: "\u304e\u3043",
                gyu: "\u304e\u3085",
                gye: "\u304e\u3047",
                gyo: "\u304e\u3087",
                sya: "\u3057\u3083",
                syi: "\u3057\u3043",
                syu: "\u3057\u3085",
                sye: "\u3057\u3047",
                syo: "\u3057\u3087",
                sha: "\u3057\u3083",
                shi: "\u3057",
                shu: "\u3057\u3085",
                she: "\u3057\u3047",
                sho: "\u3057\u3087",
                zya: "\u3058\u3083",
                zyi: "\u3058\u3043",
                zyu: "\u3058\u3085",
                zye: "\u3058\u3047",
                zyo: "\u3058\u3087",
                tya: "\u3061\u3083",
                tyi: "\u3061\u3043",
                tyu: "\u3061\u3085",
                tye: "\u3061\u3047",
                tyo: "\u3061\u3087",
                cha: "\u3061\u3083",
                chi: "\u3061",
                chu: "\u3061\u3085",
                che: "\u3061\u3047",
                cho: "\u3061\u3087",
                cya: "\u3061\u3083",
                cyi: "\u3061\u3043",
                cyu: "\u3061\u3085",
                cye: "\u3061\u3047",
                cyo: "\u3061\u3087",
                dya: "\u3062\u3083",
                dyi: "\u3062\u3043",
                dyu: "\u3062\u3085",
                dye: "\u3062\u3047",
                dyo: "\u3062\u3087",
                tsa: "\u3064\u3041",
                tsi: "\u3064\u3043",
                tse: "\u3064\u3047",
                tso: "\u3064\u3049",
                tha: "\u3066\u3083",
                thi: "\u3066\u3043",
                "t'i": "\u3066\u3043",
                thu: "\u3066\u3085",
                the: "\u3066\u3047",
                tho: "\u3066\u3087",
                "t'yu": "\u3066\u3085",
                dha: "\u3067\u3083",
                dhi: "\u3067\u3043",
                "d'i": "\u3067\u3043",
                dhu: "\u3067\u3085",
                dhe: "\u3067\u3047",
                dho: "\u3067\u3087",
                "d'yu": "\u3067\u3085",
                twa: "\u3068\u3041",
                twi: "\u3068\u3043",
                twu: "\u3068\u3045",
                twe: "\u3068\u3047",
                two: "\u3068\u3049",
                "t'u": "\u3068\u3045",
                dwa: "\u3069\u3041",
                dwi: "\u3069\u3043",
                dwu: "\u3069\u3045",
                dwe: "\u3069\u3047",
                dwo: "\u3069\u3049",
                "d'u": "\u3069\u3045",
                nya: "\u306b\u3083",
                nyi: "\u306b\u3043",
                nyu: "\u306b\u3085",
                nye: "\u306b\u3047",
                nyo: "\u306b\u3087",
                hya: "\u3072\u3083",
                hyi: "\u3072\u3043",
                hyu: "\u3072\u3085",
                hye: "\u3072\u3047",
                hyo: "\u3072\u3087",
                bya: "\u3073\u3083",
                byi: "\u3073\u3043",
                byu: "\u3073\u3085",
                bye: "\u3073\u3047",
                byo: "\u3073\u3087",
                pya: "\u3074\u3083",
                pyi: "\u3074\u3043",
                pyu: "\u3074\u3085",
                pye: "\u3074\u3047",
                pyo: "\u3074\u3087",
                fa: "\u3075\u3041",
                fi: "\u3075\u3043",
                fu: "\u3075",
                fe: "\u3075\u3047",
                fo: "\u3075\u3049",
                fya: "\u3075\u3083",
                fyu: "\u3075\u3085",
                fyo: "\u3075\u3087",
                hwa: "\u3075\u3041",
                hwi: "\u3075\u3043",
                hwe: "\u3075\u3047",
                hwo: "\u3075\u3049",
                hwyu: "\u3075\u3085",
                mya: "\u307f\u3083",
                myi: "\u307f\u3043",
                myu: "\u307f\u3085",
                mye: "\u307f\u3047",
                myo: "\u307f\u3087",
                rya: "\u308a\u3083",
                ryi: "\u308a\u3043",
                ryu: "\u308a\u3085",
                rye: "\u308a\u3047",
                ryo: "\u308a\u3087",
                "n'": "\u3093",
                nn: "\u3093",
                xn: "\u3093",
                a: "\u3042",
                i: "\u3044",
                u: "\u3046",
                wu: "\u3046",
                e: "\u3048",
                o: "\u304a",
                xa: "\u3041",
                xi: "\u3043",
                xu: "\u3045",
                xe: "\u3047",
                xo: "\u3049",
                la: "\u3041",
                li: "\u3043",
                lu: "\u3045",
                le: "\u3047",
                lo: "\u3049",
                lyi: "\u3043",
                xyi: "\u3043",
                lye: "\u3047",
                xye: "\u3047",
                ye: "\u3044\u3047",
                ka: "\u304b",
                ki: "\u304d",
                ku: "\u304f",
                ke: "\u3051",
                ko: "\u3053",
                xka: "\u30f5",
                xke: "\u30f6",
                lka: "\u30f5",
                lke: "\u30f6",
                ga: "\u304c",
                gi: "\u304e",
                gu: "\u3050",
                ge: "\u3052",
                go: "\u3054",
                sa: "\u3055",
                si: "\u3057",
                su: "\u3059",
                se: "\u305b",
                so: "\u305d",
                ca: "\u304b",
                ci: "\u3057",
                cu: "\u304f",
                ce: "\u305b",
                co: "\u3053",
                qa: "\u304f\u3041",
                qi: "\u304f\u3043",
                qu: "\u304f",
                qe: "\u304f\u3047",
                qo: "\u304f\u3049",
                kwa: "\u304f\u3041",
                kwi: "\u304f\u3043",
                kwe: "\u304f\u3047",
                kwo: "\u304f\u3049",
                gwa: "\u3050\u3041",
                za: "\u3056",
                zi: "\u3058",
                zu: "\u305a",
                ze: "\u305c",
                zo: "\u305e",
                ja: "\u3058\u3083",
                ji: "\u3058",
                ju: "\u3058\u3085",
                je: "\u3058\u3047",
                jo: "\u3058\u3087",
                jya: "\u3058\u3083",
                jyi: "\u3058\u3043",
                jyu: "\u3058\u3085",
                jye: "\u3058\u3047",
                jyo: "\u3058\u3087",
                ta: "\u305f",
                ti: "\u3061",
                tu: "\u3064",
                tsu: "\u3064",
                te: "\u3066",
                to: "\u3068",
                da: "\u3060",
                di: "\u3062",
                du: "\u3065",
                de: "\u3067",
                "do": "\u3069",
                xtu: "\u3063",
                xtsu: "\u3063",
                ltu: "\u3063",
                ltsu: "\u3063",
                na: "\u306a",
                ni: "\u306b",
                nu: "\u306c",
                ne: "\u306d",
                no: "\u306e",
                ha: "\u306f",
                hi: "\u3072",
                hu: "\u3075",
                fu: "\u3075",
                he: "\u3078",
                ho: "\u307b",
                ba: "\u3070",
                bi: "\u3073",
                bu: "\u3076",
                be: "\u3079",
                bo: "\u307c",
                pa: "\u3071",
                pi: "\u3074",
                pu: "\u3077",
                pe: "\u307a",
                po: "\u307d",
                ma: "\u307e",
                mi: "\u307f",
                mu: "\u3080",
                me: "\u3081",
                mo: "\u3082",
                xya: "\u3083",
                lya: "\u3083",
                ya: "\u3084",
                wyi: "\u3090",
                xyu: "\u3085",
                lyu: "\u3085",
                yu: "\u3086",
                wye: "\u3091",
                xyo: "\u3087",
                lyo: "\u3087",
                yo: "\u3088",
                ra: "\u3089",
                ri: "\u308a",
                ru: "\u308b",
                re: "\u308c",
                ro: "\u308d",
                xwa: "\u308e",
                lwa: "\u308e",
                wa: "\u308f",
                wi: "\u3046\u3043",
                we: "\u3046\u3047",
                wo: "\u3092",
                wha: "\u3046\u3041",
                whi: "\u3046\u3043",
                whu: "\u3046",
                whe: "\u3046\u3047",
                who: "\u3046\u3049",
                "z/": "\u30fb",
                "z.": "\u2026",
                "z,": "\u2025",
                zh: "\u2190",
                zj: "\u2193",
                zk: "\u2191",
                zl: "\u2192",
                "z-": "\u301c",
                "z[": "\u300e",
                "z]": "\u300f",
                0: "\uff10",
                1: "\uff11",
                2: "\uff12",
                3: "\uff13",
                4: "\uff14",
                5: "\uff15",
                6: "\uff16",
                7: "\uff17",
                8: "\uff18",
                9: "\uff19",
                "'": "\u2019",
                '"': "\u201d",
                ",": "\u3001",
                ".": "\u3002",
                "[": "\u300c",
                "]": "\u300d",
                "~": "\u301c",
                "/": "\u30fb",
                "-": "\u30fc",
                "!": "\uff01",
                "#": "\uff03",
                $: "\uff04",
                "%": "\uff05",
                "&": "\uff06",
                "(": "\uff08",
                ")": "\uff09",
                "*": "\uff0a",
                "+": "\uff0b",
                ":": "\uff1a",
                ";": "\uff1b",
                "<": "\uff1c",
                "=": "\uff1d",
                ">": "\uff1e",
                "?": "\uff1f",
                "@": "\uff20",
                "^": "\uff3e",
                _: "\uff3f",
                "`": "\uff40",
                "{": "\uff5b",
                "|": "\uff5c",
                "}": "\uff5d",
                "\\": "\uffe5",
                "\u00a5": "\uffe5"
            }, UA = new ew,
            VA;
        for (VA in yw)
            for (var WA = 0, XA = VA[E]; WA < XA; ++WA) UA.b[fw(VA[Ya](WA))] = j;
        Aw[F].q = function () {
            return this[Qa][0]
        };
        U(Bw, Aw);
        var YA = "jsapi";
        Bw[F].q = function () {
            return this.c ? this.j ? this[Qa][L](M) : this[Qa][L](vd) + vd : Bw.g.q[I](this)
        };
        U(Jw, Bu);
        var ZA = Zq();
        Zq();
        Q = Jw[F];
        Q.Ob = P("t13nzh");
        Q.oc = function () {
            return [oj, pj, qj, Gj]
        };
        Q.Fe = function (a) {
            return a.B == Ul
        };
        Q.Za = function (a) {
            if (!this.T) Kw(this), this.T = !0;
            Jw.g.Za[I](this, a);
            var b = this.c.Xa(a);
            Gv(b, T(function (b) {
                var c = this.ea(a);
                return b[A] == 32 || this.Zc.get(c, b)
            }, this));
            if (!a.z) {
                var c = yo(a.C());
                if (c != p) {
                    var d = qm(a);
                    this.F[d] || (Vp(c, Gj, b.qh, !0, b), Y && Vp(c, jh, b.qh, !0, b), this.F[d] = a)
                }
            }
        };
        Q.Ab = function (a) {
            Jw.g.Ab[I](this, a);
            if (this.cd(a)) {
                this.c.ag(a);
                var b = a.c[ZA];
                b && b.s();
                a.c[ZA] = j
            }
        };
        Q.lh = function (a, b) {
            this.f[Vb]();
            var c = this.oa.c[ZA];
            if (c) {
                var d = b[C] == bl ? a.O() : M;
                d ? (c.s(), c = this.oa.Wb(), Gp(c), c[u](d), br(this.oa), c.Hb(!0)) : Hp(c);
                c.s();
                this.oa.c[ZA] = j
            }
        };
        va(Q, function (a, b) {
            this.oa = a;
            var c = this.c.Xa(a);
            c.tf = a;
            if (!Du(this, a, b)) return !1;
            if (!this.N(this.oa) || St(b)) return !1;
            if (b[C] == Gj) return X && a.sb(), c.Va(!1), !1;
            if (b[C] == oj || b[C] == pj || b[C] == qj) {
                var d = qm(a);
                this.j[d] || (this.j[d] = {
                    keyCode: -1,
                    lastKey: -1
                });
                var f;
                if (a.F && b[A] == 13) b[C] == oj && (f = new Rt(13, 0, !1, b));
                else a: {
                    f = this.j[d];
                    switch (b[C]) {
                    case oj:
                        if (Y && (f.lastKey == 17 && !b[hc] || f.lastKey == 18 && !b[Xb])) f.lastKey = -1, sa(f, -1);
                        LA && !Hq(b[A], f.lastKey, b[Bc], b[hc], b[Xb]) ? f = Tt(b, f) : (sa(f, Z && b[A] in KA ? KA[b[A]] :
                            b[A]), f = j);
                        break a;
                    case qj:
                        f.lastKey = -1;
                        sa(f, -1);
                        break;
                    case pj:
                        f = Tt(b, f);
                        break a
                    }
                    f = j
                }
                if (f) {
                    if (c.Bd()) return c = c.Ne(f), f.s(), c;
                    c = a.Wb();
                    if (!c) return !1;
                    var d = n[ub](f[vb]),
                        g;
                    a: {
                        var h = n[ub](f[vb]);
                        if ((g = this.oa.Wb()) && g.Sa())
                            if (h = this.Zc.get(this.ea(this.oa), h)) {
                                var h = h.b,
                                    k = this.oa.Cd();
                                if (g && k) {
                                    Gp(g);
                                    g[u](h);
                                    g.Hb(!0);
                                    g.s();
                                    g = !0;
                                    break a
                                }
                            }
                        g = !1
                    }
                    if (g) return !0;
                    if (/[^a-zA-Z]/ [Ma](d)) return !1;
                    a.c[ZA] = c;
                    Bq(a, this.b).yd = M;
                    Gp(c);
                    c.f = c.H.qb();
                    this.c.Df(a, c.Me(), d);
                    this.f[sc]();
                    f.s();
                    return !0
                }
            }
            return !1
        });
        Q.Yi = function (a, b, c, d, f) {
            if (a.Bd()) {
                var c = b.q(),
                    g = a.Wa();
                Lw(g) || (g = a.O());
                if (c == g[Lc]() && (a.Kb(), d && f && d && f)) a = b.b || 0, b = Bq(this.oa, this.b), b.Hg = c, b.ui = a, this.c.Lf(this.oa, f, this.d.Jf, a - 1)
            }
        };
        Q.oh = function (a, b) {
            var c = b[H].Ma(),
                d = c.q(),
                f = a.Wa(),
                g = Bq(this.oa, this.b).Hg;
            if (f[Lc]() == g) {
                var c = Lw(f)[J](0, c.c),
                    g = (g = b.eh ? this.Zc.get(this.ea(this.oa), b.eh) : j) ? g.b : M,
                    h = a.O();
                if (h == f) {
                    if (h = h[u](c, d), !Lw(h)) return a.Ia(h + g), a.Va(!0), !0
                } else if (g) return !1;
                a.fh(c, d)
            }
            return !0
        };
        Q.mh = function (a) {
            return Mw(this, a[H], a[Qa], a.c + 1)
        };
        Q.nh = function (a) {
            this.f[Vb]();
            if (a.Bd()) {
                var b = a.O();
                if (b) {
                    var c = Bq(this.oa, this.b);
                    if (b[E] > this.d.Bf) a.If(sf, {
                        background: Xc
                    }), c.yd = b;
                    else {
                        var d = a.Wa(),
                            c = c.yd || M;
                        Lw(d) || (d = b);
                        d = d[Lc]();
                        d != c && (a.Te(), Mw(this, a, d, 1) || a.Kb())
                    }
                    this.f[sc]()
                } else a.Va(!1)
            }
        };
        Q.n = function () {
            var a = this.c.Xa(j);
            a[fc](rg, T(this.oh, this, a));
            var b = T(this.lh, this, a);
            a[fc](bl, b);
            a[fc](zh, b);
            b = T(this.mh, this);
            a[fc](Mh, b);
            this.f[fc](sl, T(this.nh, this, a));
            this.f.s();
            this.M.s();
            Jw.g.n[I](this)
        };
        Q = Pw[F];
        Q.Bb = 0;
        Q.Qb = 0;
        Q.Sa = function () {
            return this.Qb - this.Bb == 0
        };
        xa(Q, function () {
            Ba(this.b, 0);
            this.Qb = this.Bb = 0
        });
        Fa(Q, function (a) {
            return Vm(this.b, a)
        });
        ra(Q, function (a) {
            a = Wm(this.b, a);
            if (a < 0) return !1;
            a == this.Bb ? Qw(this) : (Ym[Ic][I](this.b, a, 1), this.Qb--);
            return !0
        });
        Q.yb = function () {
            return this.b[Sa](this.Bb, this.Qb)
        };
        U(Tw, np);
        Q = Tw[F];
        Q.Bh = hm;
        Q.Mi = function (a, b, c) {
            this.c = j;
            this.Bh(a, b, c);
            Ww(this)
        };
        Q.dh = hm;
        Q.bh = hm;
        Q.Ad = function (a, b) {
            var c = Vw(this, a);
            if (c) return b(a, !0, !0, c), !0;
            c = Rw(this.b);
            if (!c || !Gw(c.ub, a)) {
                var c = this.b,
                    d = new Sw(a, b);
                c.b[c.Qb++] = d
            }
            Ww(this);
            return !1
        };
        U(Xw, Tw);
        Q = Xw[F];
        Q.Ac = j;
        Q.Bh = function (a, b, c) {
            function d(a, b) {
                var c = Im(a[Na]()),
                    d = !g.c && Zw(f, c, q) || new Bw(c, q);
                if (a[E]) {
                    var k = a[Na]();
                    if (!c || !k || !k[E]) qa(d, Kh), b(d, j);
                    else {
                        var w = f.T,
                            z = [];
                        V(k, function (b, d) {
                            b && z[s](w(b, c, a, d))
                        });
                        k = new jw(c, z);
                        g.c || (Uw(f.f, h)[c] = k, Uw(f.M, h)[k.b] = c);
                        o || (f.j[c] = !0);
                        qa(d, Bk);
                        b(d, k)
                    }
                } else qa(d, Kh), b(d, j)
            }
            Yw(this, zk, lg);
            if (this.Ac) this.Ac.name = rl + Iw(a.ub)[u](/-/g, hg), l[jb].report(this.Ac);
            var f = this,
                g = a.ub,
                h = [Fw(g)[Wb]()],
                k = a.b,
                a = a[Qa],
                o = g.f,
                q = Fw(g),
                b = c[0] == Pf,
                c = c[1];
            if (!b || !c)
                if (g.c) c = Zw(this, g) ||
                    g, qa(c, Kh), k(c, !1, !1, j);
                else
                    for (b = 0; a && b < a[E]; ++b) c = Zw(this, a[b], q) || new Bw(a[b], q), qa(c, Kh), k(c, !1, !1, j);
                else if (g.c) {
                var a = Xr(c, function (a) {
                    return Im(a[0])
                }),
                    w = !0,
                    z = new jw(g.q(), []);
                V(c, function (a) {
                    a && a[E] && d(a, function (a, b) {
                        a[sb] == Bk && b ? z.c[s](b) : w = !1
                    })
                });
                b = Uw(f.f, h);
                b[g.q()] = z;
                c = Zw(f, g) || g;
                qa(c, w ? Bk : Kh);
                a = Dw(a, Fw(g), g.b || 0, !1);
                c[sb] == Bk && !c.Xb && c.q() != a.q() && (b = Uw(f.f, h), b[a.q()] = z, Ew(a, c.d || 0), qa(a, c[sb]), $w(this, a));
                k(c, !1, w, w ? z : j)
            } else V(c, function (a) {
                a && a[E] && d(a, function (a, b) {
                    k(a, !1, a[sb] ==
                        Bk && !! b, b)
                })
            })
        };
        Q.Ad = function (a, b) {
            var c = Zw(this, a),
                d = c ? c.d || 0 : 0,
                f = Vw(this, a),
                g = f ? f.Re() : 0,
                h, k = this.p.zc;
            if (f && (a.b || 0) <= g) b(a, !0, !0, f), h = !0;
            else if (!a.Xb && (!c || !(c[sb] == Bk || c[sb] == Kh)) || d < k && g == d) {
                if (this.d) c = this.b, d = new Sw(a, b), c.b[c.Qb++] = d;
                else if (c = Rw(this.b), !c || !Gw(c.ub, a)) c = this.b, d = new Sw(a, b), c.b[c.Qb++] = d;
                h = !1
            }
            Ww(this);
            return h
        };
        Q.dh = function (a, b) {
            var c = this.p,
                d = a.ub,
                f = c.ad;
            if (this.d) {
                var g = Zw(this, d),
                    g = g ? g.d || 0 : 0;
                g > 0 && (f = g + c.Dd)
            }
            Ew(d, r.min(r.max(f, d.b || 0), c.zc));
            d.Xb || $w(this, d);
            f = {
                uv: ax(this, Fw(d))
            };
            g = d.B == mj || d.B == lj ? Wl : M;
            g = {
                text: d.c ? d.q() + g : d[Qa][L](vd),
                ime: Iw(d),
                num: d.d,
                cp: le,
                cs: le,
                ie: Hl,
                oe: Hl,
                app: YA
            };
            if (c.Af) g.sct = c.Af;
            qn(g, f);
            f = new Lt(g);
            c = this.F;
            g = f.b;
            f = f.c;
            c.b && Nt(c, c.b);
            var g = c.p + g,
                h = g + ad + c.f;
            if (h != c.c) c.d = new Ht(g, c.f), c.c = h;
            if (f) {
                g = un(f);
                typeof g == "undefined" && e(m("Keys are undefined"));
                h = tn(f);
                g[E] != h[E] && e(m("Mismatched lengths for keys/values"));
                for (var k = new vt(j, i, i), o = 0; o < g[E]; o++) Gt(k, g[o], h[o])
            }
            var k = T(b, i),
                q;
            g = c.d;
            h = T(c.j, c, k, !0);
            k = T(c.j, c, k, !1);
            f = f || j;
            if (p[Qb][B]) {
                o = hg + (FA++)[Wb](36) + Lq()[Wb](36);
                R._callbacks_ || (R._callbacks_ = {});
                var w = p[xb](Dk),
                    z = j;
                g.Fd > 0 && (z = R[dc](It(o, w, f, k), g.Fd));
                k = g.c.W();
                if (f)
                    for (q in f)(!f[lc] || f[lc](q)) && At(k, q, f[q]);
                h && (R._callbacks_[o] = Kt(o, w, h, z), At(k, g.b, jg + o));
                Vn(w, {
                    type: kl,
                    id: o,
                    charset: Zf,
                    src: k[Wb]()
                });
                p.getElementsByTagName(hi)[0][Ja](w);
                q = {
                    Na: o,
                    Fd: z
                }
            } else k && k(f), q = j;
            c.b = {
                Th: q,
                key: c.c
            };
            a.id = c.b;
            qa(d,
                bk);
            Yw(this, lg)
        };
        Q.bh = function (a) {
            var b = a.ub,
                c = 0,
                d = Zw(this, b);
            d && (c = (d.d || 0) - this.p.Dd, Ew(d, c), c <= 0 && (Uw(this.z, [Fw(d)[Wb]()])[d.q()] = j));
            Nt(this.F, a.id);
            qa(b, pg)
        };
        U(bx, Bu);
        Q = bx[F];
        Q.Ob = P("t13nsuggestion");
        Q.oc = function () {
            return [gh, oj, pj]
        };
        Q.Fe = function (a) {
            return a.B != Ul
        };
        Q.Si = function (a, b, c, d, f) {
            c.q();
            if (!d || !f) Hp(b);
            else {
                var d = this.c,
                    g = f,
                    h = Vw(d, c),
                    k = h.Lb;
                d.j[k] = !0;
                g != k && (h.Se(g), Uw(d.M, [Fw(c)[Wb]()])[g] = k);
                Au(this.zd, Fw(c), f) && (f += N);
                b[u](f);
                b.Hb(!0)
            }
            b.s();
            a.sb()
        };
        Q.$i = function (a, b, c, d, f, g, h, k) {
            if (h && k && f.q() == c.q()) {
                c.f = b.qb();
                d && c[u](k.Lb);
                b = T(this.Si, this, a, c, f);
                d = Gs(Fw(f).B);
                f = {};
                f.direction = Is(d) ? yk : zj;
                if ((d = d.b.f) && d.lineHeight) f[vj] = d.lineHeight;
                d && d.fontSize && (f[Ph] = d.fontSize + pk);
                Tx(this.f, a, c.Me(i, !0), k, b, f)
            }
        };
        va(Q, function (a, b) {
            if (!Du(this, a, b)) return !1;
            var c;
            if (!(c = St(b))) b[C] == gh ? c = 0 : (c = b[A] == 8, c = b[C] == (Z ? pj : oj) && c ? 0 : !a.Cd() || 1);
            if (c) return !1;
            c = b[A] == 8;
            var d = a.Wb();
            if (!d || !d.xc() || !d.Sa()) return !1;
            var f = d.H.qb(),
                g = rp(f, f.m),
                h = rp(f, f.m - 1),
                k = this.ea(a);
            if (c) {
                if (Hs($[k.B], g)) return !1
            } else if (!Hs($[k.B], h) || !Hs($[k.B], g)) return !1;
            yu(this.zd, d, Ks(k.B, k.X), !c);
            if (d.Sa()) return !1;
            Gp(d);
            g = d.q();
            a: if (h = $[k.X], g) {
                for (var o = 0, q = g[E]; o < q; o++)
                    if (!h.isChar(g[Ya](o))) {
                        h = !1;
                        break a
                    }
                h = !0
            } else h = !1; if (h) return !1;
            k = new Bw(g,
                k, !0);
            return mm(this.c.Ad(k, T(this.$i, this, a, f, d, c)))
        });
        U(cx, Bu);
        Q = cx[F];
        Q.Ob = P("t13ntransform");
        Q.oc = function () {
            return [oj, pj, Gj]
        };
        Q.Fe = function (a) {
            return a.B != Ul && a.B != lj
        };
        Q.aj = function (a, b, c, d) {
            var f = a.q(),
                g = Fw(a);
            this.c[f] && (V(this.c[f], function (a) {
                if (c && a) {
                    var f = rp(a.H, a.H.m - 1),
                        o = rp(a.V, a.V.m),
                        q = this.zd;
                    if (b || !Au(q, g, f) && !Au(q, g, o)) a[u](kw(d)), b && (this.oa instanceof As ? a.Hb(!0) : br(this.oa))
                }
                a.s()
            }, this), delete this.c[f])
        };
        va(Q, function (a, b) {
            if (!Du(this, a, b)) return !1;
            this.oa = a;
            if (b[C] == Gj) return X && a.sb(), !1;
            if (dx(a, b)) return !1;
            var c = this.ea(a);
            if (zu(this.zd, c, n[ub](b[A] || b[vb]))) {
                var c = a.Wb(),
                    d;
                if (d = !! c) a: {
                    if (c.xc()) {
                        d = this.ea(a);
                        yu(this.zd, c, d);
                        d = n[ub](b[A] || b[vb]);
                        if (c.Sa()) d = !1;
                        else {
                            var f = c.q();
                            (d = this.Zc.get(this.ea(a), f + d)) ? (Gp(c), c[u](d.b), c.Hb(!0), c.s(), d = !0) : d = !1
                        } if (d) {
                            d = !0;
                            break a
                        }
                        c.xc() && !c.Sa() && (f = this.ea(a), Gp(c), d = c.q(), f = new Bw(d, f), this.c[d] || (this.c[d] = []), this.c[d][s](c), this.j.Ad(f, this.f) === !1 &&
                            c.Kf())
                    }
                    d = n[ub](b[A] || b[vb]);
                    c = a.Wb();
                    !c || !c.Sa() ? d = !1 : (d = this.Zc.get(this.ea(a), d)) ? (Gp(c), c[u](d.b), c.Hb(!0), c.s(), d = !0) : d = !1
                }
                return d
            }
            return !1
        });
        U(ex, Bu);
        var cz = {
            Kd: cl,
            Xf: "t13n.maybeChangeDirection"
        };
        Q = ex[F];
        Q.Ob = P("t13n");
        Q.oc = function () {
            var a = [];
            V(this.c, function (b) {
                an(a, b.oc())
            });
            dn(a);
            return a
        };
        Q.Za = function (a) {
            a.T == Xh ? ex.g.Za[I](this, a) : tu(this, a);
            Nw(this.c, NA[3], a)
        };
        Q.Ab = function (a) {
            a.T == Xh && ex.g.Ab[I](this, a);
            Nw(this.c, NA[4], a)
        };
        Q.gf = function (a) {
            ex.g.gf[I](this, a);
            Nw(this.c, NA[0], a)
        };
        Q.cf = function (a) {
            ex.g.cf[I](this, a);
            Nw(this.c, NA[1], a)
        };
        va(Q, function (a, b) {
            return a.T != Xh ? !1 : !this[qc](a) ? !1 : Ow(this.c, NA[9], a, b)
        });
        U(hx, fx);
        U(jx, Fv);
        Q = jx[F];
        Q.l = function () {
            jx.g.l[I](this);
            var a = this.C(),
                b = this.h(),
                c = this.La().v(),
                d = go(a.b, Ie),
                f = Tn(a.b, hl, j, d)[0];
            this.c = a.l(O, c + Td);
            X && a.Dg(this.c, {
                hideFocus: !0
            });
            this.c.contentEditable = !0;
            a.Aa(f, this.c);
            this.rb = a.l(O, c + Id);
            a.Aa(f, this.rb);
            var g = ao(O, c + Md);
            a.Aa(g, a.l(O, c + Ud));
            this.jb = a.l(O, c + Rd);
            a.Aa(g, this.jb);
            a.Aa(g, a.l(O, c + Nd));
            a.Aa(f, g);
            a.Aa(b, d)
        };
        Q.S = function () {
            this.tb(!0);
            jx.g.S[I](this);
            this[Bb](mi, this.cj, !1, this);
            this[Bb](Ih, this.bj, !1, this);
            this[Bb](rg, this.ej, !1, this);
            bu(this).w(this.c, oj, this.dj, !0, this);
            bu(this).w(this.c, [Gj, Kj, rh, mh, ek, jh], ux);
            rv(this, this.c);
            this.Ta(!1, !0);
            $o(this.c, !1, Z)
        };
        Q.Pc = function () {
            return this.rb || jx.g.Pc[I](this)
        };
        Q.jc = function () {
            var a = this.Zb();
            a < 0 || a >= gu(this) - 1 ? px(this, 1) : (jx.g.jc[I](this), la(this.b[this.R], this.F + this.Zb()), ox(this))
        };
        Q.kc = function () {
            this.Zb() <= 0 ? px(this, -1) : (jx.g.kc[I](this), la(this.b[this.R], this.F + this.Zb()), ox(this))
        };
        Q.bd = function (a) {
            if (!this.d) return !1;
            var b;
            if (b = mx(this)) a: if (this.d.Le(this, a)) {
                if (this.d.zf(this, a)) {
                    if (this.b[E] == 0) this.b = [new yx(this.O())], this.R = 0;
                    this.ia = lh;
                    Ax(this)
                }
                b = !0
            } else {
                if (Vm(this.d.c, a[A])) {
                    b = a[A] == 8;
                    var c;
                    if (c = b)
                        if (c = this.Nb().D(), !this.z || this.z[E] == 0) c = !1;
                        else {
                            var d = Rm(this.z);
                            d.wf != this.O() || d.xf != this.Wa() ? (this.z = [], c = !1) : (this.Da(c + vx(this, d, !0)), c = !0)
                        }
                    c || (c = this.Nb().D(), (d = this.T[c]) ? (this.Da(c + vx(this, d, b)), c = !0) : c = !1);
                    if (c) {
                        b = !0;
                        break a
                    }
                }
                b = mu(this.d, this, a) ? this.d.yf(this,
                    a, n[ub](a[vb])) : !1
            }
            if (!b && (b = wx(this))) a: if (mu(this.d, this, a)) {
                b = n[ub](a[vb]);
                if (!/[^0-9]/ [Ma](b) && (b = Om(b), 1 <= b && b <= 9 && nx(this, b - 1))) {
                    b = !0;
                    break a
                }
                b = Dx(this, !0, a)
            } else b = !1;
            !b && !a[hc] && !a[gb] && !a[Xb] && (b = lx(this, a));
            b && mx(this) && !this.O() && this.Va(!1);
            return !0
        };
        Q.kg = function (a) {
            return !!a[vb] && !mu(this.d, this, a)
        };
        Q.Rc = function (a) {
            this.P && !Cv(this, a[H]) && this.Va(!0)
        };
        Q.dj = function (a) {
            return (a[hc] || a[gb] || a[Xb]) && lx(this, a) ? (mx(this) && !this.O() && this.Va(!1), a[bb](), a[jc](), !0) : !1
        };
        Q.Ve = function () {
            this.Va(!0)
        };
        Q.ld = function () {
            mx(this) ? this.Va(!1) : this.Kb()
        };
        Q.Rg = function () {
            this.Da(this.Nb().D() - 1)
        };
        Q.Sg = function () {
            this.Da(this.Nb().D() + 1)
        };
        Q.Tg = function () {
            this.Da(!0)
        };
        Q.Ug = function () {
            this.Da(!1)
        };
        Q.Ng = function () {
            var a = this.O(),
                b = this.Nb().D();
            b <= 0 || (this.Ia(a[J](0, b - 1) + a[J](b)), this.Da(b - 1))
        };
        Q.Qg = function () {
            var a = this.O(),
                b = this.Nb().D();
            b >= a[E] || (this.Ia(a[J](0, b) + a[J](b + 1)), this.Da(b))
        };
        Q.We = function () {
            this.jc()
        };
        Q.Mf = function () {
            this.kc()
        };
        Q.Og = function () {
            px(this, this.p)
        };
        Q.Pg = function () {
            px(this, -this.p)
        };
        Q.Bi = function () {
            sx(this, 0)
        };
        Q.Ci = function () {
            sx(this, this.b[this.R].lb[E] - 1)
        };
        Q.Vg = function () {
            this.R = ix(this.R - 1, this.b[E]);
            Ax(this)
        };
        Q.Wg = function () {
            this.R = ix(this.R + 1, this.b[E]);
            Ax(this)
        };
        Q.Di = function () {
            this.R = 0
        };
        Q.Ei = function () {
            this.R = r.max(0, this.b[E] - 1)
        };
        Q.Of = function () {
            var a;
            a = this.R;
            var b = this.b[a].Lc;
            if (b[E] <= 1) a = !1;
            else {
                var c = b[J](b[E] - 1);
                this.b[a] = new yx(b[J](0, b[E] - 1));
                a >= this.b[E] - 1 ? this.b[s](new yx(c)) : this.b[a + 1] = new yx(c + this.b[a + 1].Lc);
                a = !0
            } if (a) Ax(this), this.f = xq(this, new Xt(rx(this), 1))
        };
        Q.Nf = function () {
            var a;
            a = this.R;
            if (a + 1 >= this.b[E]) a = !1;
            else {
                var b = this.b[a + 1].Lc;
                this.b[a] = new yx(this.b[a].Lc + b[J](0, 1));
                b[E] <= 1 ? Ym[Ic][I](this.b, a + 1, 1) : this.b[a + 1] = new yx(b[J](1));
                a = !0
            } if (a) Ax(this), this.f = xq(this, new Xt(rx(this), 1))
        };
        Q.bj = function (a) {
            this.Ec && a[bb]()
        };
        Q.cj = dm("Ya");
        Q.ej = function (a) {
            var b;
            return a[H] instanceof mv && 0 <= (b = ju(this, a[H])) ? nx(this, b) : !1
        };
        Q.Qe = cm("d");
        Q.Bd = function () {
            return this.K && this.P
        };
        Q.cg = function (a) {
            if (!(a < 1)) this.p = a
        };
        Q.Nb = function () {
            this.c[B] != this.c[pc] && is(this.c[B]);
            return as(zo(this.C()))
        };
        Q.Da = function (a) {
            this.c[B] != this.c[pc] && is(this.c[B]);
            var b = this.c[B],
                c = 0;
            !b || !b[Kc] ? b = this.c : (c = b[Kc][E], c = mm(a) ? a ? 0 : c : r.min(r.max(a, 0), c));
            (a = Ir(b, c, b, c)) && a[yb]()
        };
        Q.Wa = function () {
            return wx(this) ? rx(this)[L](vd) : (so(this.c) || M)[u](/\u00a0/g, N)
        };
        Q.O = function () {
            return wx(this) ? Bx(this)[L](M) : (so(this.c) || M)[u](/\u00a0/g, N)
        };
        Q.Ia = function (a) {
            wx(this) || (qo(this.c, a[u](/ /g, Xl)), this.P && (zo(this.C())[wb](), this.c[wb](), this.Da(!1)))
        };
        Q.fh = function (a, b) {
            if (mx(this) && a != b) {
                var c = this.Nb(),
                    d = c.A(),
                    f = c.D(),
                    g = this.O(),
                    c = g[x](a);
                !g && !a && b ? this.Ia(b) : c >= 0 && (g = g[u](a, b), Ia(d, g), this.Te(), d = f + b[E] - (c + a[E] > f ? 0 : a[E]), c = c + b[E], this.z[s](this.T[c] = {
                    Ud: a,
                    Td: b,
                    wf: this.O(),
                    xf: this.Wa(),
                    index: c
                }), this.Da(d))
            }
        };
        Q.Va = function (a) {
            return Dx(this, a, j)
        };
        Q.If = function (a, b) {
            b = b || {
                background: Yc
            };
            this.Kb();
            Hv(this, a, M, i, b).Ga(!1)
        };
        Q.Fh = function (a) {
            this.b = [new yx(this.Wa(), a)];
            this.f = !0
        };
        Q.Te = function () {
            iu(this, function (a) {
                a.Ga(!1)
            });
            zx(this, []);
            this.f = !1
        };
        Q.Kb = function () {
            ku(this);
            var a = rx(this)[L](M);
            zx(this, []);
            ho(this.c);
            this.ia = ih;
            this.Ia(a);
            ho(this.jb)
        };
        Q.ig = function (a) {
            sx(this, a)
        };
        Ga(Q, function () {
            rv(this, this.c);
            this.T = {};
            this.z = [];
            this.Kb();
            this.Ia(M)
        });
        U(Ex, lu);
        var Fx = {
            Ig: [13],
            Jg: [8],
            ub: [32, 40, 9]
        };
        Q = Ex[F];
        Q.zf = function (a, b) {
            var c = a.O(),
                d = Gx(a);
            b[A] == 32 && !d[Mc] && d[y][Sa](-1) == N && /[A-Z]/ [Ma](d[y]) && (c = c[Sa](0, -1), a.Ia(c));
            !d[Mc] && d[y][Sa](-1) == Mj && !/[A-Z]/ [Ma](d[y]) && (c = xw(c, M), a.Ia(c));
            xq(a, new Xt([c], 1, !0));
            return !0
        };
        Q.yf = function (a, b, c) {
            b = Gx(a);
            a: if (c = b[y] + c, !/[A-Z]/ [Ma](c)) {
                for (var d = r.min(c[E], 4); d > 0; --d) {
                    var f = yw[c[Sa](-d)];
                    if (f) {
                        c = xw(c[Sa](0, -d), f);
                        break a
                    }
                }
                c = xw(c[Sa](0, -1), c[Sa](-1))
            }
            c = c + b[Mc];
            a.Ia(c);
            a.Da(c[E] - b[Mc][E]);
            return !0
        };
        Q.Le = function (a, b) {
            if (b[A] == 32 && a instanceof jx && mx(a)) {
                var c = Gx(a);
                if (/[A-Z]/ [Ma](c[y])) return !c[Mc] && c[y][Sa](-1) == N
            }
            return Ex.g.Le[I](this, a, b)
        };
        Q.vg = function (a, b, c) {
            if ((b[Xb] || b[hc] || b[gb]) && c != Yl) a = !1;
            else {
                if (b = b[A] == 32) b = /[A-Z]/ [Ma](Gx(a)[y]);
                a = b ? !0 : this.fd(c)
            }
            return a
        };
        Q.fd = function (a) {
            return UA[zc](a[Lc]())
        };
        U(Hx, Bu);
        var $A = Zq();
        Q = Hx[F];
        Q.Ob = P("t13nja");
        Q.oc = function () {
            return [pj, nj]
        };
        Q.Fe = function (a) {
            return a.B == lj
        };
        Q.Za = function (a) {
            this.c = a;
            Hx.g.Za[I](this, this.c);
            var a = this.j.Xa(this.c),
                b = T(this.Wi, this, a);
            nu(this.f, a, bl, b);
            nu(this.f, a, zh, b);
            nu(this.f, a, Mh, T(this.Xi, this))
        };
        Q.Ab = function (a) {
            if (this.cd(a)) {
                Hx.g.Ab[I](this, a);
                this.j.ag(a);
                var b = a.c[$A];
                b && b.s();
                a.c[$A] = j
            }
        };
        Q.Wi = function (a, b) {
            var c = this.c.c[$A];
            if (c) {
                var d = b[C] == bl ? a.O() : M;
                d ? (c[u](d), c.Hb(!0)) : Hp(c);
                c.s();
                this.c.sb();
                this.c.c[$A] = j;
                if (b.b) {
                    var c = new Rt(b.b[A], b.b[vb], !1, j),
                        f;
                    for (f in [qh, zg, Kk, Fj, ik, Xk]) c[f] = b.b[f];
                    Mq(T(this[Eb], this, this.c, c), 0)
                }
            }
        };
        va(Q, function (a, b) {
            var c = this.j.Xa(a);
            if (!Du(this, a, b)) {
                for (var d = this.f, f = c.Fa(), g = d.b.get(f).Pb(), h = 0, k = g[E]; h < k; ++h) c[fc](g[h], d.b.get(f).get(g[h]));
                c.Qe(j);
                return !1
            }
            c.Qe(this.f);
            d = this.f;
            f = c.Fa();
            g = d.b.get(f).Pb();
            h = 0;
            for (k = g[E]; h < k; ++h) c[Bb](g[h], d.b.get(f).get(g[h]));
            c[Dc]();
            this.N(a) ? a.Cd() ? (d = b.Ha, d = !! d && d[vb] == 0) : d = !0 : d = !0;
            if (d) return !1;
            d = a.Wb();
            if (!d) return !1;
            if (b[A] == 32)
                if (!b[Bc] && !b[Xb] && !b[hc] && !b[gb]) return Gp(d), d[u](am), d.Hb(!0), !0;
                else if (b[Bc] && !b[Xb] && !b[hc] && !b[gb]) return !1;
            if (!mu(this.f,
                c, b)) return !1;
            a.c[$A] = d;
            Bq(a, this.b).yd = M;
            Gp(d);
            d.f = d.H.qb();
            this.j.Df(a, d.Me());
            this.f.yf(c, b, n[ub](b[vb]));
            return !0
        });
        Q.oi = function (a, b, c, d, f) {
            if (a.Bd()) {
                var c = b.q(),
                    g = a.Wa() || a.O();
                if (!(c != g && c != g + vd))!d || !f ? a.Kb() : (a = b.b || 0, b = Bq(this.c, this.b), b.Hg = c, b.ui = a, this.j.Lf(this.c, f, 9))
            }
        };
        Q.Xi = function (a) {
            var b;
            if (a.d) {
                b = a[H];
                var c = a.d,
                    d = a.c,
                    a = a.f;
                if (!c || c[E] == 0 || !c[0]) b = !1;
                else {
                    var f = Ks(mj, lj),
                        d = Dw(c, f, d, a);
                    Bq(this.c, this.b).yd = d.q();
                    c[L](M)[E] > this.d.Bf ? (b.If(sf), b = !1) : (b = this.M.Ad(d, T(this.oi, this, b)), b = mm(b))
                }
            } else b = !1;
            return b
        };
        var aB = Zq();
        Ix[F].Xa = function (a) {
            var b = a.c[aB];
            if (!b) {
                b = new jx(Pn(p[mc]), this.c);
                b.Ff = this.d;
                eu(b, i);
                b[Dc]();
                a.c[aB] = b;
                var c = b.h();
                this.b.w(c, Gj, function (a) {
                    var b = new Iv(c);
                    b[Bb](Hh, T(b.s, b));
                    b.Cf(a)
                })
            }
            return b
        };
        Ix[F].Df = function (a, b, c) {
            var d = this.Xa(a);
            d[Dc]();
            a = {
                direction: a.Be()
            };
            Eo(d.h(), a);
            Ev(d, b);
            c && d.Ia(c)
        };
        Ix[F].Lf = function (a, b, c) {
            a = this.Xa(a);
            xx(a, b.c);
            a.cg(c);
            Ax(a)
        };
        Ix[F].ag = function (a) {
            var b = a.c[aB];
            this.b.Ca(b.h(), Gj);
            b.s();
            a.c[aB] = j
        };
        U(Kx, fx);
        U(Nx, np);
        Nx[F].q = dm("b");
        Nx[F].Ye = function (a) {
            return a + 1 + he + this.b
        };
        var Sx = Zq();
        U(Vx, Tv);
        im(Vx);
        if (Z) Vx[F].Cc = function (a, b) {
            var c = Vx.g.ab[I](this, a && a[B]);
            if (c) {
                var d = this.b(b, Pn(a)),
                    f = c[K];
                f && f.replaceChild(d, c)
            }
        };
        Vx[F].ab = function (a) {
            a = Vx.g.ab[I](this, a && a[B]);
            Z && a && a.__goog_wrapper_div && (a = a[B]);
            return a
        };
        Vx[F].Qd = function (a, b) {
            return Vx.g.Qd[I](this, [this.b(a, b), b.l(O, Gi + (this.v() + Kd), Xl)], b)
        };
        Vx[F].b = function (a, b) {
            return Wx(a, this.v(), b)
        };
        Vx[F].v = P(Hi);
        U(Xx, Sv);
        Q = Xx[F];
        Q.$e = !0;
        Q.Sf = !1;
        Q.Pe = !1;
        Q.ii = !1;
        Q.S = function () {
            Xx.g.S[I](this);
            this.b && ay(this, this.b, !0);
            Fu(this.h(), gi, Bl)
        };
        Q.wb = function () {
            Xx.g.wb[I](this);
            if (this.b) {
                this.Y(!1);
                this.b.wb();
                ay(this, this.b, !1);
                var a = this.b.h();
                a && jo(a)
            }
        };
        Q.n = function () {
            Xx.g.n[I](this);
            this.b && (this.b.s(), delete this.b);
            delete this.ia;
            this.z.s()
        };
        Q.Fc = function (a) {
            Xx.g.Fc[I](this, a);
            if (this.N() && (this.Y(!(this.U & 64), a), this.b)) this.b.Jb = !! (this.U & 64)
        };
        Q.Jc = function (a) {
            Xx.g.Jc[I](this, a);
            if (this.b && !this.N()) this.b.Jb = !1
        };
        Q.zb = function () {
            Uu(this, !1);
            return !0
        };
        Q.Hf = function (a) {
            this.b && this.b.P && !this.Wf(a[H]) && this.Y(!1)
        };
        Q.Wf = function (a) {
            return a && ko(this.h(), a) || this.b && Cv(this.b, a) || !1
        };
        Q.Ae = function (a) {
            if (a[A] == 32) {
                if (a[bb](), a[C] != qj) return !1
            } else if (a[C] != nj) return !1;
            if (this.b && this.b.P) {
                var b = this.b.Ne(a);
                return a[A] == 27 ? (this.Y(!1), !0) : b
            }
            return a[A] == 40 || a[A] == 38 || a[A] == 32 ? (this.Y(!0), !0) : !1
        };
        Q.Sc = function () {
            this.Y(!1)
        };
        Q.ei = function () {
            this.N() || this.Y(!1)
        };
        Q.qd = function (a) {
            this.Pe || this.Y(!1);
            Xx.g.qd[I](this, a)
        };
        Q.Rd = function (a) {
            var b = this.b;
            if (a != b && (b && (this.Y(!1), this.K && ay(this, b, !1), delete this.b), a)) {
                this.b = a;
                cu(a, this);
                a.Ta(!1);
                var c = this.Pe;
                (a.Ed = c) && a.tb(!0);
                this.K && ay(this, a, !0)
            }
            return b
        };
        Q.Vc = function (a) {
            $x(this).Ib(a, !0)
        };
        Q.Ga = function (a) {
            Xx.g.Ga[I](this, a);
            this[qc]() || this.Y(!1)
        };
        Q.Y = function (a, b) {
            Xx.g.Y[I](this, a);
            if (this.b && !! (this.U & 64) == a) {
                if (a) this.b.K || (this.ii ? eu(this.b, this.h()[K]) : eu(this.b, i)), this.f = Qo(this.h()), this.d = Yo(this.h()), this.Gf(), vv(this.b, -1);
                else if (Uu(this, !1), this.b.Jb = !1, this.h() && Fu(this.h(), tg, M), this.F != j) {
                    this.F = i;
                    var c = this.b.h();
                    c && Vo(c, M, M)
                }
                this.b.Ta(a, !1, b);
                if (!this.Oe) {
                    var c = bu(this),
                        d = a ? c.w : c.Ca;
                    d[I](c, yo(this.C()), Gj, this.Hf, !0);
                    this.Pe && d[I](c, this.b, Mg, this.ei);
                    d[I](c, this.z, sl, this.ai);
                    a ? this.z[sc]() : this.z[Vb]()
                }
            }
        };
        Q.Gf = function () {
            if (this.b.K) {
                var a = new Ap(this.ia || this.h(), this.$e ? 5 : 7, !this.Sf, this.Sf),
                    b = this.b.h();
                this.b.P || (Aa(b[G], li), Zo(b, !0));
                if (!this.F && this.Sf) this.F = Wo(b);
                a.b(b, this.$e ? 4 : 6, j, this.F);
                this.b.P || (Zo(b, !1), Aa(b[G], Ml))
            }
        };
        Q.ai = function () {
            var a = Yo(this.h()),
                b = Qo(this.h());
            if (!(this.d == a || (!this.d || !a ? 0 : this.d[y] == a[y] && this.d[t] == a[t] && this.d.top == a.top && this.d[Gc] == a[Gc])) || !(this.f == b || (!this.f || !b ? 0 : this.f.top == b.top && this.f[Mc] == b[Mc] && this.f[xc] == b[xc] && this.f[y] == b[y]))) this.d = a, this.f = b, this.Gf()
        };
        Q.Gj = function (a) {
            Fu(this.h(), tg, a[H].h().id)
        };
        Q.Hj = function () {
            hu(this.b, this.b.Ba) || Fu(this.h(), tg, M)
        };
        Gu(Hi, function () {
            return new Xx(j)
        });
        U(by, Xx);
        Q = by[F];
        Q.Lg = j;
        Q.zb = function () {
            Uu(this, !1);
            Vu(this, !(this.U & 16));
            return !0
        };
        Q.Hf = function (a) {
            by.g.Hf[I](this, a);
            Vu(this, !1)
        };
        Q.lc = function (a) {
            var b = by.g.lc[I](this, a);
            a[A] == 27 && Vu(this, !1);
            return b
        };
        Q.Sc = function (a) {
            by.g.Sc[I](this, a);
            Vu(this, !1)
        };
        Q.qd = function (a) {
            by.g.qd[I](this, a);
            Vu(this, !1)
        };
        Xx[F].Gf = function () {
            var a = new yp(this.Lg || this.h(), this.$e ? 5 : 7, !0),
                b = this.b.h();
            if (!this.b.P) b[G].Vi = li, Zo(b, !0);
            a.b(b, this.$e ? 4 : 6, new Co(0, 0, 0, 0));
            if (!this.b.P) Zo(b, !1), b[G].Vi = Ml
        };
        U(cy, Qv);
        im(cy);
        cy[F].l = function (a) {
            var b = Mu(this, a.U),
                b = {
                    "class": Gi + (b ? b[L](N) : M),
                    title: a.p || M
                }, a = a.C().l(O, b, a.Kc() || M);
            $o(a, !0);
            return a
        };
        U(dy, mv);
        dy[F].zb = function () {
            return oq(this, rg)
        };
        Gu(Oi, function () {
            return new dy(j)
        });
        U(ey, Tv);
        im(ey);
        ey[F].v = P(Ti);
        U(fy, Sv);
        Gu(Ti, function () {
            return new fy(j)
        });
        var ly = {
            aliceblue: "#f0f8ff",
            antiquewhite: "#faebd7",
            aqua: "#00ffff",
            aquamarine: "#7fffd4",
            azure: "#f0ffff",
            beige: "#f5f5dc",
            bisque: "#ffe4c4",
            black: "#000000",
            blanchedalmond: "#ffebcd",
            blue: "#0000ff",
            blueviolet: "#8a2be2",
            brown: "#a52a2a",
            burlywood: "#deb887",
            cadetblue: "#5f9ea0",
            chartreuse: "#7fff00",
            chocolate: "#d2691e",
            coral: "#ff7f50",
            cornflowerblue: "#6495ed",
            cornsilk: "#fff8dc",
            crimson: "#dc143c",
            cyan: "#00ffff",
            darkblue: "#00008b",
            darkcyan: "#008b8b",
            darkgoldenrod: "#b8860b",
            darkgray: "#a9a9a9",
            darkgreen: "#006400",
            darkgrey: "#a9a9a9",
            darkkhaki: "#bdb76b",
            darkmagenta: "#8b008b",
            darkolivegreen: "#556b2f",
            darkorange: "#ff8c00",
            darkorchid: "#9932cc",
            darkred: "#8b0000",
            darksalmon: "#e9967a",
            darkseagreen: "#8fbc8f",
            darkslateblue: "#483d8b",
            darkslategray: "#2f4f4f",
            darkslategrey: "#2f4f4f",
            darkturquoise: "#00ced1",
            darkviolet: "#9400d3",
            deeppink: "#ff1493",
            deepskyblue: "#00bfff",
            dimgray: "#696969",
            dimgrey: "#696969",
            dodgerblue: "#1e90ff",
            firebrick: "#b22222",
            floralwhite: "#fffaf0",
            forestgreen: "#228b22",
            fuchsia: "#ff00ff",
            gainsboro: "#dcdcdc",
            ghostwhite: "#f8f8ff",
            gold: "#ffd700",
            goldenrod: "#daa520",
            gray: "#808080",
            green: "#008000",
            greenyellow: "#adff2f",
            grey: "#808080",
            honeydew: "#f0fff0",
            hotpink: "#ff69b4",
            indianred: "#cd5c5c",
            indigo: "#4b0082",
            ivory: "#fffff0",
            khaki: "#f0e68c",
            lavender: "#e6e6fa",
            lavenderblush: "#fff0f5",
            lawngreen: "#7cfc00",
            lemonchiffon: "#fffacd",
            lightblue: "#add8e6",
            lightcoral: "#f08080",
            lightcyan: "#e0ffff",
            lightgoldenrodyellow: "#fafad2",
            lightgray: "#d3d3d3",
            lightgreen: "#90ee90",
            lightgrey: "#d3d3d3",
            lightpink: "#ffb6c1",
            lightsalmon: "#ffa07a",
            lightseagreen: "#20b2aa",
            lightskyblue: "#87cefa",
            lightslategray: "#778899",
            lightslategrey: "#778899",
            lightsteelblue: "#b0c4de",
            lightyellow: "#ffffe0",
            lime: "#00ff00",
            limegreen: "#32cd32",
            linen: "#faf0e6",
            magenta: "#ff00ff",
            maroon: "#800000",
            mediumaquamarine: "#66cdaa",
            mediumblue: "#0000cd",
            mediumorchid: "#ba55d3",
            mediumpurple: "#9370d8",
            mediumseagreen: "#3cb371",
            mediumslateblue: "#7b68ee",
            mediumspringgreen: "#00fa9a",
            mediumturquoise: "#48d1cc",
            mediumvioletred: "#c71585",
            midnightblue: "#191970",
            mintcream: "#f5fffa",
            mistyrose: "#ffe4e1",
            moccasin: "#ffe4b5",
            navajowhite: "#ffdead",
            navy: "#000080",
            oldlace: "#fdf5e6",
            olive: "#808000",
            olivedrab: "#6b8e23",
            orange: "#ffa500",
            orangered: "#ff4500",
            orchid: "#da70d6",
            palegoldenrod: "#eee8aa",
            palegreen: "#98fb98",
            paleturquoise: "#afeeee",
            palevioletred: "#d87093",
            papayawhip: "#ffefd5",
            peachpuff: "#ffdab9",
            peru: "#cd853f",
            pink: "#ffc0cb",
            plum: "#dda0dd",
            powderblue: "#b0e0e6",
            purple: "#800080",
            red: "#ff0000",
            rosybrown: "#bc8f8f",
            royalblue: "#4169e1",
            saddlebrown: "#8b4513",
            salmon: "#fa8072",
            sandybrown: "#f4a460",
            seagreen: "#2e8b57",
            seashell: "#fff5ee",
            sienna: "#a0522d",
            silver: "#c0c0c0",
            skyblue: "#87ceeb",
            slateblue: "#6a5acd",
            slategray: "#708090",
            slategrey: "#708090",
            snow: "#fffafa",
            springgreen: "#00ff7f",
            steelblue: "#4682b4",
            tan: "#d2b48c",
            teal: "#008080",
            thistle: "#d8bfd8",
            tomato: "#ff6347",
            turquoise: "#40e0d0",
            violet: "#ee82ee",
            wheat: "#f5deb3",
            white: "#ffffff",
            whitesmoke: "#f5f5f5",
            yellow: "#ffff00",
            yellowgreen: "#9acd32"
        };
        var my = /#(.)(.)(.)/,
            hy = /^#(?:[0-9a-f]{3}){1,2}$/i,
            jy = /^(?:rgb)?\((0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2}),\s?(0|[1-9]\d{0,2})\)$/i;
        U(ny, Vx);
        im(ny);
        ny[F].b = function (a, b) {
            return ny.g.b[I](this, oy(a, b), b)
        };
        ny[F].Qc = function (a, b) {
            a && py(this.ab(a), b)
        };
        ny[F].rd = function (a) {
            this.Qc(a.h(), a.Ma());
            Nn(a.h(), Ai);
            ny.g.rd[I](this, a)
        };
        U(qy, Hu);
        im(qy);
        var ty = 0;
        qy[F].l = function (a) {
            var b = this.Tb(a);
            return a.C().l(O, b ? b[L](N) : j, ry(this, a.Oa, a.eb, a.C()))
        };
        qy[F].Cc = function (a, b) {
            if (a) {
                var c = Tn(p, gl, this.v() + Ad, a)[0];
                if (c) {
                    var d = 0;
                    V(c.rows, function (a) {
                        V(a.cells, function (a) {
                            ho(a);
                            if (b) {
                                var c = b[d++];
                                c && a[Ja](c)
                            }
                        })
                    });
                    if (d < b[E]) {
                        for (var f = [], g = Pn(a), h = c.rows[0].cells[E]; d < b[E];) {
                            var k = b[d++];
                            f[s](sy(this, k, g));
                            f[E] == h && (k = g.l(xl, this.v() + ae, f), c[Ja](k), Ba(f, 0))
                        }
                        if (f[E] > 0) {
                            for (; f[E] < h;) f[s](sy(this, M, g));
                            k = g.l(xl, this.v() + ae, f);
                            c[Ja](k)
                        }
                    }
                }
                $o(a, !0, Z)
            }
        };
        qy[F].v = P("inputapi-palette");
        U(wy, wq);
        Q = wy[F];
        Q.$a = j;
        Q.hg = j;
        Q.Vc = function (a) {
            var b = this.b[E];
            a && (this.pd(a, !1), bn(this.b, b, 0, a))
        };
        xa(Q, function () {
            var a = this.b;
            if (!km(a))
                for (var b = a[E] - 1; b >= 0; b--) delete a[b];
            Ba(a, 0);
            this.$a = j
        });
        Q.n = function () {
            wy.g.n[I](this);
            delete this.b;
            this.$a = j
        };
        Q.pd = function (a, b) {
            a && (typeof this.hg == Vh ? this.hg(a, b) : typeof a.rg == Vh && a.rg(b))
        };
        U(zy, Nu);
        Q = zy[F];
        Q.eb = j;
        Q.ic = -1;
        Q.r = j;
        Q.n = function () {
            zy.g.n[I](this);
            if (this.r) this.r.s(), this.r = j;
            this.eb = j
        };
        Q.Hd = function (a) {
            zy.g.Hd[I](this, a);
            Ey(this);
            this.r ? (this.r[Hb](), xy(this.r, a)) : (this.r = new wy(a), this.r.hg = T(this.pd, this), bu(this).w(this.r, Fk, this.xj));
            this.ic = -1
        };
        Q.Kc = P(j);
        Q.ee = function (a) {
            zy.g.ee[I](this, a);
            var b = uy(this.La(), this, a[H]);
            if ((!b || !a[Oa] || !ko(b, a[Oa])) && b != Ay(this)) a = this.Oa, By(this, a ? Wm(a, b) : -1)
        };
        Q.ue = function (a) {
            zy.g.ue[I](this, a);
            var b = uy(this.La(), this, a[H]);
            (!b || !a[Oa] || !ko(b, a[Oa])) && b == Ay(this) && vy(this.La(), this, b, !1)
        };
        Q.Fc = function (a) {
            zy.g.Fc[I](this, a);
            if (this.N() && (a = uy(this.La(), this, a[H]), a != Ay(this))) {
                var b = this.Oa;
                By(this, b ? Wm(b, a) : -1)
            }
        };
        Q.zb = function () {
            var a = Ay(this);
            return a ? (this.r && yy(this.r, a), oq(this, rg)) : !1
        };
        Q.lc = function (a) {
            var b = this.Oa,
                b = b ? b[E] : 0,
                c = this.eb[t];
            if (b == 0 || !this[qc]()) return !1;
            if (a[A] == 13 || a[A] == 32) return this.zb(a);
            if (a[A] == 36) return By(this, 0), !0;
            else if (a[A] == 35) return By(this, b - 1), !0;
            var d = this.ic < 0 ? this.r ? this.r.$a ? Wm(this.r.b, this.r.$a) : -1 : -1 : this.ic;
            switch (a[A]) {
            case 37:
                d == -1 && (d = b);
                if (d > 0) return By(this, d - 1), a[bb](), !0;
                break;
            case 39:
                if (d < b - 1) return By(this, d + 1), a[bb](), !0;
                break;
            case 38:
                d == -1 && (d = b + c - 1);
                if (d >= c) return By(this, d - c), a[bb](), !0;
                break;
            case 40:
                if (d == -1 && (d = -c), d < b - c) return By(this,
                    d + c), a[bb](), !0
            }
            return !1
        };
        Q.xj = bm();
        Q.Zb = dm("ic");
        Q.pd = function (a, b) {
            if (this.h() && a) {
                var c = a[K],
                    d = this.La().v() + Ed;
                b ? Nn(c, d) : On(c, d)
            }
        };
        U(Fy, zy);
        Fy[F].d = j;
        Fy[F].ng = function () {
            var a = this.r ? this.r.$a : j;
            return a ? (a = a[G][Pm(Hg)] || M, Hy(a)) : j
        };
        Fy[F].Yf = function (a) {
            a = Hy(a);
            if (!this.d) this.d = Xr(this.b, function (a) {
                return Hy(a)
            });
            Dy(this, a ? Wm(this.d, a) : -1)
        };
        U(Iy, Xx);
        var Ky = {
            b: "#000,#444,#666,#999,#ccc,#eee,#f3f3f3,#fff".split(","),
            d: "#f00,#f90,#ff0,#0f0,#0ff,#00f,#90f,#f0f".split(","),
            c: "#f4cccc,#fce5cd,#fff2cc,#d9ead3,#d0e0e3,#cfe2f3,#d9d2e9,#ead1dc,#ea9999,#f9cb9c,#ffe599,#b6d7a8,#a2c4c9,#9fc5e8,#b4a7d6,#d5a6bd,#e06666,#f6b26b,#ffd966,#93c47d,#76a5af,#6fa8dc,#8e7cc3,#c27ba0,#cc0000,#e69138,#f1c232,#6aa84f,#45818e,#3d85c6,#674ea7,#a64d79,#990000,#b45f06,#bf9000,#38761d,#134f5c,#0b5394,#351c75,#741b47,#660000,#783f04,#7f6000,#274e13,#0c343d,#073763,#20124d,#4c1130".split(",")
        };
        Q = Iy[F];
        Q.ng = function () {
            return this.Ma()
        };
        Q.Yf = function (a) {
            this.vb(a)
        };
        Q.vb = function (a) {
            for (var b = 0, c; c = this.b ? hu(this.b, b) : j; b++) typeof c.Yf == Vh && c.Yf(a);
            Iy.g.vb[I](this, a)
        };
        Q.Sc = function (a) {
            typeof a[H].ng == Vh ? this.vb(a[H].ng()) : a[H].Ma() == Rj && this.vb(j);
            Iy.g.Sc[I](this, a);
            a[jc]();
            oq(this, rg)
        };
        Q.Y = function (a, b) {
            if (a && (this.b ? gu(this.b) : 0) == 0) this.Rd(Jy(this.C())), this.vb(this.Ma());
            Iy.g.Y[I](this, a, b)
        };
        Gu(Ai, function () {
            return new Iy(j)
        });
        U(Ly, Vx);
        im(Ly);
        Ly[F].v = P(Vi);
        U(My, Ly);
        im(My);
        My[F].b = function (a, b) {
            return Wx(oy(a, b), this.v(), b)
        };
        My[F].Qc = function (a, b) {
            a && py(this.ab(a), b)
        };
        My[F].rd = function (a) {
            this.Qc(a.h(), a.Ma());
            Nn(a.h(), Ui);
            My.g.rd[I](this, a)
        };
        U(Ny, Iy);
        Gu(Ui, function () {
            return new Ny(j)
        });
        U(Oy, Xx);
        Gu(Vi, function () {
            return new Oy(j)
        });
        U(Py, Xx);
        Q = Py[F];
        Q.r = j;
        Q.Zf = j;
        Q.S = function () {
            Py.g.S[I](this);
            Qy(this);
            Sy(this)
        };
        Q.n = function () {
            Py.g.n[I](this);
            if (this.r) this.r.s(), this.r = j;
            this.Zf = j
        };
        Q.Sc = function (a) {
            this.r && yy(this.r, a[H]);
            Py.g.Sc[I](this, a);
            a[jc]();
            oq(this, rg)
        };
        Q.Ej = function () {
            var a = this.r ? this.r.$a : j;
            Py.g.vb[I](this, a && a.Ma());
            Qy(this)
        };
        Q.Rd = function (a) {
            var b = Py.g.Rd[I](this, a);
            a != b && (this.r && this.r[Hb](), a && (this.r ? iu(a, function (a) {
                this.r.Vc(a)
            }, this) : Ry(this, a)));
            return b
        };
        Q.Vc = function (a) {
            Py.g.Vc[I](this, a);
            this.r ? this.r.Vc(a) : Ry(this, $x(this))
        };
        Q.vb = function (a) {
            if (a != j && this.r)
                for (var b = 0, c; c = this.r.b[b] || j; b++)
                    if (c && typeof c.Ma == Vh && c.Ma() == a) {
                        this.r && yy(this.r, c);
                        return
                    }
            this.r && yy(this.r, j)
        };
        Q.Y = function (a, b) {
            Py.g.Y[I](this, a, b);
            this.U & 64 && vv($x(this), this.r ? this.r.$a ? Wm(this.r.b, this.r.$a) : -1 : -1)
        };
        Gu("inputapi-select", function () {
            return new Py(j)
        });
        U(Ty, Py);
        Gu("inputapi-toolbar-select", function () {
            return new Ty(j)
        });
        U(Uy, mv);
        Gu("inputapi-checkbox-menuitem", function () {
            return new Uy(j)
        });
        U(Vy, Sv);
        Gu("inputapi-toggle-button", function () {
            return new Vy(j)
        });
        var bB = {
            Bk: Ck,
            lk: rj,
            xk: Vk,
            yk: al
        }, cB = ["bn", "gu", ki, "kn", "ml", "mr", "ne", "or", "pa", "sa", "si", "ta", il, Gl],
            $y = [Ag, Cg, "bn", Ul, "el", "gu", ki, "kn", "ml", "mr", "ne", "or", Lh, "pa", Ak, "sa", Vk, "si", "ta", il, ql, Gl],
            dB = {
                ALL: $y,
                INDIC: cB
            }, fz = {
                Ah: {
                    code: Fh
                }
            }, bz = $y,
            az = {
                ALL: bz,
                INDIC: cB
            }, Zy = {
                Vh: "sourceLanguage",
                Wh: "destinationLanguage",
                Xh: "transliterationEnabled",
                Uh: Mk,
                Ki: "adjustElementStyle",
                Ji: "adjustElementDirection",
                bk: "controlType"
            }, eB = new Tv;
        eB.v = P(Wi);
        var fB = cv("inputapi-transliterate-language-menu"),
            gB = fv("inputapi-transliterate-language-menuitem"),
            hB = new Vx;
        hB.Qd = function (a, b) {
            return Vx.g.Qd[I](this, this.b(a, b), b)
        };
        hB.v = P(Wi);
        Q = Xy[F];
        Q.Ai = function (a) {
            a[H].U & 16 ? this.th() : this.sh()
        };
        Q.yi = function (a) {
            this.vh(Fh, a[H].sd.language);
            jz(this, !0)
        };
        Q.Yh = function (a) {
            var b = a[ab];
            a.c == cl && oq(this.b, {
                type: Ck,
                transliterationEnabled: b.N,
                sourceLanguage: b.X,
                targetLanguage: b.B,
                destinationLanguage: b.B
            })
        };
        Q.s = function () {
            this.b.s();
            this.b = j;
            this.d.s();
            this.d = j;
            kn(this.f, function (a) {
                a.s()
            });
            this.f = j;
            kn(this.j, function (a) {
                a.s()
            });
            this.j = j;
            try {
                this.c.s()
            } catch (a) {}
            this.c = j
        };
        Q.hj = function (a, b, c) {
            nn(bB, a) || Yy(vg, vf + a);
            this.b[Bb](a, b, !1, c)
        };
        Q.removeEventListener = function (a, b, c) {
            nn(bB, a) || Yy(vk, vf + a);
            this.b[fc](a, b, !1, c)
        };
        Q.ij = function (a, b) {
            lm(a) || Yy(Aj, rf);
            for (var c = b || {}, d = 0; d < a[E]; d++) {
                var f = S(a[d]) ? p[Wa](a[d]) : a[d];
                f || Yy(Aj, tf + a[d]);
                var g = qm(f);
                if (!this.f[g]) {
                    var h = f[Cc][Hc](),
                        h = h == mf || h == bf ? new As(f) : new cr(f),
                        k = h.dc();
                    if (!this.j[g] && this.z) k = new Nq(k), this.j[g] = k, k.$g(Mk, this.z), k.f = !0, Vp(k, Lk, this.Fg, !1, this);
                    f[C] && f[C][Hc]() == Vf && f.id != Rk && Eo(f, {
                        "line-height": oe,
                        "font-family": Re,
                        "font-size": re
                    });
                    h.ia = this.p;
                    Cq(h, this.d);
                    this.f[g] = h
                }
            }
            f = Zy;
            d = c[f.Ki] !== !1;
            c = c[f.Ji] !== !1;
            this.b[Bb](Ck, T(this.ah, this, d, c));
            this.b[Bb](rj,
                T(this.ah, this, d, c))
        };
        Q.ah = function (a, b) {
            var c = Is(Gs(this.ea().targetLanguage)) ? yk : zj;
            kn(this.f, function (a) {
                b && a.Ze(c)
            })
        };
        Q.th = function () {
            jz(this, !0)
        };
        Q.sh = function () {
            jz(this, !1)
        };
        Q.Fg = function () {
            jz(this, !this.Je())
        };
        Q.vh = function (a, b) {
            a == Fh && Vm($y, b) || Yy(Ik, cg + a + Sc + b);
            if (this.d.ea(this.c).B == b) return !1;
            var c = this.Je(),
                d = this;
            kn(this.f, function (f) {
                f[Gb](d.M.Kd, new wu(c, a, b))
            });
            oq(this.b, {
                type: rj,
                sourceLanguage: a,
                targetLanguage: b,
                destinationLanguage: b
            });
            return !0
        };
        Q.ea = function () {
            var a = this.d.ea(this.c);
            return {
                sourceLanguage: a.X,
                targetLanguage: a.B,
                destinationLanguage: a.B
            }
        };
        Q.Je = function () {
            return this.d.N(this.c)
        };
        Q.lj = function (a, b) {
            var c = (b || {}).controlType || (km(this.Gb) && this.Gb[E] > 1 ? Lj : Qk),
                d = S(a) ? p[Wa](a) : a;
            d != j || Yy(Pk, Ff + a);
            var f = this.ea().targetLanguage,
                g = Pn(d),
                h = g.l(O, {
                    "class": Fi,
                    style: Ol
                }),
                k = new Vy(h, eB);
            Vu(k, this.Je());
            eu(k, d);
            Wy() ? (Nn(h, bj + f), Nn(h[K], ej)) : Nn(h, Yi + f);
            Vp(k, rg, this.Ai, i, this);
            Vp(this.b, Ck, gz(k), i, this);
            Vp(this.b, rj, iz(h), i, this);
            if (c == Lj) {
                k.$c ? Vm(k.$c, Ei) || k.$c[s](Ei) : k.$c = [Ei];
                Ju(k, Ei, !0);
                c = new Bv(i, fB);
                for (h = 0; h < this.Gb[E]; ++h) {
                    var k = this.Gb[h],
                        o = g.l(O, {
                            style: Ql
                        }),
                        q = new Uy(o, {
                            language: k
                        }),
                        w = q,
                        z = gB;
                    w.K && e(m(Ze));
                    if (w.h()) w.J = j;
                    w.c = z;
                    c.Ib(q, !0);
                    Wy() ? (Nn(o, dj + k), Nn(o[K], gj)) : Nn(o, Zi + k);
                    k == f && Vu(q, !0)
                }
                Vp(c, rg, this.yi, i, this);
                Vp(this.b, rj, hz(c), i, this);
                f = g.l(O, {
                    style: ii
                });
                g = new by(f, c, hB);
                eu(g, d);
                g.Lg = d[B];
                Wy() ? (Nn(f[K], cj), Nn(f[K][K], fj)) : Nn(f, aj)
            } else if (f == Cg && (k.p = jf, d = k.h())) d.title = jf
        };
        Q.kj = function (a) {
            YA = a
        };
        (function () {
            Sm = function (a, b, c, h) {
                var k = c;
                V(a, function (c, g) {
                    k = b[I](h, k, c, g, a)
                });
                return k
            };
            Ms();
            dz();
            var a = {};
            fm($h, a);
            fm(bi, kz);
            fm(ci, lz);
            fm(ai, dB);
            var b = {
                ENGLISH: Fh
            };
            V($y, function (a) {
                var c = $[a];
                c && (b[c.c] = a)
            });
            a.LanguageCode = b;
            a.TransliterationControl = Xy;
            var c = Xy[F];
            c.makeTransliteratable = c.ij;
            c.showControl = c.lj;
            c.setLanguagePair = c.vh;
            c.enableTransliteration = c.th;
            c.disableTransliteration = c.sh;
            c.toggleTransliteration = c.Fg;
            c.getLanguagePair = c.ea;
            c.isTransliterationEnabled = c.Je;
            c.addEventListener = c.hj;
            c.removeEventListener = c[fc];
            c.dispose = c.s;
            c.setApplicationName = c.kj;
            wm(a.TransliterationControl, $e, {
                SINGLE_LANGUAGE_BUTTON: Qk,
                MULTI_LANGUAGE_BUTTON: Lj
            });
            wm(a.TransliterationControl, ff, {
                STATE_CHANGED: Ck,
                LANGUAGE_CHANGED: rj,
                SERVER_REACHABLE: Vk,
                SERVER_UNREACHABLE: al
            })
        })();
        if (l[jb]) {
            l[jb].Ph = {};
            l[jb].Pj = 1;
            var iB = function (a, b, c) {
                var d = a.t[b],
                    f = a.t[sc];
                if (d && (f || c)) return d = a.t[b][0], c != i ? f = c : f = f[0], d - f
            }, jB = function (a, b, c) {
                    var d = M;
                    l[jb].pt && (d += nd + l[jb].pt, delete l[jb].pt);
                    try {
                        l[Sb] && l[Sb].tran ? d += od + l[Sb].tran : l.gtbExternal && l.gtbExternal.tran ? d += od + l.gtbExternal.tran() : l.chrome && l.chrome.csi && (d += od + l.chrome.csi().tran)
                    } catch (f) {}
                    var g = l.chrome;
                    if (g && (g = g.loadTimes)) g().wasFetchedViaSpdy && (d += jd), g().wasNpnNegotiated && (d += id), g().wasAlternateProtocolAvailable && (d +=
                        dd);
                    a.Rj && (d += ad + a.Rj);
                    var h = a.t,
                        k = h[sc],
                        g = [],
                        o = [],
                        q;
                    for (q in h)
                        if (q != Wk && q[x](hg) != 0) {
                            var w = h[q][1];
                            w ? h[w] && o[s](q + he + iB(a, q, h[w][0])) : k && g[s](q + he + iB(a, q))
                        }
                    delete h[sc];
                    if (b)
                        for (var z in b) d += ad + z + Ke + b[z];
                    (b = c) || (b = ri == p.location.protocol ? si : pi);
                    return [b, Ne, md + (l[jb].sn || ui) + bd, a[Lb], o[E] ? fd + o[L](vd) : M, M, d, ld, g[L](vd)][L](M)
                }, kB = function (a, b, c) {
                    a = jB(a, b, c);
                    if (!a) return M;
                    var b = new Image,
                        d = l[jb].Pj++;
                    l[jb].Ph[d] = b;
                    b.onload = b.onerror = function () {
                        delete l[jb].Ph[d]
                    };
                    b.src = a;
                    b = j;
                    return a
                };
            l[jb].report =
                function (a, b, c) {
                    if (p.webkitVisibilityState == mk) {
                        var d = !1,
                            f = function () {
                                if (!d) {
                                    b ? b.prerender = me : b = {
                                        prerender: me
                                    };
                                    var g;
                                    p.webkitVisibilityState == mk ? g = !1 : (kB(a, b, c), g = !0);
                                    g && (d = !0, p[fc](Nl, f, !1))
                                }
                            };
                        p[Bb](Nl, f, !1);
                        return M
                    }
                    return kB(a, b, c)
            }
        };
    })()
    google.loader.loaded({
        "module": "elements",
        "version": "1.0",
        "components": ["transliteration"]
    });
    google.loader.eval.elements = function () {
        eval(arguments[0]);
    };
    if (google.loader.eval.scripts && google.loader.eval.scripts['elements']) {
        (function () {
            var scripts = google.loader.eval.scripts['elements'];
            for (var i = 0; i < scripts.length; i++) {
                google.loader.eval.elements(scripts[i]);
            }
        })();
        google.loader.eval.scripts['elements'] = null;
    }
})();