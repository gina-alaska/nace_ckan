<?php
/**
 * All the callback request will be handled here
 */
require_once( "Social/Auth.php" );
require_once( "Social/Client.php" );

Social_Client::handle();