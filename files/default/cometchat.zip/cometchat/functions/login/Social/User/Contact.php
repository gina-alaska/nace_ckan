<?php
/**
 * Class Social_user_Contac
 *
 * @author Hüseyin BABAL
 */
class Social_User_Contact {
	public $identifier; 
	public $webSiteURL;
	public $profileURL;
	public $photoURL;
	public $displayName;
	public $description;
	public $email;
}
