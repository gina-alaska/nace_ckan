<?php

include_once(dirname(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR.'config.php');

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* SETTINGS START */

$twitteruser = setConfigValue('twitteruser','');
$notweets = setConfigValue('notweets','');
$consumerkey = setConfigValue('consumerkey','');
$consumersecret = setConfigValue('consumersecret','');
$accesstoken = setConfigValue('accesstoken','');
$accesstokensecret = setConfigValue('accesstokensecret','');


/* SETTINGS END */

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////